=== Rawi MD — Markdown for AI Crawlers ===
Contributors: elalmy111
Tags: markdown, ai, llms, crawlers, seo
Requires at least: 6.2
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Give ChatGPT, Claude and other AI crawlers a clean Markdown copy of your posts, pages and products, plus an llms.txt index and a full analytics dashboard.

== Description ==

People are asking ChatGPT, Claude and Perplexity the questions they used to type into Google. To answer, those tools visit real websites and read them — including yours.

But they read a WordPress page badly. Your content arrives buried in markup, scripts, navigation and cookie banners that mean nothing to a language model, and the model pays for every one of those tokens.

This plugin answers `Accept: text/markdown` with a clean Markdown document at the same URL. Browsers keep getting the normal page. Nothing changes for your visitors, and nothing changes in how you write.

**The part most plugins get wrong**

Page caches answer requests before WordPress runs. When LiteSpeed or WP Rocket has a stored copy of a page, an agent asking for Markdown gets HTML instead, and the plugin never even loads. This plugin handles that on both sides: it tells the cache plugins to stand down at runtime, and it generates the server-level rules you need to paste in so the cache steps aside before PHP starts.

**How agents can reach the Markdown**

* `Accept: text/markdown` on the normal page URL — real HTTP content negotiation, the route AI agents actually use
* A `.md` suffix on any URL, for agents that do not send the header
* `?format=md` or `?output_format=md`

The HTML page also advertises the Markdown version through a `<link rel="alternate">` tag and a `Link:` response header, so an agent can find it without guessing.

**What you control**

* Which post types are served, and which individual pages are excluded
* Which theme elements are stripped, by CSS selector
* Which YAML frontmatter fields appear
* WooCommerce products carry SKU, price, currency, stock status and rating in the frontmatter. Those live in post meta, so a converter working from rendered HTML cannot produce them
* A `Content-Signal` header stating how you allow the content to be used

**llms.txt**

`/llms.txt` is generated automatically: the site name, a short introduction you can write, and a link to the Markdown version of every eligible page, grouped by content type.

**The dashboard**

* Requests, distinct agents, pages read, tokens delivered and **tokens saved** compared with the real HTML page, each against the previous period
* A stacked timeline by agent, with 24-hour, 7-day, 30-day, 90-day and 12-month ranges in your own timezone
* Who is reading: live AI assistants, AI search indexes, training crawlers, search engines and scripts, and which company runs each one
* **Crawler verification**: requests that claim to be Googlebot, Bingbot or Applebot are checked with forward-confirmed reverse DNS, and optionally GPTBot, ChatGPT-User, OAI-SearchBot and Perplexity against their published IP lists. Fake crawlers are flagged.
* **Visitors sent by AI**: people who click through to your site from ChatGPT, Perplexity, Gemini, Copilot, Claude and other assistants, which pages they land on, and how many crawler reads it took to earn each visit. Works behind page caches.
* **AI readiness score** for every page, from the Markdown agents actually receive: summary, substance, headings, alt text, structure, internal links, freshness and size, with a "fix these first" list and the most common issues across the site
* A weekday × hour heatmap, the most requested pages with their Markdown-vs-HTML weight, coverage per content type, broken Markdown links, and a live activity feed
* A health panel and a one-click live test that requests your site the way an agent and a browser would, through every cache in front of it
* A filterable request log with CSV export, a summary widget on the WordPress dashboard, and a box in the post editor showing who read that post

**For developers**

* `wp rawi warm`, `wp rawi flush`, `wp rawi render <id>`, `wp rawi stats`, `wp rawi test`
* Filters: `rawi_is_eligible`, `rawi_markdown_document`, `rawi_frontmatter_data`, `rawi_strip_selectors`, `rawi_llms_txt`, `rawi_agent_catalog`, `rawi_post_types`, `rawi_setting`, `rawi_readiness_checks`, `rawi_referral_hosts`, `rawi_client_ip` (behind a trusted reverse proxy; Cloudflare is detected automatically)
* Markdown is generated in the background as soon as a post is published, so the first agent never waits
* Conditional requests: every response carries an `ETag` and `Last-Modified`, and a repeat visit answers `304 Not Modified`

== Screenshots ==

1. The dashboard: tokens saved, a timeline by agent, who is reading and how they asked.
2. Settings: choose post types, frontmatter fields, caching and logging behaviour.
3. Server rules: detects your caching stack and generates the rules to paste, plus a one-line check.
4. The Markdown a crawler receives, with YAML frontmatter and the content stripped of theme chrome.

== Frequently Asked Questions ==

= Is this cloaking? =

No. Cloaking means serving different content based on who is asking. This is content negotiation: the client states which format it prefers and the server honours it. The words are the same either way. The plugin never inspects the User-Agent to decide what to send.

That said, search engines have not published a definitive position on serving Markdown through content negotiation. The plugin sends `noindex` only on the `.md` and query-string addresses, which are genuine duplicates, and never on your real page URL.

= I already use Cloudflare's Markdown for Agents. Do I need this? =

Probably not, if your zone is on a Pro plan or above and you are happy with the generic conversion. Running both means converting the same page twice. This plugin is for sites on the Cloudflare free plan, sites not behind Cloudflare, and anyone who wants control over what gets stripped and what metadata is attached.

= Will this slow my site down? =

No. Conversion only runs when a client explicitly asks for Markdown, and the result is cached on disk until the post changes. Normal visitors never touch this code path.

= Does it work with Elementor? =

Yes. Elementor renders through the content filters, which is the default source. Bricks and Oxygen replace the whole template, so switch the content source to the full page render for those.

= How do I check it is working? =

`curl -sI -H "Accept: text/markdown" "https://example.com/your-post/"`

You want `content-type: text/markdown` and an `x-markdown-tokens` header. If you get `text/html`, your page cache is answering first — see the Server rules tab.

== Privacy ==

The plugin records Markdown requests in a table in your own database: timestamp, post ID, URL path, user agent, the response status, and a one-way hash of the IP address. Nothing is sent anywhere. Crawler verification uses the IP address in memory during the request and stores only the verdict.

When "Visitors sent by AI" is on, a small inline script runs on public pages. It reads only the referrer and the utm_source of the current page view. If, and only if, they point at an AI assistant, it sends the assistant's name and the visited path to your own site's REST API. No cookie or local identifier is created; a once-per-tab marker in sessionStorage avoids counting a reload twice. Unique visitors are counted with a hash that changes every day, so no visitor can be followed across days. Logged-in editors are never counted. IP addresses are never stored in readable form, hashing can be turned off entirely, and entries are deleted after a retention period you set. Uninstalling removes the table.

== External services ==

By default the plugin makes no request to any outside service.

If you enable *Settings > Request log > Crawler verification > Also download the official IP lists*, the plugin downloads, once a day, the public IP range lists that crawler operators publish, so it can tell real crawlers from impostors. No information about your site or its visitors is sent; it is a plain download.

* OpenAI: https://openai.com/gptbot.json, https://openai.com/searchbot.json, https://openai.com/chatgpt-user.json — [terms](https://openai.com/policies/terms-of-use), [privacy](https://openai.com/policies/privacy-policy)
* Perplexity: https://www.perplexity.ai/perplexitybot.json, https://www.perplexity.ai/perplexity-user.json — [terms](https://www.perplexity.ai/hub/legal/terms-of-service), [privacy](https://www.perplexity.ai/hub/legal/privacy-policy)
* Google: https://developers.google.com/static/search/apis/ipranges/googlebot.json — [terms](https://policies.google.com/terms), [privacy](https://policies.google.com/privacy)
* Microsoft Bing: https://www.bing.com/toolbox/bingbot.json — [terms](https://www.microsoft.com/servicesagreement), [privacy](https://privacy.microsoft.com/privacystatement)

Reverse-DNS verification, which is on by default, performs DNS lookups only and contacts no web service.

== Languages ==

The interface ships in English and Arabic. WordPress picks the Arabic strings automatically when the site language is set to Arabic, and the admin screens follow the right-to-left layout.

== Installation ==

1. Upload the `rawi-md` folder to `/wp-content/plugins/`.
2. Activate the plugin.
3. Open Settings > Rawi MD and pick your post types.
4. Open the Server rules tab and apply the rules for your stack.
5. Run the curl check from that same tab.

== Upgrade Notice ==

= 1.3.0 =
New analytics dashboard, visitors sent by AI, AI readiness scores, llms.txt and crawler verification. Updating keeps every setting and every logged request.

== Changelog ==

= 1.3.0 =
* New dashboard: tokens saved against the real HTML page, period-over-period changes, timeline by agent, heatmap, company and agent-type breakdowns, coverage, broken links, live feed, health checks and a live end-to-end test.
* New request log tab with filters and CSV export, a WordPress dashboard widget, and a box in the post editor with per-post statistics and a "do not serve" switch.
* New: visitors sent by AI assistants, counted with a tiny cache-proof script and shown against crawler reads per page.
* New: AI readiness score for every page, in the dashboard and the post editor.
* New: Markdown is prepared in the background when a post is published or updated.
* New: `/llms.txt` index of every page served as Markdown.
* New: crawler verification with forward-confirmed reverse DNS, and optional official IP lists.
* New: `ETag`, `Last-Modified` and `304 Not Modified` on every Markdown response.
* New: WP-CLI commands `warm`, `flush`, `render`, `stats`, `test` and `refresh-ip-lists`.
* New frontmatter fields: language, featured image and word count. Product prices of variable products, and numbers and booleans written as real YAML types.
* Fixed: a backslash in a title or description produced invalid YAML.
* Fixed: unexpanded SEO templates such as `%%title%% %%sep%% %%sitename%%` appeared as the description.
* Fixed: with the content filters, the removal list deleted `<header>`, `<aside>` and `<form>` blocks the author wrote. The content mode now has its own short list.
* Fixed: spaces around bold, italic and links were lost ("foo**bar**").
* Fixed: `bdi`, `bdo`, `kbd`, `ins` and other inline tags split sentences into separate paragraphs — common in Arabic text.
* Fixed: YouTube and other embeds disappeared; they are now links. Definition lists, video, audio and nested tables are handled.
* Fixed: a `.md` address could resolve to a different post with the same slug. Hierarchical pages now match by full path, and other matches redirect to the real address.
* Fixed: the cache was not cleared when a review was approved, a variation changed, a category was renamed or an author changed their name; files left by older versions are now cleaned up.
* Fixed: the cache folder's protection now works on Apache 2.4 too.
* Fixed: the noindex check now also follows the post-type defaults of Yoast SEO and Rank Math, AIOSEO 4's own table, and the site-wide "Discourage search engines" option.
* Fixed: conflicting `Expires` and `Cache-Control` headers on `.md` responses.
* Logging and verification now run after the response has been sent, so agents never wait for them.
* Updating is safe: settings are only extended, the log table only gains columns, and nothing is deleted.


= 1.2.0 =
* Renamed to Rawi MD. The previous name overlapped with an existing third-party feature name.
* Every function, class, constant, option, hook and database table now uses the RAWI_ prefix.

= 1.1.1 =
* Uninstall now removes cached files through WP_Filesystem rather than direct PHP calls.
* Every database query passes the table name through a prepared identifier placeholder.
* Minimum WordPress raised to 6.2, which is where identifier placeholders arrived.

= 1.1.0 =
* Full Arabic translation, with a right-to-left admin layout.
* Moved to its own top-level menu instead of sitting under Settings.
* Rebuilt the Reports screen: headline figures, a 30-day activity chart, and proportional breakdowns by agent, page and route.

= 1.0.3 =
* Product frontmatter now carries the main image URL, read from meta so it survives either content source.

= 1.0.2 =
* Themes that print the title more than once no longer produce repeated H1 headings.
* Default removal list now covers WooCommerce price, meta, tabs and related-product blocks.

= 1.0.1 =
* Fixed a parse error that stopped the plugin activating.
* The plugin now stays out of the way, and says so in the admin, when PHP is built without the DOM extension.
* Conversion failures fall back to the normal HTML page instead of serving an empty document.

= 1.0.0 =
* First release.
