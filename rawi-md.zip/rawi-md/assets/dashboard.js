/**
 * Rawi MD dashboard.
 *
 * Dependency-free: every chart is drawn as inline SVG from window.RAWI_DASH,
 * so nothing is loaded from a third-party CDN.
 */
( function () {
	'use strict';

	var D = window.RAWI_DASH;
	var root = document.getElementById( 'rawi-dashboard' );

	if ( ! D || ! root ) {
		return;
	}

	var T = D.i18n;
	var state = {
		range: D.range,
		data: D.data,
		hidden: {},
		live: false,
		liveTimer: null,
		lastId: 0,
		agentSort: { key: 'hits', dir: -1 },
		pageSort: { key: 'hits', dir: -1 },
		agentFilter: '',
		pageFilter: ''
	};

	var PALETTE = [ '#6d5efc', '#14b8a6', '#f59e0b', '#ec4899', '#0ea5e9', '#a3acc2' ];
	var KIND_COLORS = {
		assistant: '#6d5efc',
		search: '#0ea5e9',
		training: '#f59e0b',
		search_engine: '#14b8a6',
		tool: '#a3acc2',
		browser: '#c084fc',
		other: '#d6dae4'
	};
	var ROUTE_COLORS = { accept: '#6d5efc', suffix: '#14b8a6', query: '#f59e0b', llms: '#ec4899' };
	var SVGNS = 'http://www.w3.org/2000/svg';

	/* ------------------------------------------------------------------ *
	 * Helpers
	 * ------------------------------------------------------------------ */

	function el( tag, attrs, children ) {
		var node = document.createElement( tag );
		setAttrs( node, attrs );
		append( node, children );
		return node;
	}

	function svg( tag, attrs, children ) {
		var node = document.createElementNS( SVGNS, tag );
		setAttrs( node, attrs );
		append( node, children );
		return node;
	}

	function setAttrs( node, attrs ) {
		if ( ! attrs ) {
			return;
		}
		Object.keys( attrs ).forEach( function ( key ) {
			var value = attrs[ key ];
			if ( null === value || undefined === value || false === value ) {
				return;
			}
			if ( 'text' === key ) {
				node.textContent = value;
			} else if ( 'class' === key ) {
				node.setAttribute( 'class', value );
			} else if ( 0 === key.indexOf( 'on' ) && 'function' === typeof value ) {
				node.addEventListener( key.slice( 2 ), value );
			} else {
				node.setAttribute( key, value );
			}
		} );
	}

	function append( node, children ) {
		if ( null === children || undefined === children ) {
			return;
		}
		( Array.isArray( children ) ? children : [ children ] ).forEach( function ( child ) {
			if ( null === child || undefined === child || false === child ) {
				return;
			}
			if ( Array.isArray( child ) ) {
				append( node, child );
				return;
			}
			node.appendChild( 'object' === typeof child ? child : document.createTextNode( String( child ) ) );
		} );
	}

	function fmt( str ) {
		var args = Array.prototype.slice.call( arguments, 1 );
		var i = 0;
		return String( str )
			.replace( /%(\d+)\$s/g, function ( m, n ) {
				return String( args[ parseInt( n, 10 ) - 1 ] );
			} )
			.replace( /%s/g, function () {
				return String( args[ i++ ] );
			} )
			.replace( /%%/g, '%' );
	}

	var locale = D.locale || 'en';
	var numFmt, compactFmt, pctFmt;

	try {
		numFmt = new Intl.NumberFormat( locale, { numberingSystem: 'latn' } );
		compactFmt = new Intl.NumberFormat( locale, { notation: 'compact', maximumFractionDigits: 1, numberingSystem: 'latn' } );
		pctFmt = new Intl.NumberFormat( locale, { maximumFractionDigits: 1, numberingSystem: 'latn' } );
	} catch ( e ) {
		numFmt = compactFmt = pctFmt = new Intl.NumberFormat( 'en' );
	}

	function n( value ) {
		return numFmt.format( value || 0 );
	}

	function c( value ) {
		value = value || 0;
		return Math.abs( value ) < 10000 ? numFmt.format( value ) : compactFmt.format( value );
	}

	function pct( value ) {
		return pctFmt.format( value ) + '%';
	}

	function bytes( value ) {
		var units = [ 'B', 'KB', 'MB', 'GB' ];
		var i = 0;
		while ( value >= 1024 && i < units.length - 1 ) {
			value /= 1024;
			i++;
		}
		return pctFmt.format( value ) + ' ' + units[ i ];
	}

	var relFmt = null;
	try {
		relFmt = new Intl.RelativeTimeFormat( locale, { numeric: 'auto' } );
	} catch ( e ) {}

	function ago( iso ) {
		if ( ! iso ) {
			return '—';
		}
		var diff = ( Date.parse( iso ) - Date.now() ) / 1000;
		var abs = Math.abs( diff );
		var steps = [ [ 60, 'second', 1 ], [ 3600, 'minute', 60 ], [ 86400, 'hour', 3600 ], [ 604800, 'day', 86400 ], [ 2629800, 'week', 604800 ], [ 31557600, 'month', 2629800 ], [ Infinity, 'year', 31557600 ] ];
		for ( var i = 0; i < steps.length; i++ ) {
			if ( abs < steps[ i ][ 0 ] ) {
				var value = Math.round( diff / steps[ i ][ 2 ] );
				return relFmt ? relFmt.format( value, steps[ i ][ 1 ] ) : value + ' ' + steps[ i ][ 1 ];
			}
		}
		return iso;
	}

	function dateLabel( bucket, unit ) {
		// Buckets are already in site-local time; format them as UTC so the
		// browser's own timezone does not shift them a second time.
		var iso = 'hour' === unit ? bucket.replace( ' ', 'T' ) + ':00Z' : bucket + 'T00:00:00Z';
		var date = new Date( iso );
		try {
			return new Intl.DateTimeFormat( locale, 'hour' === unit ? { hour: '2-digit', minute: '2-digit', timeZone: 'UTC', numberingSystem: 'latn' } : { month: 'short', day: 'numeric', timeZone: 'UTC', numberingSystem: 'latn' } ).format( date );
		} catch ( e ) {
			return bucket;
		}
	}

	function weekdayNames() {
		var names = [];
		for ( var i = 0; i < 7; i++ ) {
			// 2023-01-01 was a Sunday.
			var date = new Date( Date.UTC( 2023, 0, 1 + i ) );
			try {
				names.push( new Intl.DateTimeFormat( locale, { weekday: 'short', timeZone: 'UTC' } ).format( date ) );
			} catch ( e ) {
				names.push( [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ][ i ] );
			}
		}
		return names;
	}

	function agentName( label ) {
		return '__other' === label ? T.other : label;
	}

	function post( action, params ) {
		var body = new URLSearchParams();
		body.append( 'action', action );
		body.append( 'nonce', D.nonce );
		Object.keys( params || {} ).forEach( function ( key ) {
			body.append( key, params[ key ] );
		} );
		return fetch( D.ajax, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( res ) {
				return res.json();
			} )
			.then( function ( json ) {
				if ( ! json || ! json.success ) {
					throw new Error( 'request failed' );
				}
				return json.data;
			} );
	}

	function niceMax( value ) {
		if ( value <= 4 ) {
			return 4;
		}
		var exp = Math.pow( 10, Math.floor( Math.log10( value ) ) );
		var f = value / exp;
		var nice = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10;
		return nice * exp;
	}

	function sum( list ) {
		return list.reduce( function ( a, b ) {
			return a + b;
		}, 0 );
	}

	/* ------------------------------------------------------------------ *
	 * Tooltip
	 * ------------------------------------------------------------------ */

	var tip = el( 'div', { class: 'rawi-tip', role: 'tooltip' } );
	document.body.appendChild( tip );

	function showTip( evt, content ) {
		tip.innerHTML = '';
		append( tip, content );
		tip.classList.add( 'is-visible' );
		var x = evt.clientX + 14;
		var y = evt.clientY + 14;
		var rect = tip.getBoundingClientRect();
		if ( x + rect.width > window.innerWidth - 8 ) {
			x = evt.clientX - rect.width - 14;
		}
		if ( y + rect.height > window.innerHeight - 8 ) {
			y = evt.clientY - rect.height - 14;
		}
		tip.style.left = Math.max( 8, x ) + 'px';
		tip.style.top = Math.max( 8, y ) + 'px';
	}

	function hideTip() {
		tip.classList.remove( 'is-visible' );
	}

	/* ------------------------------------------------------------------ *
	 * Building blocks
	 * ------------------------------------------------------------------ */

	function card( title, hint, body, extra ) {
		return el( 'section', { class: 'rawi-card' + ( extra && extra.cls ? ' ' + extra.cls : '' ), id: extra && extra.id }, [
			el( 'header', { class: 'rawi-card__head' }, [
				el( 'div', null, [
					el( 'h2', { text: title } ),
					hint ? el( 'p', { class: 'rawi-card__hint', text: hint } ) : null
				] ),
				extra && extra.actions ? el( 'div', { class: 'rawi-card__actions' }, extra.actions ) : null
			] ),
			el( 'div', { class: 'rawi-card__body' }, body )
		] );
	}

	function empty( text, hint ) {
		return el( 'div', { class: 'rawi-empty-state' }, [
			el( 'span', { class: 'rawi-empty-state__icon', 'aria-hidden': 'true' }, '◌' ),
			el( 'p', { text: text } ),
			hint ? el( 'p', { class: 'rawi-muted', text: hint } ) : null
		] );
	}

	function delta( current, previous ) {
		if ( ! previous ) {
			return current > 0 ? el( 'span', { class: 'rawi-delta rawi-delta--new', text: T.newPeriod } ) : null;
		}
		var change = ( ( current - previous ) / previous ) * 100;
		var cls = change > 0.5 ? 'up' : change < -0.5 ? 'down' : 'flat';
		var arrow = 'up' === cls ? '▲' : 'down' === cls ? '▼' : '■';
		return el( 'span', { class: 'rawi-delta rawi-delta--' + cls, title: T.vsPrev }, arrow + ' ' + pct( Math.abs( Math.round( change * 10 ) / 10 ) ) );
	}

	function sparkline( values, color ) {
		var w = 120;
		var h = 34;
		var max = Math.max.apply( null, values.concat( [ 1 ] ) );
		var step = values.length > 1 ? w / ( values.length - 1 ) : w;
		var points = values.map( function ( v, i ) {
			return [ i * step, h - 3 - ( v / max ) * ( h - 6 ) ];
		} );
		var line = points.map( function ( p, i ) {
			return ( i ? 'L' : 'M' ) + p[ 0 ].toFixed( 1 ) + ' ' + p[ 1 ].toFixed( 1 );
		} ).join( ' ' );
		var area = line + ' L' + w + ' ' + h + ' L0 ' + h + ' Z';
		var id = 'g' + Math.random().toString( 36 ).slice( 2 );

		return svg( 'svg', { class: 'rawi-spark', viewBox: '0 0 ' + w + ' ' + h, preserveAspectRatio: 'none', 'aria-hidden': 'true' }, [
			svg( 'defs', null, svg( 'linearGradient', { id: id, x1: '0', x2: '0', y1: '0', y2: '1' }, [
				svg( 'stop', { offset: '0%', 'stop-color': color, 'stop-opacity': '0.35' } ),
				svg( 'stop', { offset: '100%', 'stop-color': color, 'stop-opacity': '0' } )
			] ) ),
			svg( 'path', { d: area, fill: 'url(#' + id + ')' } ),
			svg( 'path', { d: line, fill: 'none', stroke: color, 'stroke-width': '2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'vector-effect': 'non-scaling-stroke' } )
		] );
	}

	function kpi( opts ) {
		return el( 'div', { class: 'rawi-kpi' + ( opts.accent ? ' rawi-kpi--accent' : '' ) }, [
			el( 'div', { class: 'rawi-kpi__top' }, [
				el( 'span', { class: 'rawi-kpi__label', text: opts.label } ),
				opts.delta || null
			] ),
			el( 'div', { class: 'rawi-kpi__value', title: opts.exact || null }, opts.value ),
			el( 'div', { class: 'rawi-kpi__note' }, opts.note || ' ' ),
			opts.spark ? el( 'div', { class: 'rawi-kpi__spark' }, opts.spark ) : null
		] );
	}

	function meter( ratio, color ) {
		return el( 'span', { class: 'rawi-meter' }, el( 'span', { class: 'rawi-meter__fill', style: 'width:' + Math.max( 0, Math.min( 100, ratio * 100 ) ).toFixed( 1 ) + '%;' + ( color ? 'background:' + color : '' ) } ) );
	}

	/* ------------------------------------------------------------------ *
	 * Charts
	 * ------------------------------------------------------------------ */

	function stackedChart( series, ns ) {
		ns = ns || '';
		var wrap = el( 'div', { class: 'rawi-chart-wrap' } );
		var legend = el( 'div', { class: 'rawi-legend' } );
		var canvas = el( 'div', { class: 'rawi-chart-canvas', dir: 'ltr' } );

		series.series.forEach( function ( s, i ) {
			var color = PALETTE[ '__other' === s.label ? 5 : i % 5 ];
			var item = el( 'button', {
				type: 'button',
				class: 'rawi-legend__item' + ( state.hidden[ ns + s.label ] ? ' is-off' : '' ),
				onclick: function () {
					state.hidden[ ns + s.label ] = ! state.hidden[ ns + s.label ];
					item.classList.toggle( 'is-off' );
					draw();
				}
			}, [ el( 'span', { class: 'rawi-swatch', style: 'background:' + color } ), agentName( s.label ), el( 'b', { text: c( sum( s.values ) ) } ) ] );
			legend.appendChild( item );
		} );

		function draw() {
			canvas.innerHTML = '';
			var width = Math.max( 320, canvas.clientWidth || 800 );
			var height = 280;
			var pad = { l: 46, r: 12, t: 14, b: 30 };
			var innerW = width - pad.l - pad.r;
			var innerH = height - pad.t - pad.b;
			var buckets = series.buckets;
			var visible = series.series.map( function ( s, i ) {
				return { s: s, color: PALETTE[ '__other' === s.label ? 5 : i % 5 ], on: ! state.hidden[ ns + s.label ] };
			} );
			var totals = buckets.map( function ( b, i ) {
				return visible.reduce( function ( acc, v ) {
					return acc + ( v.on ? v.s.values[ i ] : 0 );
				}, 0 );
			} );
			var max = niceMax( Math.max.apply( null, totals.concat( [ 1 ] ) ) );
			var slot = innerW / buckets.length;
			var barW = Math.max( 2, Math.min( 34, slot * 0.68 ) );

			var chart = svg( 'svg', { class: 'rawi-chart', width: width, height: height, viewBox: '0 0 ' + width + ' ' + height, role: 'img', 'aria-label': T.requestsOver } );

			// Grid and y axis.
			for ( var g = 0; g <= 4; g++ ) {
				var y = pad.t + innerH - ( g / 4 ) * innerH;
				chart.appendChild( svg( 'line', { x1: pad.l, x2: width - pad.r, y1: y, y2: y, class: 'rawi-gridline' + ( 0 === g ? ' rawi-gridline--base' : '' ) } ) );
				chart.appendChild( svg( 'text', { x: pad.l - 8, y: y + 4, class: 'rawi-axis', 'text-anchor': 'end' }, c( ( max / 4 ) * g ) ) );
			}

			// Bars.
			buckets.forEach( function ( bucket, i ) {
				var x = pad.l + slot * i + ( slot - barW ) / 2;
				var yCursor = pad.t + innerH;
				var group = svg( 'g', { class: 'rawi-bar' } );
				var stack = visible.filter( function ( v ) {
					return v.on && v.s.values[ i ] > 0;
				} );

				stack.forEach( function ( v, k ) {
					var h = ( v.s.values[ i ] / max ) * innerH;
					yCursor -= h;
					var isTop = k === stack.length - 1;
					group.appendChild( svg( 'rect', {
						x: x.toFixed( 2 ),
						y: yCursor.toFixed( 2 ),
						width: barW.toFixed( 2 ),
						height: Math.max( 0.5, h - ( isTop ? 0 : 1 ) ).toFixed( 2 ),
						rx: isTop ? Math.min( 4, barW / 3 ) : 0,
						fill: v.color
					} ) );
				} );

				// Full-height hit area for the tooltip.
				var hit = svg( 'rect', { x: pad.l + slot * i, y: pad.t, width: slot, height: innerH, class: 'rawi-hit' } );
				hit.addEventListener( 'mousemove', function ( evt ) {
					group.classList.add( 'is-hover' );
					var rows = visible.filter( function ( v ) {
						return v.on && v.s.values[ i ] > 0;
					} ).map( function ( v ) {
						return el( 'div', { class: 'rawi-tip__row' }, [ el( 'span', { class: 'rawi-swatch', style: 'background:' + v.color } ), agentName( v.s.label ), el( 'b', { text: n( v.s.values[ i ] ) } ) ] );
					} );
					showTip( evt, [
						el( 'div', { class: 'rawi-tip__title', text: dateLabel( bucket, series.unit ) + ( 'hour' === series.unit ? '' : '' ) } ),
						rows.length ? rows : el( 'div', { class: 'rawi-muted', text: '0' } ),
						el( 'div', { class: 'rawi-tip__total' }, [ T.total, el( 'b', { text: n( totals[ i ] ) } ) ] )
					] );
				} );
				hit.addEventListener( 'mouseleave', function () {
					group.classList.remove( 'is-hover' );
					hideTip();
				} );

				chart.appendChild( group );
				chart.appendChild( hit );
			} );

			// X labels: at most ~8, evenly spaced.
			var every = Math.max( 1, Math.ceil( buckets.length / Math.max( 3, Math.floor( innerW / 90 ) ) ) );
			buckets.forEach( function ( bucket, i ) {
				if ( i % every !== 0 && i !== buckets.length - 1 ) {
					return;
				}
				if ( i === buckets.length - 1 && i % every !== 0 && ( i % every ) < every / 2 ) {
					return;
				}
				chart.appendChild( svg( 'text', { x: pad.l + slot * i + slot / 2, y: height - 8, class: 'rawi-axis', 'text-anchor': 'middle' }, dateLabel( bucket, series.unit ) ) );
			} );

			canvas.appendChild( chart );
		}

		wrap.appendChild( canvas );
		wrap.appendChild( legend );

		if ( window.ResizeObserver ) {
			var last = 0;
			new ResizeObserver( function () {
				if ( Math.abs( canvas.clientWidth - last ) > 4 ) {
					last = canvas.clientWidth;
					draw();
				}
			} ).observe( canvas );
		} else {
			setTimeout( draw, 0 );
			window.addEventListener( 'resize', draw );
		}

		return wrap;
	}

	function donut( items, centerLabel ) {
		var total = sum( items.map( function ( i ) {
			return i.value;
		} ) );
		var size = 168;
		var r = 64;
		var stroke = 22;
		var circ = 2 * Math.PI * r;
		var offset = 0;
		var chart = svg( 'svg', { class: 'rawi-donut', viewBox: '0 0 ' + size + ' ' + size, width: size, height: size, role: 'img' } );

		chart.appendChild( svg( 'circle', { cx: size / 2, cy: size / 2, r: r, fill: 'none', class: 'rawi-donut__track', 'stroke-width': stroke } ) );

		items.forEach( function ( item ) {
			if ( ! item.value ) {
				return;
			}
			var len = ( item.value / total ) * circ;
			var arc = svg( 'circle', {
				cx: size / 2,
				cy: size / 2,
				r: r,
				fill: 'none',
				stroke: item.color,
				'stroke-width': stroke,
				'stroke-dasharray': Math.max( 0, len - 2 ).toFixed( 2 ) + ' ' + circ.toFixed( 2 ),
				'stroke-dashoffset': ( -offset ).toFixed( 2 ),
				transform: 'rotate(-90 ' + size / 2 + ' ' + size / 2 + ')',
				class: 'rawi-donut__arc'
			} );
			arc.addEventListener( 'mousemove', function ( evt ) {
				showTip( evt, [ el( 'div', { class: 'rawi-tip__title', text: item.label } ), el( 'div', { class: 'rawi-tip__total' }, [ n( item.value ), el( 'b', { text: pct( Math.round( ( item.value / total ) * 1000 ) / 10 ) } ) ] ) ] );
			} );
			arc.addEventListener( 'mouseleave', hideTip );
			chart.appendChild( arc );
			offset += len;
		} );

		chart.appendChild( svg( 'text', { x: size / 2, y: size / 2 - 2, 'text-anchor': 'middle', class: 'rawi-donut__value' }, c( total ) ) );
		chart.appendChild( svg( 'text', { x: size / 2, y: size / 2 + 18, 'text-anchor': 'middle', class: 'rawi-donut__label' }, centerLabel ) );

		var legend = el( 'ul', { class: 'rawi-donut__legend' }, items.map( function ( item ) {
			return el( 'li', null, [
				el( 'span', { class: 'rawi-swatch', style: 'background:' + item.color } ),
				el( 'span', { class: 'rawi-donut__name', text: item.label } ),
				el( 'b', { text: total ? pct( Math.round( ( item.value / total ) * 1000 ) / 10 ) : '0%' } )
			] );
		} ) );

		return el( 'div', { class: 'rawi-donut-wrap' }, [ el( 'div', { dir: 'ltr' }, chart ), legend ] );
	}

	function heatmap( grid ) {
		var names = weekdayNames();
		var start = D.startOfWeek || 0;
		var max = 0;
		var best = { d: 0, h: 0, v: 0 };

		grid.forEach( function ( row, d ) {
			row.forEach( function ( v, h ) {
				if ( v > max ) {
					max = v;
					best = { d: d, h: h, v: v };
				}
			} );
		} );

		var table = el( 'div', { class: 'rawi-heat', dir: 'ltr' } );
		table.appendChild( el( 'span', { class: 'rawi-heat__corner' } ) );

		for ( var h = 0; h < 24; h++ ) {
			table.appendChild( el( 'span', { class: 'rawi-heat__hour', text: 0 === h % 3 ? String( h ).padStart( 2, '0' ) : '' } ) );
		}

		for ( var k = 0; k < 7; k++ ) {
			var d = ( start + k ) % 7;
			table.appendChild( el( 'span', { class: 'rawi-heat__day', text: names[ d ] } ) );

			for ( var hr = 0; hr < 24; hr++ ) {
				var v = grid[ d ][ hr ];
				var level = max ? v / max : 0;
				var cell = el( 'span', {
					class: 'rawi-heat__cell' + ( v ? '' : ' is-zero' ),
					style: v ? 'background: rgba(109, 94, 252,' + ( 0.12 + level * 0.88 ).toFixed( 3 ) + ')' : null
				} );
				( function ( day, hour, value ) {
					cell.addEventListener( 'mousemove', function ( evt ) {
						showTip( evt, [ el( 'div', { class: 'rawi-tip__title', text: names[ day ] + ' ' + String( hour ).padStart( 2, '0' ) + ':00' } ), el( 'div', { class: 'rawi-tip__total' }, [ T.requestsShort, el( 'b', { text: n( value ) } ) ] ) ] );
					} );
					cell.addEventListener( 'mouseleave', hideTip );
				} )( d, hr, v );
				table.appendChild( cell );
			}
		}

		var foot = max
			? el( 'p', { class: 'rawi-card__foot', text: fmt( T.peak, names[ best.d ], String( best.h ).padStart( 2, '0' ) + ':00' ) } )
			: null;

		return el( 'div', null, [ table, foot ] );
	}

	/* ------------------------------------------------------------------ *
	 * Tables
	 * ------------------------------------------------------------------ */

	function sortable( columns, rows, sortState, onSort ) {
		var head = el( 'tr', null, columns.map( function ( col ) {
			var active = sortState.key === col.key;
			return el( 'th', {
				class: ( col.num ? 'num ' : '' ) + ( col.sort === false ? '' : 'is-sortable' ) + ( active ? ' is-sorted' : '' ),
				onclick: col.sort === false ? null : function () {
					sortState.dir = active ? -sortState.dir : -1;
					sortState.key = col.key;
					onSort();
				}
			}, [ col.label, active ? el( 'span', { class: 'rawi-sort', text: sortState.dir < 0 ? ' ↓' : ' ↑' } ) : null ] );
		} ) );

		var sorted = rows.slice().sort( function ( a, b ) {
			var x = a[ sortState.key ];
			var y = b[ sortState.key ];
			if ( null === x || undefined === x ) {
				x = -Infinity;
			}
			if ( null === y || undefined === y ) {
				y = -Infinity;
			}
			if ( 'string' === typeof x ) {
				return x.localeCompare( y ) * sortState.dir * -1;
			}
			return ( x - y ) * sortState.dir;
		} );

		return el( 'table', { class: 'rawi-table' }, [
			el( 'thead', null, head ),
			el( 'tbody', null, sorted.map( function ( row ) {
				return el( 'tr', null, columns.map( function ( col ) {
					return el( 'td', { class: col.num ? 'num' : null }, col.render( row ) );
				} ) );
			} ) )
		] );
	}

	function identityBadge( agent ) {
		if ( ! D.verifyOn ) {
			return el( 'span', { class: 'rawi-pill', text: T.verifyOff } );
		}
		if ( agent.spoofed && agent.verified ) {
			return el( 'span', { class: 'rawi-pill rawi-pill--warn', title: fmt( T.spoofedNote, n( agent.spoofed ) ), text: T.mixedBadge + ' · ' + c( agent.spoofed ) } );
		}
		if ( agent.spoofed ) {
			return el( 'span', { class: 'rawi-pill rawi-pill--bad', text: T.spoofedBadge } );
		}
		if ( agent.verified ) {
			return el( 'span', { class: 'rawi-pill rawi-pill--ok', text: '✓ ' + T.verifiedBadge } );
		}
		if ( ! agent.verifiable ) {
			return el( 'span', { class: 'rawi-pill', text: T.unverifiable } );
		}
		return el( 'span', { class: 'rawi-pill', text: T.pending } );
	}

	function agentsTable() {
		var holder = el( 'div', { class: 'rawi-table-wrap' } );
		var data = state.data.agents;
		var total = sum( data.map( function ( a ) {
			return a.hits;
		} ) );

		function render() {
			var filter = state.agentFilter.toLowerCase();
			var rows = data.filter( function ( a ) {
				return ! filter || ( a.label + ' ' + a.operator ).toLowerCase().indexOf( filter ) !== -1;
			} );

			holder.innerHTML = '';
			holder.appendChild( sortable( [
				{
					key: 'label',
					label: T.colAgent,
					render: function ( a ) {
						return el( 'div', { class: 'rawi-agent' }, [
							el( 'span', { class: 'rawi-avatar', style: 'background:' + ( KIND_COLORS[ a.kind ] || KIND_COLORS.other ) }, a.label.charAt( 0 ).toUpperCase() ),
							el( 'div', null, [ el( 'strong', { text: a.label } ), el( 'div', { class: 'rawi-muted', text: a.operator || T.unknownOperator } ) ] )
						] );
					}
				},
				{
					key: 'kind',
					label: T.colKind,
					render: function ( a ) {
						return el( 'span', { class: 'rawi-chip', style: '--chip:' + ( KIND_COLORS[ a.kind ] || KIND_COLORS.other ) }, D.kinds[ a.kind ] || a.kind );
					}
				},
				{
					key: 'hits',
					label: T.colRequests,
					num: true,
					render: function ( a ) {
						return el( 'div', { class: 'rawi-share' }, [ el( 'b', { text: n( a.hits ) } ), meter( total ? a.hits / total : 0, KIND_COLORS[ a.kind ] ) ] );
					}
				},
				{ key: 'pages', label: T.colPages, num: true, render: function ( a ) { return n( a.pages ); } },
				{ key: 'tokens', label: T.colTokens, num: true, render: function ( a ) { return c( a.tokens ); } },
				{ key: 'verified', label: T.colVerification, render: identityBadge },
				{
					key: 'last_seen',
					label: T.colLastSeen,
					render: function ( a ) {
						return el( 'span', { title: a.last_seen, text: ago( a.last_seen ) } );
					}
				}
			], rows, state.agentSort, render ) );
		}

		render();
		return holder;
	}

	function pagesTable() {
		var holder = el( 'div', { class: 'rawi-table-wrap' } );
		var data = state.data.pages;

		function render() {
			var filter = state.pageFilter.toLowerCase();
			var rows = data.filter( function ( p ) {
				return ! filter || p.title.toLowerCase().indexOf( filter ) !== -1;
			} );

			holder.innerHTML = '';
			holder.appendChild( sortable( [
				{
					key: 'title',
					label: T.colPage,
					render: function ( p ) {
						return el( 'div', { class: 'rawi-page' }, [
							p.url ? el( 'a', { href: p.url, target: '_blank', rel: 'noopener', text: p.title } ) : el( 'span', { text: p.title } ),
							el( 'div', { class: 'rawi-row-actions' }, [
								p.type ? el( 'span', { class: 'rawi-muted', text: p.type } ) : null,
								p.md_url ? el( 'a', { href: p.md_url, target: '_blank', rel: 'noopener', text: T.viewMd } ) : null,
								p.edit_url ? el( 'a', { href: p.edit_url, text: T.edit } ) : null
							] )
						] );
					}
				},
				{ key: 'hits', label: T.colRequests, num: true, render: function ( p ) { return el( 'b', { text: n( p.hits ) } ); } },
				{ key: 'agents', label: T.colAgentsN, num: true, render: function ( p ) { return n( p.agents ); } },
				{
					key: 'md_tokens',
					label: T.colWeight,
					render: function ( p ) {
						if ( ! p.html_tokens ) {
							return el( 'span', { class: 'rawi-muted', text: c( p.md_tokens ) + ' · ' + T.measuring } );
						}
						return el( 'div', { class: 'rawi-weight', title: n( p.md_tokens ) + ' / ' + n( p.html_tokens ) }, [
							el( 'span', { class: 'rawi-weight__bar' }, [
								el( 'span', { class: 'rawi-weight__md', style: 'width:' + Math.max( 2, Math.min( 100, ( p.md_tokens / p.html_tokens ) * 100 ) ).toFixed( 1 ) + '%' } )
							] ),
							el( 'span', { class: 'rawi-muted', text: c( p.md_tokens ) + ' / ' + c( p.html_tokens ) } )
						] );
					}
				},
				{
					key: 'saving_pct',
					label: T.colSaving,
					num: true,
					render: function ( p ) {
						return null === p.saving_pct ? '—' : el( 'span', { class: 'rawi-saving', text: '−' + pct( p.saving_pct ) } );
					}
				},
				{
					key: 'last_seen',
					label: T.colLastSeen,
					render: function ( p ) {
						return el( 'span', { title: p.last_seen, text: ago( p.last_seen ) } );
					}
				}
			], rows, state.pageSort, render ) );
		}

		render();
		return holder;
	}

	function filterInput( key, onInput ) {
		return el( 'input', {
			type: 'search',
			class: 'rawi-search',
			placeholder: T.search,
			value: state[ key ],
			oninput: function ( evt ) {
				state[ key ] = evt.target.value;
				onInput();
			}
		} );
	}

	/* ------------------------------------------------------------------ *
	 * Live feed
	 * ------------------------------------------------------------------ */

	var feedList = null;

	function feedRow( r, fresh ) {
		var status = 304 === r.status ? T.status304 : 404 === r.status ? T.status404 : r.cache_hit ? T.cacheHit : T.cacheMiss;
		return el( 'li', { class: 'rawi-feed__row' + ( fresh ? ' is-new' : '' ) + ( 404 === r.status ? ' is-error' : '' ) }, [
			el( 'span', { class: 'rawi-feed__dot', style: 'background:' + ( KIND_COLORS[ r.kind ] || KIND_COLORS.other ) } ),
			el( 'div', { class: 'rawi-feed__main' }, [
				el( 'div', null, [
					el( 'strong', { text: r.agent } ),
					1 === r.verified ? el( 'span', { class: 'rawi-pill rawi-pill--ok rawi-pill--xs', text: '✓' } ) : null,
					2 === r.verified ? el( 'span', { class: 'rawi-pill rawi-pill--bad rawi-pill--xs', text: T.spoofedBadge } ) : null,
					el( 'span', { class: 'rawi-feed__route', style: '--chip:' + ( ROUTE_COLORS[ r.route ] || '#a3acc2' ) }, D.routes[ r.route ] || r.route )
				] ),
				el( 'div', { class: 'rawi-feed__title', title: r.path, text: r.title || r.path } )
			] ),
			el( 'div', { class: 'rawi-feed__meta' }, [
				el( 'span', { class: 'rawi-code-badge rawi-code-badge--' + r.status, text: String( r.status ) } ),
				el( 'span', { class: 'rawi-muted', text: status + ( r.tokens ? ' · ' + c( r.tokens ) : '' ) } ),
				el( 'time', { class: 'rawi-muted', title: r.time, 'data-time': r.time, text: ago( r.time ) } )
			] )
		] );
	}

	function liveFeed() {
		feedList = el( 'ul', { class: 'rawi-feed' } );
		var rows = state.data.recent;

		state.lastId = rows.length ? rows[ 0 ].id : 0;

		if ( ! rows.length ) {
			// Keep the list in the page so live polling has somewhere to
			// put the first request; the placeholder goes when it arrives.
			return el( 'div', null, [ el( 'div', { class: 'rawi-feed-empty' }, empty( T.noData ) ), feedList ] );
		}

		rows.forEach( function ( r ) {
			feedList.appendChild( feedRow( r, false ) );
		} );

		return feedList;
	}

	function poll() {
		post( 'rawi_recent', { after: state.lastId } ).then( function ( rows ) {
			if ( ! rows.length || ! feedList ) {
				return;
			}
			state.lastId = rows[ 0 ].id;
			var placeholder = document.querySelector( '.rawi-feed-empty' );
			if ( placeholder ) {
				placeholder.parentNode.removeChild( placeholder );
			}
			rows.slice().reverse().forEach( function ( r ) {
				feedList.insertBefore( feedRow( r, true ), feedList.firstChild );
			} );
			while ( feedList.children.length > 60 ) {
				feedList.removeChild( feedList.lastChild );
			}
			var badge = document.querySelector( '.rawi-live__count' );
			if ( badge ) {
				badge.textContent = fmt( T.newRequests, rows.length );
				badge.classList.add( 'is-visible' );
				setTimeout( function () {
					badge.classList.remove( 'is-visible' );
				}, 4000 );
			}
		} ).catch( function () {} );

		// Keep relative times fresh.
		document.querySelectorAll( '.rawi-feed time[data-time]' ).forEach( function ( t ) {
			t.textContent = ago( t.getAttribute( 'data-time' ) );
		} );
	}

	function setLive( on ) {
		state.live = on;
		clearInterval( state.liveTimer );
		if ( on ) {
			poll();
			state.liveTimer = setInterval( poll, 10000 );
		}
		try {
			window.localStorage.setItem( 'rawiLive', on ? '1' : '0' );
		} catch ( e ) {}
	}

	/* ------------------------------------------------------------------ *
	 * Health and tools
	 * ------------------------------------------------------------------ */

	function checkList( checks ) {
		return el( 'ul', { class: 'rawi-checks' }, checks.map( function ( check ) {
			var icon = 'pass' === check.state ? '✓' : 'warn' === check.state ? '!' : '✕';
			return el( 'li', { class: 'rawi-check rawi-check--' + check.state }, [
				el( 'span', { class: 'rawi-check__icon', text: icon } ),
				el( 'div', null, [ el( 'strong', { text: check.label } ), el( 'div', { class: 'rawi-muted', text: check.detail } ) ] )
			] );
		} ) );
	}

	function healthCard() {
		var results = el( 'div', { class: 'rawi-test-results' } );
		var button = el( 'button', {
			type: 'button',
			class: 'button button-primary',
			onclick: function () {
				button.disabled = true;
				button.textContent = T.running;
				results.innerHTML = '';
				results.appendChild( el( 'span', { class: 'spinner is-active' } ) );
				post( 'rawi_selftest' ).then( function ( res ) {
					results.innerHTML = '';
					if ( res.url ) {
						results.appendChild( el( 'p', { class: 'rawi-muted' }, el( 'code', { text: res.url } ) ) );
					}
					results.appendChild( checkList( res.checks ) );
				} ).catch( function () {
					results.innerHTML = '';
					results.appendChild( el( 'p', { class: 'rawi-error', text: T.error } ) );
				} ).then( function () {
					button.disabled = false;
					button.textContent = T.runTest;
				} );
			}
		}, T.runTest );

		return card( T.health, T.testHint, [ checkList( D.health ), el( 'div', { class: 'rawi-test' }, [ button, results ] ) ], { id: 'rawi-health' } );
	}

	function coverageCard() {
		var cov = state.data.coverage;
		var progress = el( 'div', { class: 'rawi-warm' } );
		var button = el( 'button', {
			type: 'button',
			class: 'button',
			onclick: function () {
				var made = 0;
				button.disabled = true;

				function step( offset ) {
					post( 'rawi_warm', { offset: offset } ).then( function ( res ) {
						made += res.generated;
						progress.innerHTML = '';
						progress.appendChild( meter( res.total ? res.next / res.total : 1 ) );
						progress.appendChild( el( 'span', { class: 'rawi-muted', text: res.done ? fmt( T.generated, n( made ) ) : fmt( T.generating, n( res.next ), n( res.total ) ) } ) );
						if ( ! res.done ) {
							step( res.next );
						} else {
							button.disabled = false;
						}
					} ).catch( function () {
						button.disabled = false;
						progress.appendChild( el( 'span', { class: 'rawi-error', text: T.error } ) );
					} );
				}

				step( 0 );
			}
		}, T.generateAll );

		var rows = cov.types.map( function ( t ) {
			var ratio = t.published ? t.read / t.published : 0;
			return el( 'div', { class: 'rawi-coverage__row' }, [
				el( 'div', { class: 'rawi-coverage__head' }, [ el( 'strong', { text: t.label } ), el( 'span', { class: 'rawi-muted', text: fmt( T.readOf, n( t.read ), n( t.published ) ) + ' · ' + pct( Math.round( ratio * 1000 ) / 10 ) } ) ] ),
				meter( ratio, '#14b8a6' )
			] );
		} );

		return card( T.coverage, T.coverageHint, [
			el( 'div', { class: 'rawi-coverage' }, rows ),
			el( 'div', { class: 'rawi-coverage__cache' }, [
				el( 'span', { class: 'rawi-muted', text: fmt( T.cachedDocs, n( cov.cached_files ), bytes( cov.cached_bytes ) ) } ),
				D.warmTotal ? button : null
			] ),
			progress
		] );
	}

	function missingCard() {
		var rows = state.data.missing;
		var body = rows.length
			? el( 'ul', { class: 'rawi-missing' }, rows.map( function ( r ) {
				return el( 'li', null, [ el( 'code', { text: r.path } ), el( 'span', { class: 'rawi-muted', text: n( r.hits ) + ' · ' + ago( r.last_seen ) } ) ] );
			} ) )
			: el( 'p', { class: 'rawi-ok', text: '✓ ' + T.noMissing } );

		return card( T.missing, T.missingHint, body );
	}

	/* ------------------------------------------------------------------ *
	 * Visitors sent by AI
	 * ------------------------------------------------------------------ */

	function miniKpi( label, value, note, deltaNode ) {
		return el( 'div', { class: 'rawi-mini' }, [
			el( 'div', { class: 'rawi-kpi__top' }, [ el( 'span', { class: 'rawi-kpi__label', text: label } ), deltaNode || null ] ),
			el( 'div', { class: 'rawi-mini__value' }, value ),
			note ? el( 'div', { class: 'rawi-kpi__note' }, note ) : null
		] );
	}

	function referralsSection() {
		var r = state.data.referrals;

		if ( ! r ) {
			return null;
		}

		if ( ! r.enabled ) {
			return card( T.aiVisitors, T.aiVisitorsHint, el( 'p', { class: 'rawi-muted' }, [ T.referralsOff, ' ', el( 'a', { href: D.settingsUrl, text: '→' } ) ] ), { cls: 'rawi-card--referrals' } );
		}

		if ( ! r.kpis.visits ) {
			return card( T.aiVisitors, T.aiVisitorsHint, empty( T.noReferrals, T.noReferralsHint ), { cls: 'rawi-card--referrals' } );
		}

		var served = state.data.kpis.served || 0;
		var ratio = served / r.kpis.visits;
		var top = r.sources.length ? r.sources[ 0 ] : null;

		var kpis = el( 'div', { class: 'rawi-minis' }, [
			miniKpi( T.visits, n( r.kpis.visits ), null, delta( r.kpis.visits, r.previous.visits ) ),
			miniKpi( T.visitors, r.kpis.visitors ? n( r.kpis.visitors ) : '—', null, r.kpis.visitors ? delta( r.kpis.visitors, r.previous.visitors ) : null ),
			miniKpi( T.topSource, top ? top.key : '—', top ? n( top.hits ) + ' · ' + pct( Math.round( ( top.hits / r.kpis.visits ) * 1000 ) / 10 ) : null ),
			miniKpi( T.readsPerVisit, served ? pctFmt.format( Math.round( ratio * 10 ) / 10 ) : '—', T.readsPerHint )
		] );

		var pages = r.pages.length
			? el( 'div', { class: 'rawi-table-wrap rawi-table-wrap--inset' }, el( 'table', { class: 'rawi-table' }, [
				el( 'thead', null, el( 'tr', null, [
					el( 'th', { text: T.colPage } ),
					el( 'th', { class: 'num', text: T.colVisits } ),
					el( 'th', { class: 'num', text: T.colReads } ),
					el( 'th', { text: T.colSources } )
				] ) ),
				el( 'tbody', null, r.pages.map( function ( p ) {
					return el( 'tr', null, [
						el( 'td', null, el( 'div', { class: 'rawi-page' }, [
							p.url ? el( 'a', { href: p.url, target: '_blank', rel: 'noopener', text: p.title } ) : p.title,
							p.edit_url ? el( 'div', { class: 'rawi-row-actions' }, el( 'a', { href: p.edit_url, text: T.edit } ) ) : null
						] ) ),
						el( 'td', { class: 'num' }, el( 'b', { text: n( p.visits ) } ) ),
						el( 'td', { class: 'num', text: n( p.reads ) } ),
						el( 'td', { class: 'rawi-chips' }, p.sources.map( function ( src ) {
							return el( 'span', { class: 'rawi-chip', style: '--chip:#6d5efc' }, src );
						} ) )
					] );
				} ) )
			] ) )
			: null;

		return el( 'section', { class: 'rawi-card rawi-card--referrals' }, [
			el( 'header', { class: 'rawi-card__head' }, el( 'div', null, [
				el( 'h2', null, [ el( 'span', { class: 'rawi-spark-icon', 'aria-hidden': 'true' }, '✦ ' ), T.aiVisitors ] ),
				el( 'p', { class: 'rawi-card__hint', text: T.aiVisitorsHint } )
			] ) ),
			kpis,
			r.series.series.length ? stackedChart( r.series, 'ref:' ) : null,
			pages ? el( 'h3', { class: 'rawi-subhead', text: T.landingPages } ) : null,
			pages
		] );
	}

	/* ------------------------------------------------------------------ *
	 * AI readiness
	 * ------------------------------------------------------------------ */

	function scoreLevel( score ) {
		return score >= 80 ? 'good' : score >= 50 ? 'fair' : 'poor';
	}

	function scoreRing( score ) {
		var size = 132;
		var r = 54;
		var circ = 2 * Math.PI * r;
		var color = { good: '#12b76a', fair: '#f79009', poor: '#f04438' }[ scoreLevel( score ) ];

		return el( 'div', { class: 'rawi-ring', dir: 'ltr' }, svg( 'svg', { viewBox: '0 0 ' + size + ' ' + size, width: size, height: size }, [
			svg( 'circle', { cx: size / 2, cy: size / 2, r: r, fill: 'none', stroke: '#f2f4f7', 'stroke-width': 12 } ),
			svg( 'circle', {
				cx: size / 2,
				cy: size / 2,
				r: r,
				fill: 'none',
				stroke: color,
				'stroke-width': 12,
				'stroke-linecap': 'round',
				'stroke-dasharray': ( ( score / 100 ) * circ ).toFixed( 2 ) + ' ' + circ.toFixed( 2 ),
				transform: 'rotate(-90 ' + size / 2 + ' ' + size / 2 + ')'
			} ),
			svg( 'text', { x: size / 2, y: size / 2 + 6, 'text-anchor': 'middle', class: 'rawi-ring__value' }, String( score ) ),
			svg( 'text', { x: size / 2, y: size / 2 + 26, 'text-anchor': 'middle', class: 'rawi-donut__label' }, '/ 100' )
		] ) );
	}

	function issueLabel( key ) {
		return D.readiness[ key ] ? D.readiness[ key ][ 0 ] : key;
	}

	function readinessCard() {
		var s = state.data.readiness;

		if ( ! s || ! s.scored ) {
			return card( T.readiness, T.readinessHint, empty( T.notScored ) );
		}

		var total = s.buckets.good + s.buckets.fair + s.buckets.poor;
		var bar = function ( key, label, color ) {
			var value = s.buckets[ key ];
			return el( 'div', { class: 'rawi-bucket' }, [
				el( 'div', { class: 'rawi-coverage__head' }, [ el( 'span', { text: label } ), el( 'b', { text: n( value ) } ) ] ),
				meter( total ? value / total : 0, color )
			] );
		};

		var summary = el( 'div', { class: 'rawi-readiness__summary' }, [
			el( 'div', { class: 'rawi-readiness__ring' }, [
				scoreRing( s.average ),
				el( 'div', { class: 'rawi-muted', text: T.avgScore } )
			] ),
			el( 'div', { class: 'rawi-readiness__buckets' }, [
				bar( 'good', T.scoreGood, '#12b76a' ),
				bar( 'fair', T.scoreFair, '#f79009' ),
				bar( 'poor', T.scorePoor, '#f04438' ),
				el( 'p', { class: 'rawi-muted', text: fmt( T.scored, n( s.scored ) ) + ( D.warmTotal > s.scored ? ' · ' + T.unscoredHint : '' ) } )
			] )
		] );

		var common = s.common.length
			? el( 'div', null, [
				el( 'h3', { class: 'rawi-subhead', text: T.commonIssues } ),
				el( 'ul', { class: 'rawi-issues' }, s.common.slice( 0, 6 ).map( function ( item ) {
					var hint = D.readiness[ item.key ] ? D.readiness[ item.key ][ 1 ] : '';
					return el( 'li', null, [
						el( 'div', null, [ el( 'strong', { text: issueLabel( item.key ) } ), el( 'div', { class: 'rawi-muted', text: hint } ) ] ),
						el( 'span', { class: 'rawi-pill rawi-pill--warn', text: fmt( T.pagesAffected, n( item.count ) ) } )
					] );
				} ) )
			] )
			: el( 'div' );

		var worst = s.worst.length
			? el( 'div', null, [
				el( 'h3', { class: 'rawi-subhead', text: T.fixFirst } ),
				el( 'ul', { class: 'rawi-worst' }, s.worst.map( function ( w ) {
					return el( 'li', null, [
						el( 'span', { class: 'rawi-score rawi-score--' + scoreLevel( w.score ), text: String( w.score ) } ),
						el( 'div', { class: 'rawi-worst__main' }, [
							w.edit_url ? el( 'a', { href: w.edit_url, text: w.title } ) : el( 'span', { text: w.title } ),
							el( 'div', { class: 'rawi-chips' }, w.issues.map( function ( key ) {
								return el( 'span', { class: 'rawi-chip', style: '--chip:#f79009' }, issueLabel( key ) );
							} ) )
						] )
					] );
				} ) )
			] )
			: el( 'div' );

		return card( T.readiness, T.readinessHint, [ summary, el( 'div', { class: 'rawi-grid rawi-grid--2 rawi-readiness__lists' }, [ common, worst ] ) ], { cls: 'rawi-card--readiness' } );
	}

	/* ------------------------------------------------------------------ *
	 * Page assembly
	 * ------------------------------------------------------------------ */

	function toolbar() {
		var ranges = el( 'div', { class: 'rawi-segment', role: 'group' }, [ 1, 7, 30, 90, 365 ].map( function ( days ) {
			return el( 'button', {
				type: 'button',
				class: days === state.range ? 'is-active' : '',
				'aria-pressed': days === state.range ? 'true' : 'false',
				onclick: function () {
					load( days );
				}
			}, T[ 'range' + days ] );
		} ) );

		var liveToggle = el( 'label', { class: 'rawi-live' + ( state.live ? ' is-on' : '' ) }, [
			el( 'input', {
				type: 'checkbox',
				checked: state.live ? 'checked' : null,
				onchange: function ( evt ) {
					setLive( evt.target.checked );
					liveToggle.classList.toggle( 'is-on', evt.target.checked );
				}
			} ),
			el( 'span', { class: 'rawi-live__pulse' } ),
			T.liveOn,
			el( 'span', { class: 'rawi-live__count' } )
		] );

		return el( 'div', { class: 'rawi-toolbar' }, [
			ranges,
			el( 'div', { class: 'rawi-toolbar__end' }, [
				liveToggle,
				el( 'button', { type: 'button', class: 'button', onclick: function () { load( state.range ); } }, T.refresh ),
				el( 'a', { class: 'button', href: state.exportUrl || D.exportUrl }, T.export ),
				el( 'a', { class: 'button', href: D.logUrl }, T.openLog )
			] )
		] );
	}

	function kpiGrid() {
		var k = state.data.kpis;
		var p = state.data.previous;
		var totals = state.data.series.buckets.map( function ( b, i ) {
			return sum( state.data.series.series.map( function ( s ) {
				return s.values[ i ];
			} ) );
		} );

		return el( 'div', { class: 'rawi-kpis' }, [
			kpi( {
				label: T.requests,
				value: c( k.requests ),
				exact: n( k.requests ),
				delta: delta( k.requests, p.requests ),
				note: k.not_modified ? fmt( T.conditional, n( k.not_modified ) ) : ( k.llms ? fmt( T.llmsHits, n( k.llms ) ) : T.vsPrev ),
				spark: sparkline( totals, '#6d5efc' ),
				accent: true
			} ),
			kpi( {
				label: T.agents,
				value: n( k.agents ),
				delta: delta( k.agents, p.agents ),
				note: fmt( T.clientsNote, n( k.clients ) )
			} ),
			kpi( {
				label: T.pages,
				value: n( k.pages ),
				delta: delta( k.pages, p.pages ),
				note: T.pagesNote
			} ),
			kpi( {
				label: T.tokensSaved,
				value: c( k.tokens_saved ),
				exact: n( k.tokens_saved ),
				delta: delta( k.tokens_saved, p.tokens_saved ),
				note: null !== k.saving_pct ? fmt( T.lighter, pct( k.saving_pct ) ) : T.measuring
			} ),
			kpi( {
				label: T.tokensServed,
				value: c( k.md_tokens ),
				exact: n( k.md_tokens ),
				delta: delta( k.md_tokens, p.md_tokens )
			} ),
			kpi( {
				label: T.cacheRate,
				value: null !== k.cache_rate ? pct( k.cache_rate ) : '—',
				note: T.servedFromCache
			} ),
			kpi( {
				label: T.avgGen,
				value: null !== k.avg_ms ? fmt( T.ms, n( k.avg_ms ) ) : '—',
				note: T.perMiss
			} ),
			kpi( {
				label: T.verified,
				value: D.verifyOn ? n( k.verified ) : '—',
				note: D.verifyOn ? ( k.spoofed ? el( 'span', { class: 'rawi-bad', text: fmt( T.spoofedNote, n( k.spoofed ) ) } ) : ' ' ) : T.verifyOff
			} )
		] );
	}

	function render() {
		var data = state.data;
		root.innerHTML = '';
		root.appendChild( toolbar() );

		if ( ! data.kpis.requests && ! data.lifetime.requests ) {
			root.appendChild( el( 'div', { class: 'rawi-card rawi-hero-empty' }, empty( T.noData, T.noDataHint ) ) );
			root.appendChild( el( 'div', { class: 'rawi-grid rawi-grid--2' }, [ healthCard(), coverageCard() ] ) );
			root.appendChild( readinessCard() );
			return;
		}

		root.appendChild( kpiGrid() );

		root.appendChild( card( T.requestsOver, T.requestsHint, data.series.series.length ? stackedChart( data.series, 'agent:' ) : empty( T.noData ), { cls: 'rawi-card--chart' } ) );

		var referrals = referralsSection();
		if ( referrals ) {
			root.appendChild( referrals );
		}

		var kindItems = data.kinds.map( function ( k ) {
			return { label: D.kinds[ k.key ] || k.key, value: k.hits, color: KIND_COLORS[ k.key ] || KIND_COLORS.other };
		} );
		var routeItems = data.routes.map( function ( r ) {
			return { label: D.routes[ r.key ] || r.key, value: r.hits, color: ROUTE_COLORS[ r.key ] || '#a3acc2' };
		} );
		var opItems = data.operators.slice( 0, 6 ).map( function ( o, i ) {
			return { label: '__unknown' === o.key ? T.unknownOperator : o.key, value: o.hits, color: PALETTE[ i % 6 ] };
		} );

		root.appendChild( el( 'div', { class: 'rawi-grid rawi-grid--3' }, [
			card( T.whoReading, null, kindItems.length ? donut( kindItems, T.requestsShort ) : empty( T.noData ) ),
			card( T.operators, null, opItems.length ? donut( opItems, T.requestsShort ) : empty( T.noData ) ),
			card( T.howAsked, null, routeItems.length ? donut( routeItems, T.requestsShort ) : empty( T.noData ) )
		] ) );

		var agentsHolder = el( 'div' );
		agentsHolder.appendChild( data.agents.length ? agentsTable() : empty( T.noData ) );

		root.appendChild( el( 'div', { class: 'rawi-grid rawi-grid--wide' }, [
			card( T.agentsTable, null, agentsHolder, {
				actions: [ filterInput( 'agentFilter', function () {
					agentsHolder.innerHTML = '';
					agentsHolder.appendChild( agentsTable() );
				} ) ]
			} ),
			card( T.whenActive, T.whenHint, heatmap( data.heatmap ) )
		] ) );

		var pagesHolder = el( 'div' );
		pagesHolder.appendChild( data.pages.length ? pagesTable() : empty( T.noData ) );

		root.appendChild( card( T.topPages, T.topPagesHint, pagesHolder, {
			actions: [ filterInput( 'pageFilter', function () {
				pagesHolder.innerHTML = '';
				pagesHolder.appendChild( pagesTable() );
			} ) ]
		} ) );

		root.appendChild( el( 'div', { class: 'rawi-grid rawi-grid--feed' }, [
			card( T.live, null, liveFeed(), { cls: 'rawi-card--feed' } ),
			el( 'div', { class: 'rawi-stack' }, [ coverageCard(), missingCard() ] )
		] ) );

		root.appendChild( readinessCard() );
		root.appendChild( healthCard() );

		var life = data.lifetime;
		if ( life.first_seen ) {
			var since;
			try {
				since = new Intl.DateTimeFormat( locale, { dateStyle: 'medium', numberingSystem: 'latn' } ).format( new Date( life.first_seen ) );
			} catch ( e ) {
				since = life.first_seen.slice( 0, 10 );
			}
			root.appendChild( el( 'p', { class: 'rawi-lifetime', text: fmt( T.lifetime, n( life.requests ), c( life.tokens ), since ) } ) );
		}
	}

	function load( days ) {
		root.classList.add( 'is-loading' );
		post( 'rawi_dashboard', { range: days } ).then( function ( res ) {
			state.range = days;
			state.data = res.data;
			state.exportUrl = res.exportUrl;
			render();
			try {
				var url = new URL( window.location.href );
				url.searchParams.set( 'range', String( days ) );
				window.history.replaceState( null, '', url.toString() );
			} catch ( e ) {}
		} ).catch( function () {
			window.alert( T.error );
		} ).then( function () {
			root.classList.remove( 'is-loading' );
		} );
	}

	render();

	try {
		if ( '1' === window.localStorage.getItem( 'rawiLive' ) ) {
			setLive( true );
			var toggle = root.querySelector( '.rawi-live input' );
			if ( toggle ) {
				toggle.checked = true;
				toggle.parentNode.classList.add( 'is-on' );
			}
		}
	} catch ( e ) {}

	document.addEventListener( 'visibilitychange', function () {
		if ( state.live ) {
			clearInterval( state.liveTimer );
			if ( ! document.hidden ) {
				poll();
				state.liveTimer = setInterval( poll, 10000 );
			}
		}
	} );

	if ( window.location.hash === '#rawi-health' ) {
		var target = document.getElementById( 'rawi-health' );
		if ( target ) {
			target.scrollIntoView( { behavior: 'smooth' } );
		}
	}
}() );
