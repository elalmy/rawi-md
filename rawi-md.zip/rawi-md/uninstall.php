<?php
/**
 * Removes everything the plugin created.
 *
 * @package RawiMD
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Clean up a single site.
 *
 * @return void
 */
function rawi_uninstall_site() {
	global $wpdb, $wp_filesystem;

	foreach ( array( 'rawi_settings', 'rawi_db_version', 'rawi_version', 'rawi_metrics_since', 'rawi_ip_lists', 'rawi_updated_from', 'rawi_flush_rewrite' ) as $rawi_option ) {
		delete_option( $rawi_option );
	}

	delete_transient( 'rawi_llms_txt' );

	// Per-post data written by 1.3.0: opt-out flag, HTML size, readiness.
	foreach ( array( '_rawi_exclude', '_rawi_html_metrics', '_rawi_readiness', '_rawi_readiness_score' ) as $rawi_meta ) {
		delete_post_meta_by_key( $rawi_meta );
	}

	foreach ( array( 'rawi_requests', 'rawi_referrals' ) as $rawi_table ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . $rawi_table ) );
	}

	// Scheduled events live per site on a network.
	wp_clear_scheduled_hook( 'rawi_daily_maintenance' );
	wp_clear_scheduled_hook( 'rawi_refresh_ip_lists' );
	wp_unschedule_hook( 'rawi_measure_html' );
	wp_unschedule_hook( 'rawi_warm_post' );

	$uploads = wp_get_upload_dir();
	$dir     = trailingslashit( $uploads['basedir'] ) . 'rawi-md';

	if ( is_multisite() ) {
		$dir .= '/' . get_current_blog_id();
	}

	if ( ! $wp_filesystem || ! $wp_filesystem->is_dir( $dir ) ) {
		return;
	}

	$wp_filesystem->delete( $dir, true );
}

require_once ABSPATH . 'wp-admin/includes/file.php';

// Without working filesystem credentials the cached files stay behind, which
// is harmless: they are regenerable output, not data.
WP_Filesystem();

if ( is_multisite() ) {
	$rawi_sites = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);

	foreach ( $rawi_sites as $rawi_site_id ) {
		switch_to_blog( $rawi_site_id );
		rawi_uninstall_site();
		restore_current_blog();
	}
} else {
	rawi_uninstall_site();
}

delete_metadata( 'user', 0, 'rawi_range', '', true );
