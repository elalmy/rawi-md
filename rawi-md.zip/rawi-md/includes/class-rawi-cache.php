<?php
/**
 * File-based Markdown cache.
 *
 * Files live under uploads/ rather than the options table, so a large site
 * does not bloat wp_options or autoloaded memory.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Cache
 */
class RAWI_Cache {

	const DIRNAME = 'rawi-md';

	/**
	 * Marker proving the .htaccess was written by a version that knows the
	 * Apache 2.4 syntax.
	 */
	const HTACCESS_MARKER = '# rawi-md 1.3';

	/**
	 * Register invalidation hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'save_post', array( __CLASS__, 'invalidate_post' ), 10, 1 );
		add_action( 'deleted_post', array( __CLASS__, 'invalidate_post' ), 10, 1 );
		add_action( 'trashed_post', array( __CLASS__, 'invalidate_post' ), 10, 1 );
		add_action( 'untrashed_post', array( __CLASS__, 'invalidate_post' ), 10, 1 );
		add_action( 'set_object_terms', array( __CLASS__, 'invalidate_post' ), 10, 1 );

		// Approved comments change a product's rating and review count.
		add_action( 'wp_update_comment_count', array( __CLASS__, 'invalidate_post' ), 10, 1 );

		// WooCommerce: a scheduled sale starting or ending saves the product
		// through the data store, which fires these and not save_post.
		add_action( 'woocommerce_update_product', array( __CLASS__, 'invalidate_post' ), 10, 1 );
		add_action( 'woocommerce_update_product_variation', array( __CLASS__, 'invalidate_variation' ), 10, 1 );
		add_action( 'woocommerce_variation_set_stock', array( __CLASS__, 'invalidate_from_product' ), 10, 1 );
		add_action( 'woocommerce_product_set_stock', array( __CLASS__, 'invalidate_from_product' ), 10, 1 );

		// A renamed category or tag appears in every document that uses it.
		add_action( 'edited_term', array( __CLASS__, 'flush' ) );
		add_action( 'delete_term', array( __CLASS__, 'flush' ) );

		// The author name is in the frontmatter.
		add_action( 'profile_update', array( __CLASS__, 'maybe_flush_for_author' ), 10, 2 );

		add_action( 'switch_theme', array( __CLASS__, 'flush' ) );
		add_action( 'update_option_' . RAWI_Settings::OPTION, array( __CLASS__, 'flush' ) );
		add_action( 'update_option_blogname', array( __CLASS__, 'flush_llms' ) );
		add_action( 'update_option_blogdescription', array( __CLASS__, 'flush_llms' ) );
	}

	/**
	 * Absolute path to the cache directory.
	 *
	 * @return string
	 */
	public static function directory() {
		$uploads = wp_get_upload_dir();
		$base    = trailingslashit( $uploads['basedir'] ) . self::DIRNAME;

		if ( is_multisite() ) {
			$base .= '/' . get_current_blog_id();
		}

		return $base;
	}

	/**
	 * Create the cache directory and block direct access to it.
	 *
	 * @param bool $refresh Rewrite an .htaccess left by an older version.
	 * @return bool
	 */
	public static function prepare_directory( $refresh = false ) {
		$dir = self::directory();

		if ( ! file_exists( $dir ) ) {
			if ( ! wp_mkdir_p( $dir ) ) {
				return false;
			}
		}

		$index = trailingslashit( $dir ) . 'index.html';
		if ( ! file_exists( $index ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			@file_put_contents( $index, '' );
		}

		$htaccess = trailingslashit( $dir ) . '.htaccess';
		$write    = ! file_exists( $htaccess );

		if ( ! $write && $refresh ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$current = (string) @file_get_contents( $htaccess );
			$write   = ( false === strpos( $current, self::HTACCESS_MARKER ) );
		}

		if ( $write ) {
			// Apache 2.2 only understands "Deny from all"; 2.4 ignores it
			// unless mod_access_compat is loaded. Send both.
			$rules = self::HTACCESS_MARKER . "\n"
				. "Options -Indexes\n"
				. "<IfModule mod_authz_core.c>\n"
				. "\tRequire all denied\n"
				. "</IfModule>\n"
				. "<IfModule !mod_authz_core.c>\n"
				. "\tOrder deny,allow\n"
				. "\tDeny from all\n"
				. "</IfModule>\n";

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			@file_put_contents( $htaccess, $rules );
		}

		return true;
	}

	/**
	 * Cache key for a post, tied to the plugin version and site URL.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private static function key( $post_id ) {
		return md5( (string) $post_id . '|' . RAWI_VERSION . '|' . get_option( 'siteurl' ) );
	}

	/**
	 * Cache file path for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private static function path( $post_id ) {
		return trailingslashit( self::directory() ) . absint( $post_id ) . '-' . self::key( $post_id ) . '.md';
	}

	/**
	 * Read a cached document.
	 *
	 * @param int $post_id Post ID.
	 * @return string|false
	 */
	public static function get( $post_id ) {
		if ( ! RAWI_Settings::get( 'cache_enabled' ) ) {
			return false;
		}

		$path = self::path( $post_id );

		if ( ! is_readable( $path ) ) {
			return false;
		}

		$ttl = (int) RAWI_Settings::get( 'cache_ttl' );

		if ( $ttl > 0 ) {
			$age = time() - (int) filemtime( $path );

			if ( $age > $ttl ) {
				return false;
			}
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$contents = @file_get_contents( $path );

		return ( false === $contents || '' === $contents ) ? false : $contents;
	}

	/**
	 * When the cached document for a post was written.
	 *
	 * @param int $post_id Post ID.
	 * @return int Unix time, 0 when not cached.
	 */
	public static function mtime( $post_id ) {
		$path = self::path( $post_id );

		return file_exists( $path ) ? (int) filemtime( $path ) : 0;
	}

	/**
	 * Is a document for this post cached right now?
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function has( $post_id ) {
		return file_exists( self::path( $post_id ) );
	}

	/**
	 * Write a document to the cache.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $document Markdown document.
	 * @return void
	 */
	public static function set( $post_id, $document ) {
		if ( ! RAWI_Settings::get( 'cache_enabled' ) ) {
			return;
		}

		if ( ! self::prepare_directory() ) {
			return;
		}

		$path = self::path( $post_id );
		$temp = $path . '.' . wp_generate_password( 6, false ) . '.tmp';

		// Write then rename, so a concurrent reader never sees a half-written file.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false !== @file_put_contents( $temp, $document, LOCK_EX ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			if ( ! @rename( $temp, $path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				@unlink( $temp );
			}
		}
	}

	/**
	 * Drop the cached document for one post.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function invalidate_post( $post_id ) {
		$post_id = absint( $post_id );

		if ( ! $post_id ) {
			return;
		}

		$path = self::path( $post_id );

		if ( file_exists( $path ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			@unlink( $path );
		}

		self::flush_llms();
	}

	/**
	 * A variation changed: the parent product's document is the stale one.
	 *
	 * @param int $variation_id Variation ID.
	 * @return void
	 */
	public static function invalidate_variation( $variation_id ) {
		$parent = wp_get_post_parent_id( (int) $variation_id );

		if ( $parent ) {
			self::invalidate_post( $parent );
		}
	}

	/**
	 * Invalidate from a WooCommerce product object or ID.
	 *
	 * @param mixed $product Product object or ID.
	 * @return void
	 */
	public static function invalidate_from_product( $product ) {
		if ( is_object( $product ) && method_exists( $product, 'get_id' ) ) {
			self::invalidate_post( $product->get_id() );

			if ( method_exists( $product, 'get_parent_id' ) && $product->get_parent_id() ) {
				self::invalidate_post( $product->get_parent_id() );
			}
			return;
		}

		self::invalidate_post( $product );
	}

	/**
	 * Flush when a user's public name changed.
	 *
	 * @param int     $user_id  User ID.
	 * @param WP_User $old_data User before the update.
	 * @return void
	 */
	public static function maybe_flush_for_author( $user_id, $old_data = null ) {
		$user = get_userdata( $user_id );

		if ( ! $user || ! $old_data instanceof WP_User ) {
			return;
		}

		if ( $user->display_name !== $old_data->display_name ) {
			self::flush();
		}
	}

	/**
	 * Drop the cached llms.txt.
	 *
	 * @return void
	 */
	public static function flush_llms() {
		delete_transient( 'rawi_llms_txt' );
	}

	/**
	 * Delete every cached document.
	 *
	 * @return int Number of files removed.
	 */
	public static function flush() {
		self::flush_llms();

		$dir = self::directory();

		if ( ! is_dir( $dir ) ) {
			return 0;
		}

		$files = glob( trailingslashit( $dir ) . '*.md' );

		if ( ! is_array( $files ) ) {
			return 0;
		}

		$count = 0;

		foreach ( $files as $file ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			if ( @unlink( $file ) ) {
				$count++;
			}
		}

		return $count;
	}

	/**
	 * Remove files no current request can ever read: documents keyed to an
	 * older plugin version or site URL, and temp files from an interrupted
	 * write. Valid documents are kept.
	 *
	 * @return int Number of files removed.
	 */
	public static function remove_stale() {
		$dir = self::directory();

		if ( ! is_dir( $dir ) ) {
			return 0;
		}

		$removed = 0;
		$files   = glob( trailingslashit( $dir ) . '*.md' );

		foreach ( is_array( $files ) ? $files : array() as $file ) {
			if ( ! preg_match( '/^(\d+)-([a-f0-9]{32})\.md$/', basename( $file ), $m ) ) {
				continue;
			}

			if ( self::key( (int) $m[1] ) !== $m[2] ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				if ( @unlink( $file ) ) {
					$removed++;
				}
			}
		}

		$temps = glob( trailingslashit( $dir ) . '*.tmp' );

		foreach ( is_array( $temps ) ? $temps : array() as $file ) {
			if ( time() - (int) filemtime( $file ) > HOUR_IN_SECONDS ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				if ( @unlink( $file ) ) {
					$removed++;
				}
			}
		}

		return $removed;
	}

	/**
	 * Number of cached documents currently stored.
	 *
	 * @return int
	 */
	public static function count() {
		$dir = self::directory();

		if ( ! is_dir( $dir ) ) {
			return 0;
		}

		$files = glob( trailingslashit( $dir ) . '*.md' );

		return is_array( $files ) ? count( $files ) : 0;
	}

	/**
	 * Count and total size of cached documents.
	 *
	 * @return array{files:int,bytes:int}
	 */
	public static function usage() {
		$dir   = self::directory();
		$bytes = 0;
		$files = is_dir( $dir ) ? glob( trailingslashit( $dir ) . '*.md' ) : array();
		$files = is_array( $files ) ? $files : array();

		foreach ( $files as $file ) {
			$bytes += (int) filesize( $file );
		}

		return array(
			'files' => count( $files ),
			'bytes' => $bytes,
		);
	}

	/**
	 * Can the cache directory be written?
	 *
	 * @return bool
	 */
	public static function is_writable() {
		$dir = self::directory();

		if ( ! is_dir( $dir ) && ! self::prepare_directory() ) {
			return false;
		}

		return wp_is_writable( $dir );
	}
}
