<?php
/**
 * Accept header parsing, following RFC 9110 content negotiation rules.
 *
 * This is deliberately strict. A naive strpos() check on the Accept header
 * breaks real browsers, because every browser sends a wildcard range that
 * would otherwise match anything.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Accept
 */
class RAWI_Accept {

	/**
	 * Media types treated as a request for Markdown.
	 *
	 * @return string[]
	 */
	public static function markdown_types() {
		return array( 'text/markdown', 'text/x-markdown' );
	}

	/**
	 * Parse an Accept header into an ordered list of media ranges.
	 *
	 * Each entry: array( 'type' => 'text', 'subtype' => 'html', 'q' => 1.0, 'specificity' => 2 ).
	 * Specificity: 2 = exact type/subtype, 1 = type/*, 0 = *\/*.
	 *
	 * @param string $header Raw Accept header value.
	 * @return array[]
	 */
	public static function parse( $header ) {
		$ranges = array();

		if ( ! is_string( $header ) || '' === trim( $header ) ) {
			return $ranges;
		}

		// Guard against absurdly long headers.
		if ( strlen( $header ) > 2048 ) {
			$header = substr( $header, 0, 2048 );
		}

		$parts = explode( ',', $header );

		foreach ( $parts as $part ) {
			$part = trim( $part );

			if ( '' === $part ) {
				continue;
			}

			$bits  = explode( ';', $part );
			$media = strtolower( trim( array_shift( $bits ) ) );

			if ( '' === $media || false === strpos( $media, '/' ) ) {
				continue;
			}

			list( $type, $subtype ) = array_pad( explode( '/', $media, 2 ), 2, '' );

			$type    = trim( $type );
			$subtype = trim( $subtype );

			if ( '' === $type || '' === $subtype ) {
				continue;
			}

			$q = 1.0;

			foreach ( $bits as $bit ) {
				$bit = trim( $bit );

				if ( 0 === stripos( $bit, 'q=' ) ) {
					$value = substr( $bit, 2 );
					if ( is_numeric( $value ) ) {
						$q = (float) $value;
					}
					break;
				}
			}

			if ( $q < 0 ) {
				$q = 0.0;
			}

			if ( $q > 1 ) {
				$q = 1.0;
			}

			if ( '*' === $type && '*' === $subtype ) {
				$specificity = 0;
			} elseif ( '*' === $subtype ) {
				$specificity = 1;
			} else {
				$specificity = 2;
			}

			$ranges[] = array(
				'type'        => $type,
				'subtype'     => $subtype,
				'q'           => $q,
				'specificity' => $specificity,
			);
		}

		return $ranges;
	}

	/**
	 * Resolve the quality value the client assigned to a concrete media type.
	 *
	 * The most specific matching range wins, per RFC 9110 section 12.5.1.
	 *
	 * @param array[] $ranges Parsed ranges from self::parse().
	 * @param string  $type   Concrete media type, e.g. "text/markdown".
	 * @return float
	 */
	public static function quality_for( array $ranges, $type ) {
		list( $want_type, $want_subtype ) = array_pad( explode( '/', strtolower( $type ), 2 ), 2, '' );

		$best_specificity = -1;
		$best_q           = 0.0;

		foreach ( $ranges as $range ) {
			$matches = false;

			if ( 2 === $range['specificity'] ) {
				$matches = ( $range['type'] === $want_type && $range['subtype'] === $want_subtype );
			} elseif ( 1 === $range['specificity'] ) {
				$matches = ( $range['type'] === $want_type );
			} else {
				$matches = true;
			}

			if ( $matches && $range['specificity'] > $best_specificity ) {
				$best_specificity = $range['specificity'];
				$best_q           = $range['q'];
			}
		}

		return $best_q;
	}

	/**
	 * Does the current request explicitly prefer Markdown over HTML?
	 *
	 * Requires an exact text/markdown range. A bare wildcard range never
	 * counts, otherwise every browser and every curl default would be served
	 * Markdown.
	 *
	 * @param string|null $header Optional raw header, defaults to the request.
	 * @return bool
	 */
	public static function prefers_markdown( $header = null ) {
		if ( null === $header ) {
			$header = isset( $_SERVER['HTTP_ACCEPT'] )
				? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT'] ) )
				: '';
		}

		$ranges = self::parse( $header );

		if ( empty( $ranges ) ) {
			return false;
		}

		// An exact text/markdown (or text/x-markdown) range must be present.
		$has_exact = false;

		foreach ( $ranges as $range ) {
			if ( 2 !== $range['specificity'] ) {
				continue;
			}

			$media = $range['type'] . '/' . $range['subtype'];

			if ( in_array( $media, self::markdown_types(), true ) && $range['q'] > 0 ) {
				$has_exact = true;
				break;
			}
		}

		if ( ! $has_exact ) {
			return false;
		}

		$md_q = 0.0;

		foreach ( self::markdown_types() as $media ) {
			$md_q = max( $md_q, self::quality_for( $ranges, $media ) );
		}

		$html_q = max(
			self::quality_for( $ranges, 'text/html' ),
			self::quality_for( $ranges, 'application/xhtml+xml' )
		);

		return ( $md_q > 0 && $md_q >= $html_q );
	}
}
