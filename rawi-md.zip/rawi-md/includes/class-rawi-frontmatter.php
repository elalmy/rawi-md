<?php
/**
 * YAML frontmatter generation.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Frontmatter
 */
class RAWI_Frontmatter {

	/**
	 * Build the frontmatter block for a post.
	 *
	 * @param WP_Post $post Post object.
	 * @return string Empty string when frontmatter is disabled.
	 */
	public static function build( WP_Post $post ) {
		if ( ! RAWI_Settings::get( 'frontmatter_enabled' ) ) {
			return '';
		}

		$enabled = RAWI_Settings::get( 'frontmatter_fields' );
		$enabled = is_array( $enabled ) ? $enabled : array();

		$data = array();

		if ( in_array( 'title', $enabled, true ) ) {
			$data['title'] = wp_strip_all_tags( get_the_title( $post ) );
		}

		if ( in_array( 'description', $enabled, true ) ) {
			$description = self::description( $post );
			if ( '' !== $description ) {
				$data['description'] = $description;
			}
		}

		if ( in_array( 'url', $enabled, true ) ) {
			$data['url'] = get_permalink( $post );
		}

		if ( in_array( 'date_published', $enabled, true ) ) {
			$data['date_published'] = get_post_time( 'c', true, $post );
		}

		if ( in_array( 'date_modified', $enabled, true ) ) {
			$data['date_modified'] = get_post_modified_time( 'c', true, $post );
		}

		if ( in_array( 'author', $enabled, true ) ) {
			$author = get_the_author_meta( 'display_name', $post->post_author );
			if ( $author ) {
				$data['author'] = $author;
			}
		}

		if ( in_array( 'categories', $enabled, true ) ) {
			$terms = self::term_names( $post, array( 'category', 'product_cat' ) );
			if ( ! empty( $terms ) ) {
				$data['categories'] = $terms;
			}
		}

		if ( in_array( 'tags', $enabled, true ) ) {
			$terms = self::term_names( $post, array( 'post_tag', 'product_tag' ) );
			if ( ! empty( $terms ) ) {
				$data['tags'] = $terms;
			}
		}

		if ( in_array( 'language', $enabled, true ) ) {
			$data['language'] = str_replace( '_', '-', (string) get_locale() );
		}

		if ( in_array( 'image', $enabled, true ) && 'product' !== $post->post_type ) {
			$thumb = get_the_post_thumbnail_url( $post, 'full' );
			if ( $thumb ) {
				$data['image'] = $thumb;
			}
		}

		if ( in_array( 'word_count', $enabled, true ) ) {
			$text = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
			$data['word_count'] = (int) count( preg_split( '/\s+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY ) );
		}

		if ( RAWI_Settings::get( 'woo_fields' ) ) {
			$data = array_merge( $data, self::woocommerce_fields( $post ) );
		}

		/**
		 * Filter the frontmatter data before it is serialised.
		 *
		 * @param array   $data Key/value pairs.
		 * @param WP_Post $post The post being rendered.
		 */
		$data = apply_filters( 'rawi_frontmatter_data', $data, $post );

		if ( empty( $data ) ) {
			return '';
		}

		return "---\n" . self::to_yaml( $data ) . "---\n\n";
	}

	/**
	 * Best available description for a post.
	 *
	 * @param WP_Post $post Post object.
	 * @return string
	 */
	private static function description( WP_Post $post ) {
		$candidates = array(
			'yoast'     => get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true ),
			'rank_math' => get_post_meta( $post->ID, 'rank_math_description', true ),
			'seopress'  => get_post_meta( $post->ID, '_seopress_titles_desc', true ),
			'excerpt'   => $post->post_excerpt,
		);

		foreach ( $candidates as $source => $candidate ) {
			$candidate = self::resolve_seo_variables( (string) $candidate, $source, $post );
			$candidate = trim( wp_strip_all_tags( $candidate ) );

			// A template the SEO plugin could not expand here is noise, not a
			// description: "%%title%% %%sep%% %%sitename%%" helps nobody.
			if ( '' === $candidate || preg_match( '/%%[a-z0-9_]+%%|%[a-z][a-z0-9_]*%/i', $candidate ) ) {
				continue;
			}

			return $candidate;
		}

		$content = trim( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) );

		if ( '' === $content ) {
			return '';
		}

		return wp_trim_words( $content, 30, '…' );
	}

	/**
	 * A description the author actually wrote: an SEO meta description or a
	 * manual excerpt. Unlike description(), never falls back to the content.
	 *
	 * @param WP_Post $post Post object.
	 * @return string
	 */
	public static function explicit_description( WP_Post $post ) {
		$candidates = array(
			'yoast'     => get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true ),
			'rank_math' => get_post_meta( $post->ID, 'rank_math_description', true ),
			'seopress'  => get_post_meta( $post->ID, '_seopress_titles_desc', true ),
			'excerpt'   => $post->post_excerpt,
		);

		foreach ( $candidates as $source => $candidate ) {
			$candidate = trim( wp_strip_all_tags( self::resolve_seo_variables( (string) $candidate, $source, $post ) ) );

			if ( '' !== $candidate && ! preg_match( '/%%[a-z0-9_]+%%|%[a-z][a-z0-9_]*%/i', $candidate ) ) {
				return $candidate;
			}
		}

		// WooCommerce: the short description is the product's summary.
		if ( 'product' === $post->post_type && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $post->ID );

			if ( $product && '' !== trim( wp_strip_all_tags( (string) $product->get_short_description() ) ) ) {
				return trim( wp_strip_all_tags( (string) $product->get_short_description() ) );
			}
		}

		return '';
	}

	/**
	 * Expand the replacement variables SEO plugins allow in descriptions.
	 *
	 * @param string  $text   Raw description.
	 * @param string  $source yoast | rank_math | seopress | excerpt.
	 * @param WP_Post $post   Post object.
	 * @return string
	 */
	private static function resolve_seo_variables( $text, $source, WP_Post $post ) {
		if ( '' === $text || false === strpos( $text, '%' ) ) {
			return $text;
		}

		try {
			if ( 'yoast' === $source && function_exists( 'wpseo_replace_vars' ) ) {
				return (string) wpseo_replace_vars( $text, $post );
			}

			if ( 'rank_math' === $source && class_exists( '\RankMath\Helper' ) && method_exists( '\RankMath\Helper', 'replace_vars' ) ) {
				return (string) \RankMath\Helper::replace_vars( $text, $post );
			}
		} catch ( Throwable $e ) {
			return '';
		}

		return $text;
	}

	/**
	 * Collect term names from the first taxonomy that applies.
	 *
	 * @param WP_Post  $post       Post object.
	 * @param string[] $taxonomies Candidate taxonomies.
	 * @return string[]
	 */
	private static function term_names( WP_Post $post, array $taxonomies ) {
		foreach ( $taxonomies as $taxonomy ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}

			$terms = get_the_terms( $post, $taxonomy );

			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				continue;
			}

			return wp_list_pluck( $terms, 'name' );
		}

		return array();
	}

	/**
	 * WooCommerce product fields.
	 *
	 * These are the fields Cloudflare's edge conversion can never produce,
	 * because they live in post meta rather than in the rendered markup.
	 *
	 * @param WP_Post $post Post object.
	 * @return array
	 */
	private static function woocommerce_fields( WP_Post $post ) {
		if ( 'product' !== $post->post_type || ! function_exists( 'wc_get_product' ) ) {
			return array();
		}

		$product = wc_get_product( $post->ID );

		if ( ! $product ) {
			return array();
		}

		$fields = array();

		$sku = $product->get_sku();
		if ( $sku ) {
			$fields['sku'] = $sku;
		}

		$price = $product->get_price();
		if ( '' !== $price && null !== $price ) {
			$fields['price']    = (string) $price;
			$fields['currency'] = get_woocommerce_currency();
		}

		$regular = $product->get_regular_price();
		$sale    = $product->get_sale_price();

		if ( $product->is_on_sale() && '' !== (string) $regular && (string) $sale !== (string) $regular ) {
			$fields['regular_price'] = (string) $regular;
			$fields['on_sale']       = true;
		}

		if ( $product->is_type( 'variable' ) && method_exists( $product, 'get_variation_price' ) ) {
			$min = (string) $product->get_variation_price( 'min' );
			$max = (string) $product->get_variation_price( 'max' );

			if ( '' !== $min && $min !== $max ) {
				$fields['price_min'] = $min;
				$fields['price_max'] = $max;
			}
		}

		$fields['availability'] = $product->is_in_stock() ? 'in_stock' : 'out_of_stock';

		// The main image URL, taken from meta rather than the rendered gallery
		// markup, so it survives no matter which content source is used.
		$image_id = $product->get_image_id();

		if ( $image_id ) {
			$image = wp_get_attachment_image_url( $image_id, 'full' );

			if ( $image ) {
				$fields['image'] = $image;
			}
		}

		$stock = $product->get_stock_quantity();
		if ( null !== $stock ) {
			$fields['stock_quantity'] = (int) $stock;
		}

		if ( $product->get_rating_count() > 0 ) {
			$fields['rating']       = round( (float) $product->get_average_rating(), 2 );
			$fields['review_count'] = (int) $product->get_review_count();
		}

		return $fields;
	}

	/**
	 * Serialise a flat array to YAML.
	 *
	 * Only scalars and flat lists are supported, which covers everything the
	 * plugin produces and avoids pulling in a YAML library.
	 *
	 * @param array $data Data.
	 * @return string
	 */
	private static function to_yaml( array $data ) {
		$lines = array();

		foreach ( $data as $key => $value ) {
			$key = preg_replace( '/[^a-z0-9_]/i', '_', (string) $key );

			if ( is_array( $value ) ) {
				if ( empty( $value ) ) {
					continue;
				}

				$items = array();
				foreach ( $value as $item ) {
					$items[] = self::scalar( $item );
				}

				$lines[] = $key . ': [' . implode( ', ', $items ) . ']';
				continue;
			}

			$lines[] = $key . ': ' . self::scalar( $value );
		}

		return implode( "\n", $lines ) . "\n";
	}

	/**
	 * Quote a scalar for YAML output.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	private static function scalar( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? 'true' : 'false';
		}

		if ( is_int( $value ) || ( is_float( $value ) && is_finite( $value ) ) ) {
			return (string) $value;
		}

		$value = (string) $value;
		$value = str_replace( array( "\r", "\n", "\t" ), ' ', $value );
		$value = trim( (string) preg_replace( '/\s+/u', ' ', $value ) );

		// Drop the remaining C0 control characters, which YAML forbids raw.
		$value = (string) preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value );

		// Backslash first: in a double-quoted YAML scalar it starts an escape,
		// so "C:\new" would otherwise be read back as "C:" + newline + "ew".
		$value = str_replace( array( '\\', '"' ), array( '\\\\', '\\"' ), $value );

		return '"' . $value . '"';
	}
}
