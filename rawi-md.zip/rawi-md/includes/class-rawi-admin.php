<?php
/**
 * Admin screens: dashboard, request log, settings and server rules.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Admin
 */
class RAWI_Admin {

	const SLUG = 'rawi-md';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'requirement_notice' ) );
		add_action( 'admin_notices', array( __CLASS__, 'upgrade_notice' ) );
		add_action( 'admin_post_rawi_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_rawi_flush_cache', array( __CLASS__, 'handle_flush' ) );
		add_action( 'admin_post_rawi_clear_log', array( __CLASS__, 'handle_clear_log' ) );
		add_action( 'admin_post_rawi_export', array( __CLASS__, 'handle_export' ) );
		add_action( 'wp_ajax_rawi_dashboard', array( __CLASS__, 'ajax_dashboard' ) );
		add_action( 'wp_ajax_rawi_recent', array( __CLASS__, 'ajax_recent' ) );
		add_action( 'wp_ajax_rawi_selftest', array( __CLASS__, 'ajax_selftest' ) );
		add_action( 'wp_ajax_rawi_warm', array( __CLASS__, 'ajax_warm' ) );
		add_action( 'wp_ajax_rawi_dismiss_upgrade', array( __CLASS__, 'ajax_dismiss_upgrade' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard_widget' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( RAWI_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Tell the site owner when PHP is missing the extension this depends on.
	 *
	 * @return void
	 */
	public static function requirement_notice() {
		if ( ! current_user_can( 'activate_plugins' ) || RAWI_Converter::is_available() ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p><strong>%s</strong> %s</p></div>',
			esc_html__( 'Rawi MD is not converting anything.', 'rawi-md' ),
			esc_html__( 'Your PHP build is missing the DOM extension (php-xml), which the converter needs. Ask your host to enable it. Until then the plugin stays out of the way and every request is answered with your normal HTML.', 'rawi-md' )
		);
	}

	/**
	 * One-time note after an update, confirming nothing was lost.
	 *
	 * @return void
	 */
	public static function upgrade_notice() {
		$from = (string) get_option( 'rawi_updated_from', '' );

		if ( '' === $from || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-success is-dismissible rawi-upgrade-notice" data-nonce="%s"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
			esc_attr( wp_create_nonce( 'rawi_dismiss_upgrade' ) ),
			esc_html(
				sprintf(
					/* translators: 1: old version, 2: new version. */
					__( 'Rawi MD updated from %1$s to %2$s.', 'rawi-md' ),
					$from,
					RAWI_VERSION
				)
			),
			esc_html__( 'Your settings and every logged request were kept.', 'rawi-md' ),
			esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ),
			esc_html__( 'Open the new dashboard', 'rawi-md' )
		);
	}

	/**
	 * Hide the update note.
	 *
	 * @return void
	 */
	public static function ajax_dismiss_upgrade() {
		check_ajax_referer( 'rawi_dismiss_upgrade', 'nonce' );

		if ( current_user_can( 'manage_options' ) ) {
			delete_option( 'rawi_updated_from' );
		}

		wp_send_json_success();
	}

	/**
	 * Add the settings link on the plugins screen.
	 *
	 * @param string[] $links Existing links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">' . esc_html__( 'Dashboard', 'rawi-md' ) . '</a>',
			'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=settings' ) ) . '">' . esc_html__( 'Settings', 'rawi-md' ) . '</a>'
		);

		return $links;
	}

	/**
	 * Tabs, in order.
	 *
	 * @return string[]
	 */
	private static function tabs() {
		return array(
			'reports'  => __( 'Dashboard', 'rawi-md' ),
			'log'      => __( 'Request log', 'rawi-md' ),
			'settings' => __( 'Settings', 'rawi-md' ),
			'server'   => __( 'Server rules', 'rawi-md' ),
		);
	}

	/**
	 * Register the menu entry.
	 *
	 * @return void
	 */
	public static function menu() {
		add_menu_page(
			__( 'Rawi MD', 'rawi-md' ),
			__( 'Rawi MD', 'rawi-md' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-editor-code',
			58
		);

		foreach ( self::tabs() as $tab => $label ) {
			add_submenu_page(
				self::SLUG,
				$label,
				$label,
				'manage_options',
				self::SLUG . ( 'reports' === $tab ? '' : '&tab=' . $tab ),
				array( __CLASS__, 'render' )
			);
		}
	}

	/**
	 * Load assets on this plugin's screens, the editor and the WP dashboard.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function assets( $hook ) {
		$hook = (string) $hook;

		if ( in_array( $hook, array( 'post.php', 'post-new.php', 'index.php' ), true ) ) {
			wp_enqueue_style( 'rawi-admin', RAWI_URL . 'assets/admin.css', array(), RAWI_VERSION );
			return;
		}

		// The update notice can appear on any screen, this one included.
		if ( get_option( 'rawi_updated_from' ) ) {
			wp_add_inline_script(
				'common',
				"jQuery(document).on('click','.rawi-upgrade-notice .notice-dismiss',function(){var n=jQuery(this).closest('.rawi-upgrade-notice');jQuery.post(ajaxurl,{action:'rawi_dismiss_upgrade',nonce:n.data('nonce')});});"
			);
		}

		if ( false === strpos( $hook, self::SLUG ) ) {
			return;
		}

		wp_enqueue_style( 'rawi-admin', RAWI_URL . 'assets/admin.css', array(), RAWI_VERSION );

		if ( 'reports' !== self::current_tab() ) {
			return;
		}

		wp_enqueue_script( 'rawi-dashboard', RAWI_URL . 'assets/dashboard.js', array(), RAWI_VERSION, true );

		$range = self::current_range();

		wp_add_inline_script(
			'rawi-dashboard',
			'window.RAWI_DASH = ' . wp_json_encode( self::dashboard_payload( $range ) ) . ';',
			'before'
		);
	}

	/**
	 * Current tab.
	 *
	 * @return string
	 */
	private static function current_tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'reports';

		return array_key_exists( $tab, self::tabs() ) ? $tab : 'reports';
	}

	/**
	 * Range picked on the dashboard, remembered per user.
	 *
	 * @return int
	 */
	private static function current_range() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['range'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return RAWI_Stats::normalise_range( wp_unslash( $_GET['range'] ) );
		}

		$saved = get_user_meta( get_current_user_id(), 'rawi_range', true );

		return RAWI_Stats::normalise_range( $saved ? $saved : 30 );
	}

	/**
	 * Everything the dashboard script needs on first paint.
	 *
	 * @param int $range Range in days.
	 * @return array
	 */
	private static function dashboard_payload( $range ) {
		$routes = array(
			'accept' => __( 'Accept header', 'rawi-md' ),
			'suffix' => __( '.md address', 'rawi-md' ),
			'query'  => __( 'Query string', 'rawi-md' ),
			'llms'   => 'llms.txt',
		);

		return array(
			'ajax'        => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'rawi_dashboard' ),
			'range'       => $range,
			'locale'      => str_replace( '_', '-', get_user_locale() ),
			'rtl'         => is_rtl(),
			'startOfWeek' => (int) get_option( 'start_of_week', 0 ),
			'logEnabled'  => (bool) RAWI_Settings::get( 'log_enabled' ),
			'verifyOn'    => (bool) RAWI_Settings::get( 'verify_bots' ),
			'warmTotal'   => count( RAWI_Tools::warmable_ids() ),
			'logUrl'      => admin_url( 'admin.php?page=' . self::SLUG . '&tab=log' ),
			'settingsUrl' => admin_url( 'admin.php?page=' . self::SLUG . '&tab=settings' ),
			'exportUrl'   => self::export_url( $range ),
			'llmsUrl'     => RAWI_Settings::get( 'llms_enabled' ) ? RAWI_Llms::url() : '',
			'data'        => RAWI_Stats::dashboard( $range ),
			'health'      => RAWI_Tools::health(),
			'kinds'       => RAWI_Agents::kinds(),
			'routes'      => $routes,
			'readiness'   => RAWI_Readiness::labels(),
			'i18n'        => self::strings(),
		);
	}

	/**
	 * CSV export address, unescaped, for use in JavaScript.
	 *
	 * wp_nonce_url() HTML-escapes its result ("&amp;"), which is right in an
	 * attribute printed by PHP but breaks a URL handed to a script.
	 *
	 * @param int $days Range in days, 0 for everything.
	 * @return string
	 */
	private static function export_url( $days ) {
		return add_query_arg(
			array(
				'action'   => 'rawi_export',
				'days'     => absint( $days ),
				'_wpnonce' => wp_create_nonce( 'rawi_export' ),
			),
			admin_url( 'admin-post.php' )
		);
	}

	/**
	 * Translated strings for the dashboard script.
	 *
	 * @return string[]
	 */
	private static function strings() {
		return array(
			'requests'        => __( 'Markdown requests', 'rawi-md' ),
			'agents'          => __( 'Distinct agents', 'rawi-md' ),
			'pages'           => __( 'Pages read', 'rawi-md' ),
			'tokensServed'    => __( 'Tokens delivered', 'rawi-md' ),
			'tokensSaved'     => __( 'Tokens saved', 'rawi-md' ),
			'cacheRate'       => __( 'Cache hit rate', 'rawi-md' ),
			'avgGen'          => __( 'Avg. conversion time', 'rawi-md' ),
			'verified'        => __( 'Verified crawlers', 'rawi-md' ),
			'vsPrev'          => __( 'vs previous period', 'rawi-md' ),
			'newPeriod'       => __( 'new this period', 'rawi-md' ),
			'lighter'         => __( '%s lighter than the HTML page', 'rawi-md' ),
			'measuring'       => __( 'Measuring the HTML pages…', 'rawi-md' ),
			'ms'              => __( '%s ms', 'rawi-md' ),
			'servedFromCache' => __( 'of documents served from cache', 'rawi-md' ),
			'perMiss'         => __( 'per uncached document', 'rawi-md' ),
			'spoofedNote'     => __( '%s requests faked a crawler name', 'rawi-md' ),
			'verifyOff'       => __( 'Verification is off', 'rawi-md' ),
			'clientsNote'     => __( '%s unique clients', 'rawi-md' ),
			'pagesNote'       => __( 'Distinct posts agents opened', 'rawi-md' ),
			'noData'          => __( 'Nothing recorded in this period yet.', 'rawi-md' ),
			'noDataHint'      => __( 'Requests appear here as soon as an AI agent asks for Markdown. Run the live test below to send the first one.', 'rawi-md' ),
			'other'           => __( 'Other agents', 'rawi-md' ),
			'total'           => __( 'Total', 'rawi-md' ),
			'requestsOver'    => __( 'Requests over time', 'rawi-md' ),
			'requestsHint'    => __( 'Stacked by agent. Click a name in the legend to hide it.', 'rawi-md' ),
			'whoReading'      => __( 'Who is reading', 'rawi-md' ),
			'howAsked'        => __( 'How they asked', 'rawi-md' ),
			'operators'       => __( 'By company', 'rawi-md' ),
			'whenActive'      => __( 'When agents visit', 'rawi-md' ),
			'whenHint'        => __( 'Day of week and hour, in the site timezone.', 'rawi-md' ),
			'agentsTable'     => __( 'Agents', 'rawi-md' ),
			'topPages'        => __( 'Most requested pages', 'rawi-md' ),
			'topPagesHint'    => __( 'What agents came for, and how much lighter the Markdown is than the page.', 'rawi-md' ),
			'coverage'        => __( 'Coverage', 'rawi-md' ),
			'coverageHint'    => __( 'How much of the site agents have read in this period.', 'rawi-md' ),
			'missing'         => __( 'Broken Markdown links', 'rawi-md' ),
			'missingHint'     => __( 'Addresses agents asked for that do not exist.', 'rawi-md' ),
			'noMissing'       => __( 'No broken Markdown links. All good.', 'rawi-md' ),
			'live'            => __( 'Live activity', 'rawi-md' ),
			'health'          => __( 'Health', 'rawi-md' ),
			'runTest'         => __( 'Run live test', 'rawi-md' ),
			'running'         => __( 'Testing…', 'rawi-md' ),
			'testHint'        => __( 'Requests a page the way an agent and a browser would, through every cache in front of the site.', 'rawi-md' ),
			'generateAll'     => __( 'Generate all now', 'rawi-md' ),
			'generating'      => __( 'Generating %1$s of %2$s…', 'rawi-md' ),
			'generated'       => __( 'Done: %s documents generated.', 'rawi-md' ),
			'colAgent'        => __( 'Agent', 'rawi-md' ),
			'colKind'         => __( 'Type', 'rawi-md' ),
			'colRequests'     => __( 'Requests', 'rawi-md' ),
			'colShare'        => __( 'Share', 'rawi-md' ),
			'colPages'        => __( 'Pages', 'rawi-md' ),
			'colTokens'       => __( 'Tokens', 'rawi-md' ),
			'colVerification' => __( 'Identity', 'rawi-md' ),
			'colLastSeen'     => __( 'Last seen', 'rawi-md' ),
			'colPage'         => __( 'Page', 'rawi-md' ),
			'colAgentsN'      => __( 'Agents', 'rawi-md' ),
			'colWeight'       => __( 'Markdown vs HTML', 'rawi-md' ),
			'colSaving'       => __( 'Saved', 'rawi-md' ),
			'viewMd'          => __( 'View Markdown', 'rawi-md' ),
			'edit'            => __( 'Edit', 'rawi-md' ),
			'search'          => __( 'Filter…', 'rawi-md' ),
			'verifiedBadge'   => __( 'Verified', 'rawi-md' ),
			'spoofedBadge'    => __( 'Fake', 'rawi-md' ),
			'mixedBadge'      => __( 'Mixed', 'rawi-md' ),
			'unverifiable'    => __( 'Not verifiable', 'rawi-md' ),
			'pending'         => __( 'Unchecked', 'rawi-md' ),
			'cacheHit'        => __( 'cache', 'rawi-md' ),
			'cacheMiss'       => __( 'fresh', 'rawi-md' ),
			'status304'       => __( 'not modified', 'rawi-md' ),
			'status404'       => __( 'not found', 'rawi-md' ),
			'cachedDocs'      => __( '%1$s documents cached, %2$s on disk', 'rawi-md' ),
			'readOf'          => __( '%1$s of %2$s', 'rawi-md' ),
			'lifetime'        => __( '%1$s requests and %2$s tokens since %3$s', 'rawi-md' ),
			'liveOn'          => __( 'Live', 'rawi-md' ),
			'refresh'         => __( 'Refresh', 'rawi-md' ),
			'export'          => __( 'Export CSV', 'rawi-md' ),
			'openLog'         => __( 'Full log', 'rawi-md' ),
			'range1'          => __( '24 hours', 'rawi-md' ),
			'range7'          => __( '7 days', 'rawi-md' ),
			'range30'         => __( '30 days', 'rawi-md' ),
			'range90'         => __( '90 days', 'rawi-md' ),
			'range365'        => __( '12 months', 'rawi-md' ),
			'peak'            => __( 'Busiest slot: %1$s, %2$s', 'rawi-md' ),
			'conditional'     => __( '%s answered with 304 Not Modified', 'rawi-md' ),
			'llmsHits'        => __( 'llms.txt fetched %s times', 'rawi-md' ),
			'unknownOperator' => __( 'Independent or unknown', 'rawi-md' ),
			'error'           => __( 'Could not load the data. Try again.', 'rawi-md' ),
			'updated'         => __( 'Updated %s', 'rawi-md' ),
			'requestsShort'   => __( 'requests', 'rawi-md' ),
			'newRequests'     => __( '%s new', 'rawi-md' ),
			'aiVisitors'      => __( 'Visitors sent by AI', 'rawi-md' ),
			'aiVisitorsHint'  => __( 'People who clicked through to your site from an AI assistant. This is what being read is worth.', 'rawi-md' ),
			'visits'          => __( 'Referred visits', 'rawi-md' ),
			'visitors'        => __( 'Unique visitors', 'rawi-md' ),
			'topSource'       => __( 'Top assistant', 'rawi-md' ),
			'readsPerVisit'   => __( 'Crawler reads per visit', 'rawi-md' ),
			'readsPerHint'    => __( 'Lower is better: fewer reads needed for each visitor', 'rawi-md' ),
			'landingPages'    => __( 'Pages AI sends people to', 'rawi-md' ),
			'colVisits'       => __( 'Visits', 'rawi-md' ),
			'colReads'        => __( 'Crawler reads', 'rawi-md' ),
			'colSources'      => __( 'From', 'rawi-md' ),
			'noReferrals'     => __( 'No visitors from AI assistants yet in this period.', 'rawi-md' ),
			'noReferralsHint' => __( 'They are counted as soon as someone follows a link from ChatGPT, Perplexity, Gemini, Copilot, Claude or another assistant.', 'rawi-md' ),
			'referralsOff'    => __( 'Visitor tracking is off. Turn it on under Settings to see who AI sends your way.', 'rawi-md' ),
			'readiness'       => __( 'AI readiness', 'rawi-md' ),
			'readinessHint'   => __( 'A score for each page, from the Markdown agents receive.', 'rawi-md' ),
			'avgScore'        => __( 'Average score', 'rawi-md' ),
			'scored'          => __( '%s pages scored', 'rawi-md' ),
			'scoreGood'       => __( 'Good (80+)', 'rawi-md' ),
			'scoreFair'       => __( 'Fair (50–79)', 'rawi-md' ),
			'scorePoor'       => __( 'Needs work (<50)', 'rawi-md' ),
			'fixFirst'        => __( 'Fix these first', 'rawi-md' ),
			'commonIssues'    => __( 'Most common issues', 'rawi-md' ),
			'pagesAffected'   => __( '%s pages', 'rawi-md' ),
			'notScored'       => __( 'No page has been scored yet. Generate the cache to score every page.', 'rawi-md' ),
			'unscoredHint'    => __( 'Pages are scored when their Markdown is generated. Use "Generate all now" to score the rest.', 'rawi-md' ),
		);
	}

	/**
	 * Render the page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$tab  = self::current_tab();
		$base = admin_url( 'admin.php?page=' . self::SLUG );
		$live = RAWI_Converter::is_available();

		echo '<div class="wrap rawi-wrap">';

		echo '<div class="rawi-header">';
		echo '<div class="rawi-brand"><span class="rawi-logo" aria-hidden="true">MD</span>';
		echo '<div><h1>' . esc_html__( 'Rawi MD', 'rawi-md' ) . '</h1>';
		echo '<p class="rawi-sub">' . esc_html__( 'Your content, served as Markdown to the AI agents that ask for it.', 'rawi-md' ) . '</p></div></div>';
		printf(
			'<span class="rawi-badge %s"><span class="rawi-dot"></span>%s</span>',
			esc_attr( $live ? 'rawi-badge--live' : 'rawi-badge--idle' ),
			esc_html( $live ? __( 'Active', 'rawi-md' ) : __( 'Not converting', 'rawi-md' ) )
		);
		echo '<span class="rawi-version">v' . esc_html( RAWI_VERSION ) . '</span>';
		echo '</div>';

		// WordPress moves notices printed inside .wrap to after the first
		// heading; this placeholder keeps them out of the header card.
		echo '<h2 class="rawi-notice-anchor"></h2>';

		self::notices();

		echo '<nav class="nav-tab-wrapper rawi-tabs">';
		foreach ( self::tabs() as $key => $label ) {
			printf(
				'<a href="%s" class="nav-tab %s">%s</a>',
				esc_url( 'reports' === $key ? $base : add_query_arg( 'tab', $key, $base ) ),
				esc_attr( $tab === $key ? 'nav-tab-active' : '' ),
				esc_html( $label )
			);
		}
		echo '</nav>';

		if ( 'settings' === $tab ) {
			self::render_settings();
		} elseif ( 'server' === $tab ) {
			self::render_server();
		} elseif ( 'log' === $tab ) {
			self::render_log();
		} else {
			self::render_dashboard();
		}

		echo '</div>';
	}

	/**
	 * Show admin notices after an action.
	 *
	 * @return void
	 */
	private static function notices() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$notice = isset( $_GET['rawi_notice'] ) ? sanitize_key( wp_unslash( $_GET['rawi_notice'] ) ) : '';

		$messages = array(
			'saved'   => __( 'Settings saved. The Markdown cache was rebuilt.', 'rawi-md' ),
			'flushed' => __( 'Markdown cache cleared.', 'rawi-md' ),
			'cleared' => __( 'Request log emptied.', 'rawi-md' ),
		);

		if ( isset( $messages[ $notice ] ) ) {
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
				esc_html( $messages[ $notice ] )
			);
		}
	}

	/**
	 * Dashboard shell. The script fills it from window.RAWI_DASH.
	 *
	 * @return void
	 */
	private static function render_dashboard() {
		if ( ! RAWI_Settings::get( 'log_enabled' ) ) {
			echo '<div class="notice notice-warning inline"><p>'
				. esc_html__( 'Logging is off, so nothing new will appear here. Turn it on under Settings.', 'rawi-md' )
				. '</p></div>';
		}

		echo '<div id="rawi-dashboard" class="rawi-dash" aria-live="polite">';
		echo '<div class="rawi-loading"><span class="spinner is-active"></span></div>';
		echo '<noscript><p>' . esc_html__( 'The dashboard needs JavaScript.', 'rawi-md' ) . '</p></noscript>';
		echo '</div>';

		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rawi-danger"
			onsubmit="return confirm('<?php echo esc_js( __( 'Delete every logged request? This cannot be undone.', 'rawi-md' ) ); ?>');">
			<input type="hidden" name="action" value="rawi_clear_log" />
			<?php wp_nonce_field( 'rawi_clear_log' ); ?>
			<?php submit_button( __( 'Empty the log', 'rawi-md' ), 'delete small', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * Check the shared AJAX nonce and capability.
	 *
	 * @return void
	 */
	private static function ajax_guard() {
		check_ajax_referer( 'rawi_dashboard', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( null, 403 );
		}
	}

	/**
	 * AJAX: dashboard data for a range.
	 *
	 * @return void
	 */
	public static function ajax_dashboard() {
		self::ajax_guard();

		$range = RAWI_Stats::normalise_range( isset( $_POST['range'] ) ? sanitize_text_field( wp_unslash( $_POST['range'] ) ) : 30 );

		update_user_meta( get_current_user_id(), 'rawi_range', $range );

		wp_send_json_success(
			array(
				'data'      => RAWI_Stats::dashboard( $range ),
				'exportUrl' => self::export_url( $range ),
			)
		);
	}

	/**
	 * AJAX: requests newer than a given id, for the live feed.
	 *
	 * @return void
	 */
	public static function ajax_recent() {
		self::ajax_guard();

		$after = isset( $_POST['after'] ) ? absint( wp_unslash( $_POST['after'] ) ) : 0;

		wp_send_json_success( RAWI_Stats::recent( 40, $after ) );
	}

	/**
	 * AJAX: live end-to-end test.
	 *
	 * @return void
	 */
	public static function ajax_selftest() {
		self::ajax_guard();

		wp_send_json_success( RAWI_Tools::self_test() );
	}

	/**
	 * AJAX: generate the cache in small batches so no request times out.
	 *
	 * @return void
	 */
	public static function ajax_warm() {
		self::ajax_guard();

		$offset = isset( $_POST['offset'] ) ? absint( wp_unslash( $_POST['offset'] ) ) : 0;
		$ids    = RAWI_Tools::warmable_ids();
		$batch  = array_slice( $ids, $offset, 10 );
		$made   = 0;

		foreach ( $batch as $id ) {
			if ( 'generated' === RAWI_Tools::warm_one( $id ) ) {
				$made++;
			}
		}

		wp_send_json_success(
			array(
				'next'      => $offset + count( $batch ),
				'total'     => count( $ids ),
				'generated' => $made,
				'done'      => ( $offset + count( $batch ) ) >= count( $ids ),
			)
		);
	}

	/**
	 * Request log tab: filterable, paginated table.
	 *
	 * @return void
	 */
	private static function render_log() {
		global $wpdb;

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$filters = array(
			'agent'  => isset( $_GET['agent'] ) ? sanitize_text_field( wp_unslash( $_GET['agent'] ) ) : '',
			'route'  => isset( $_GET['route'] ) ? sanitize_key( wp_unslash( $_GET['route'] ) ) : '',
			'status' => isset( $_GET['status'] ) ? absint( wp_unslash( $_GET['status'] ) ) : 0,
			'q'      => isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '',
		);
		$paged   = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$per   = 50;
		$table = RAWI_Logger::table();
		$where = array( '1=1' );
		$args  = array( $table );

		if ( '' !== $filters['agent'] ) {
			$where[] = 'agent_label = %s';
			$args[]  = $filters['agent'];
		}

		if ( '' !== $filters['route'] ) {
			$where[] = 'route = %s';
			$args[]  = $filters['route'];
		}

		if ( $filters['status'] ) {
			$where[] = 'status = %d';
			$args[]  = $filters['status'];
		}

		if ( '' !== $filters['q'] ) {
			$where[] = '( url_path LIKE %s OR user_agent LIKE %s )';
			$like    = '%' . $wpdb->esc_like( $filters['q'] ) . '%';
			$args[]  = $like;
			$args[]  = $like;
		}

		$sql_where = implode( ' AND ', $where );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE {$sql_where}", $args ) );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM %i WHERE {$sql_where} ORDER BY id DESC LIMIT %d OFFSET %d",
				array_merge( $args, array( $per, ( $paged - 1 ) * $per ) )
			),
			ARRAY_A
		);
		$labels = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT agent_label FROM %i ORDER BY agent_label', $table ) );
		// phpcs:enable

		$routes = array(
			'accept' => __( 'Accept header', 'rawi-md' ),
			'suffix' => __( '.md address', 'rawi-md' ),
			'query'  => __( 'Query string', 'rawi-md' ),
			'llms'   => 'llms.txt',
		);

		?>
		<form method="get" class="rawi-filters">
			<input type="hidden" name="page" value="<?php echo esc_attr( self::SLUG ); ?>" />
			<input type="hidden" name="tab" value="log" />
			<select name="agent">
				<option value=""><?php esc_html_e( 'All agents', 'rawi-md' ); ?></option>
				<?php foreach ( (array) $labels as $label ) : ?>
					<option value="<?php echo esc_attr( $label ); ?>" <?php selected( $filters['agent'], $label ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<select name="route">
				<option value=""><?php esc_html_e( 'All routes', 'rawi-md' ); ?></option>
				<?php foreach ( $routes as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $filters['route'], $key ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<select name="status">
				<option value="0"><?php esc_html_e( 'All statuses', 'rawi-md' ); ?></option>
				<?php foreach ( array( 200, 304, 404 ) as $code ) : ?>
					<option value="<?php echo esc_attr( (string) $code ); ?>" <?php selected( $filters['status'], $code ); ?>><?php echo esc_html( (string) $code ); ?></option>
				<?php endforeach; ?>
			</select>
			<input type="search" name="q" value="<?php echo esc_attr( $filters['q'] ); ?>" placeholder="<?php esc_attr_e( 'Path or user agent', 'rawi-md' ); ?>" />
			<?php submit_button( __( 'Filter', 'rawi-md' ), 'secondary', '', false ); ?>
			<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=rawi_export&days=0' ), 'rawi_export' ) ); ?>"><?php esc_html_e( 'Export CSV', 'rawi-md' ); ?></a>
			<span class="rawi-filters__count">
				<?php
				/* translators: %s: number of matching requests. */
				echo esc_html( sprintf( _n( '%s request', '%s requests', $total, 'rawi-md' ), number_format_i18n( $total ) ) );
				?>
			</span>
		</form>

		<div class="rawi-card rawi-card--flush">
		<table class="widefat striped rawi-log">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Time', 'rawi-md' ); ?></th>
					<th><?php esc_html_e( 'Agent', 'rawi-md' ); ?></th>
					<th><?php esc_html_e( 'Page', 'rawi-md' ); ?></th>
					<th><?php esc_html_e( 'Route', 'rawi-md' ); ?></th>
					<th><?php esc_html_e( 'Status', 'rawi-md' ); ?></th>
					<th class="num"><?php esc_html_e( 'Tokens', 'rawi-md' ); ?></th>
					<th><?php esc_html_e( 'Cache', 'rawi-md' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="7" class="rawi-empty"><?php esc_html_e( 'Nothing recorded yet.', 'rawi-md' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( (array) $rows as $row ) : ?>
				<?php
				$ts       = strtotime( $row['requested_at'] . ' UTC' );
				$verified = (int) $row['verified'];
				$title    = $row['post_id'] ? get_the_title( (int) $row['post_id'] ) : '';
				?>
				<tr>
					<td title="<?php echo esc_attr( $row['requested_at'] . ' UTC' ); ?>"><?php echo esc_html( wp_date( 'Y-m-d H:i:s', $ts ) ); ?></td>
					<td>
						<strong><?php echo esc_html( $row['agent_label'] ); ?></strong>
						<?php if ( RAWI_Logger::VERIFIED === $verified ) : ?>
							<span class="rawi-pill rawi-pill--ok"><?php esc_html_e( 'Verified', 'rawi-md' ); ?></span>
						<?php elseif ( RAWI_Logger::SPOOFED === $verified ) : ?>
							<span class="rawi-pill rawi-pill--bad"><?php esc_html_e( 'Fake', 'rawi-md' ); ?></span>
						<?php endif; ?>
						<div class="rawi-muted rawi-ua" title="<?php echo esc_attr( $row['user_agent'] ); ?>"><?php echo esc_html( $row['user_agent'] ); ?></div>
					</td>
					<td>
						<?php if ( '' !== $title ) : ?>
							<a href="<?php echo esc_url( (string) get_edit_post_link( (int) $row['post_id'] ) ); ?>"><?php echo esc_html( $title ); ?></a>
						<?php endif; ?>
						<div class="rawi-muted"><code><?php echo esc_html( $row['url_path'] ); ?></code></div>
					</td>
					<td><?php echo esc_html( isset( $routes[ $row['route'] ] ) ? $routes[ $row['route'] ] : $row['route'] ); ?></td>
					<td><span class="rawi-code-badge rawi-code-badge--<?php echo esc_attr( (string) (int) $row['status'] ); ?>"><?php echo esc_html( (string) (int) $row['status'] ); ?></span></td>
					<td class="num"><?php echo esc_html( number_format_i18n( (int) $row['tokens'] ) ); ?></td>
					<td>
						<?php
						if ( 200 === (int) $row['status'] ) {
							echo esc_html( $row['cache_hit'] ? __( 'Hit', 'rawi-md' ) : sprintf( /* translators: %d: milliseconds. */ __( 'Miss, %d ms', 'rawi-md' ), (int) $row['gen_ms'] ) );
						}
						?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<?php

		$pages = (int) ceil( $total / $per );

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo wp_kses_post(
				paginate_links(
					array(
						'base'    => add_query_arg( 'paged', '%#%' ),
						'format'  => '',
						'current' => $paged,
						'total'   => $pages,
					)
				)
			);
			echo '</div></div>';
		}
	}

	/**
	 * Settings form.
	 *
	 * @return void
	 */
	private static function render_settings() {
		$s     = RAWI_Settings::all();
		$types = get_post_types( array( 'public' => true ), 'objects' );
		$lists = get_option( RAWI_Verify::LISTS_OPTION, array() );

		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rawi-settings">
			<input type="hidden" name="action" value="rawi_save" />
			<?php wp_nonce_field( 'rawi_save' ); ?>

			<div class="rawi-card">
			<h2><?php esc_html_e( 'How agents request Markdown', 'rawi-md' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Delivery routes', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="enable_accept_header" value="1" <?php checked( $s['enable_accept_header'] ); ?> />
							<code>Accept: text/markdown</code> <?php esc_html_e( 'on the page URL', 'rawi-md' ); ?></label><br />
						<label><input type="checkbox" name="enable_md_suffix" value="1" <?php checked( $s['enable_md_suffix'] ); ?> />
							<?php esc_html_e( 'A .md suffix on the URL', 'rawi-md' ); ?></label><br />
						<label><input type="checkbox" name="enable_query_string" value="1" <?php checked( $s['enable_query_string'] ); ?> />
							<code>?format=md</code> <?php esc_html_e( 'and', 'rawi-md' ); ?> <code>?output_format=md</code></label>
						<p class="description">
							<?php esc_html_e( 'Keep the Accept header on: it is the route AI agents actually use. The other two are fallbacks for agents that do not send the header.', 'rawi-md' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'llms.txt', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="llms_enabled" value="1" <?php checked( $s['llms_enabled'] ); ?> />
							<?php esc_html_e( 'Publish an llms.txt index of every page served as Markdown', 'rawi-md' ); ?></label>
						<?php if ( $s['llms_enabled'] ) : ?>
							— <a href="<?php echo esc_url( RAWI_Llms::url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( RAWI_Llms::url() ); ?></a>
						<?php endif; ?>
						<p class="description"><?php esc_html_e( 'A short map of the site that agents can read in one request, with a link to the Markdown of each page.', 'rawi-md' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="rawi-llms-intro"><?php esc_html_e( 'llms.txt introduction', 'rawi-md' ); ?></label></th>
					<td>
						<textarea id="rawi-llms-intro" name="llms_intro" rows="3" class="large-text"><?php echo esc_textarea( $s['llms_intro'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Optional. A few sentences about who you are and what the site covers, placed under the site name.', 'rawi-md' ); ?></p>
						<label for="rawi-llms-max"><?php esc_html_e( 'Pages listed per content type', 'rawi-md' ); ?></label>
						<input type="number" id="rawi-llms-max" name="llms_max_per_type" min="1" max="500" value="<?php echo esc_attr( (int) $s['llms_max_per_type'] ); ?>" class="small-text" />
					</td>
				</tr>
			</table>
			</div>

			<div class="rawi-card">
			<h2><?php esc_html_e( 'What gets served', 'rawi-md' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Post types', 'rawi-md' ); ?></th>
					<td class="rawi-checkgrid">
						<?php foreach ( $types as $type ) : ?>
							<label>
								<input type="checkbox" name="post_types[]" value="<?php echo esc_attr( $type->name ); ?>"
									<?php checked( in_array( $type->name, (array) $s['post_types'], true ) ); ?> />
								<?php echo esc_html( $type->labels->singular_name ); ?>
								<code><?php echo esc_html( $type->name ); ?></code>
							</label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="rawi-excluded"><?php esc_html_e( 'Excluded post IDs', 'rawi-md' ); ?></label></th>
					<td>
						<input type="text" id="rawi-excluded" name="excluded_ids" class="regular-text"
							value="<?php echo esc_attr( $s['excluded_ids'] ); ?>" placeholder="12, 48, 301" />
						<p class="description"><?php esc_html_e( 'Comma separated. These pages return 404 on the .md URL and stay HTML for agents. You can also exclude a single post from its editor sidebar.', 'rawi-md' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Content source', 'rawi-md' ); ?></th>
					<td>
						<label><input type="radio" name="render_mode" value="the_content" <?php checked( $s['render_mode'], 'the_content' ); ?> />
							<?php esc_html_e( 'Post content filters (recommended)', 'rawi-md' ); ?></label><br />
						<label><input type="radio" name="render_mode" value="full_page" <?php checked( $s['render_mode'], 'full_page' ); ?> />
							<?php esc_html_e( 'Full page render, then strip the theme chrome', 'rawi-md' ); ?></label>
						<p class="description">
							<?php esc_html_e( 'The first option covers Classic, Gutenberg, Elementor and WPBakery, and costs nothing. Choose the full page render only for Bricks or Oxygen, which replace the whole template. It makes one internal HTTP request per uncached page, so it can stall on hosting with a single PHP worker.', 'rawi-md' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="rawi-content-strip"><?php esc_html_e( 'Removed from post content', 'rawi-md' ); ?></label></th>
					<td>
						<textarea id="rawi-content-strip" name="content_strip_selectors" rows="6" class="large-text rawi-code"><?php echo esc_textarea( $s['content_strip_selectors'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Used with the content filters. Keep it short: only share buttons and widgets that plugins inject into the content.', 'rawi-md' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="rawi-content-selectors"><?php esc_html_e( 'Content selectors', 'rawi-md' ); ?></label></th>
					<td>
						<textarea id="rawi-content-selectors" name="content_selectors" rows="5" class="large-text rawi-code"><?php echo esc_textarea( $s['content_selectors'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One per line, first match wins. Used with the full page render only.', 'rawi-md' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="rawi-strip-selectors"><?php esc_html_e( 'Removed from the full page', 'rawi-md' ); ?></label></th>
					<td>
						<textarea id="rawi-strip-selectors" name="strip_selectors" rows="8" class="large-text rawi-code"><?php echo esc_textarea( $s['strip_selectors'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One per line. Supports tag, .class, #id and descendant selectors. Used with the full page render only.', 'rawi-md' ); ?></p>
					</td>
				</tr>
			</table>
			</div>

			<div class="rawi-card">
			<h2><?php esc_html_e( 'Frontmatter', 'rawi-md' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'YAML frontmatter', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="frontmatter_enabled" value="1" <?php checked( $s['frontmatter_enabled'] ); ?> />
							<?php esc_html_e( 'Add a metadata block at the top of every document', 'rawi-md' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Fields', 'rawi-md' ); ?></th>
					<td class="rawi-checkgrid">
						<?php foreach ( self::frontmatter_fields() as $key => $label ) : ?>
							<label>
								<input type="checkbox" name="frontmatter_fields[]" value="<?php echo esc_attr( $key ); ?>"
									<?php checked( in_array( $key, (array) $s['frontmatter_fields'], true ) ); ?> />
								<?php echo esc_html( $label ); ?>
							</label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'WooCommerce', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="woo_fields" value="1" <?php checked( $s['woo_fields'] ); ?> />
							<?php esc_html_e( 'Add SKU, price, currency, stock status and rating to product frontmatter', 'rawi-md' ); ?></label>
						<p class="description"><?php esc_html_e( 'These live in post meta, not in the rendered page, so an edge converter cannot produce them.', 'rawi-md' ); ?></p>
					</td>
				</tr>
			</table>
			</div>

			<div class="rawi-card">
			<h2><?php esc_html_e( 'Search engines and signals', 'rawi-md' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Safety', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="respect_seo_noindex" value="1" <?php checked( $s['respect_seo_noindex'] ); ?> />
							<?php esc_html_e( 'Skip pages your SEO plugin marks noindex', 'rawi-md' ); ?></label><br />
						<label><input type="checkbox" name="noindex_alt_urls" value="1" <?php checked( $s['noindex_alt_urls'] ); ?> />
							<?php esc_html_e( 'Send X-Robots-Tag: noindex on .md and query-string URLs', 'rawi-md' ); ?></label>
						<p class="description">
							<?php esc_html_e( 'The noindex header is never sent on the page URL itself, only on the separate .md and query-string addresses. Those are duplicates of a real page; the page URL is not.', 'rawi-md' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="rawi-signal"><?php esc_html_e( 'Content-Signal header', 'rawi-md' ); ?></label></th>
					<td>
						<input type="text" id="rawi-signal" name="content_signal" class="regular-text"
							value="<?php echo esc_attr( $s['content_signal'] ); ?>" />
						<p class="description"><?php esc_html_e( 'States how you allow the content to be used. Leave empty to send nothing. The default permits search and answering, and declines model training.', 'rawi-md' ); ?></p>
					</td>
				</tr>
			</table>
			</div>

			<div class="rawi-card">
			<h2><?php esc_html_e( 'Cache', 'rawi-md' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Markdown cache', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="cache_enabled" value="1" <?php checked( $s['cache_enabled'] ); ?> />
							<?php esc_html_e( 'Store converted documents on disk', 'rawi-md' ); ?></label>
						<p class="description">
							<?php
							printf(
								/* translators: %d: number of cached files. */
								esc_html__( 'Currently holding %d documents. Cleared automatically when a post is edited.', 'rawi-md' ),
								(int) RAWI_Cache::count()
							);
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Prepare on publish', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="auto_warm" value="1" <?php checked( $s['auto_warm'] ); ?> />
							<?php esc_html_e( 'Generate the Markdown in the background as soon as a post is published or updated', 'rawi-md' ); ?></label>
						<p class="description"><?php esc_html_e( 'The first agent to arrive gets a ready document instead of waiting for a conversion, and the page gets its readiness score straight away.', 'rawi-md' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="rawi-ttl"><?php esc_html_e( 'Expiry', 'rawi-md' ); ?></label></th>
					<td>
						<input type="number" id="rawi-ttl" name="cache_ttl" min="0" step="60" value="<?php echo esc_attr( (int) $s['cache_ttl'] ); ?>" />
						<?php esc_html_e( 'seconds', 'rawi-md' ); ?>
						<p class="description"><?php esc_html_e( 'Set 0 to keep documents until the post changes. Use a value only if your content depends on something outside the post, such as a live feed.', 'rawi-md' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Token savings', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="measure_html" value="1" <?php checked( $s['measure_html'] ); ?> />
							<?php esc_html_e( 'Measure each page’s HTML size in the background', 'rawi-md' ); ?></label>
						<p class="description"><?php esc_html_e( 'One request to your own site per page, after it changes, so the dashboard can show how many tokens agents saved. Nothing leaves your server.', 'rawi-md' ); ?></p>
					</td>
				</tr>
			</table>
			</div>

			<div class="rawi-card">
			<h2><?php esc_html_e( 'Request log', 'rawi-md' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Logging', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="log_enabled" value="1" <?php checked( $s['log_enabled'] ); ?> />
							<?php esc_html_e( 'Record which agents request Markdown', 'rawi-md' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Visitors sent by AI', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="track_referrals" value="1" <?php checked( $s['track_referrals'] ); ?> />
							<?php esc_html_e( 'Count people who arrive from ChatGPT, Perplexity, Gemini, Copilot, Claude and other assistants', 'rawi-md' ); ?></label>
						<p class="description"><?php esc_html_e( 'A tiny inline script checks where the visitor came from. Only when it was an AI assistant does it send one request to your own site. No cookies, nothing sent to anyone else, and works behind page caches.', 'rawi-md' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Visitor IPs', 'rawi-md' ); ?></th>
					<td>
						<label><input type="radio" name="log_store_ip" value="hash" <?php checked( $s['log_store_ip'], 'hash' ); ?> />
							<?php esc_html_e( 'Store a one-way hash', 'rawi-md' ); ?></label><br />
						<label><input type="radio" name="log_store_ip" value="none" <?php checked( $s['log_store_ip'], 'none' ); ?> />
							<?php esc_html_e( 'Do not store anything', 'rawi-md' ); ?></label>
						<p class="description"><?php esc_html_e( 'Raw IP addresses are never written. The hash lets you count unique clients without keeping personal data.', 'rawi-md' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Crawler verification', 'rawi-md' ); ?></th>
					<td>
						<label><input type="checkbox" name="verify_bots" value="1" <?php checked( $s['verify_bots'] ); ?> />
							<?php esc_html_e( 'Check that Googlebot, Bingbot and Applebot really come from their operators (reverse DNS)', 'rawi-md' ); ?></label><br />
						<label><input type="checkbox" name="verify_ip_lists" value="1" <?php checked( $s['verify_ip_lists'] ); ?> />
							<?php esc_html_e( 'Also download the official IP lists published by OpenAI, Perplexity, Google and Microsoft once a day', 'rawi-md' ); ?></label>
						<p class="description">
							<?php esc_html_e( 'Anyone can claim to be GPTBot. Verification marks each request as verified or fake on the dashboard. The second option makes a daily request to openai.com, perplexity.ai, developers.google.com and bing.com; no data about your site is sent.', 'rawi-md' ); ?>
							<?php
							if ( is_array( $lists ) && ! empty( $lists['updated'] ) ) {
								echo ' ' . esc_html(
									sprintf(
										/* translators: %s: time since the last download. */
										__( 'Lists last updated %s ago.', 'rawi-md' ),
										human_time_diff( (int) $lists['updated'] )
									)
								);
							}
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="rawi-retention"><?php esc_html_e( 'Keep entries for', 'rawi-md' ); ?></label></th>
					<td>
						<input type="number" id="rawi-retention" name="log_retention_days" min="0" max="3650"
							value="<?php echo esc_attr( (int) $s['log_retention_days'] ); ?>" />
						<?php esc_html_e( 'days', 'rawi-md' ); ?>
						&nbsp;&nbsp;
						<label for="rawi-maxrows"><?php esc_html_e( 'Row limit', 'rawi-md' ); ?></label>
						<input type="number" id="rawi-maxrows" name="log_max_rows" min="0" step="1000"
							value="<?php echo esc_attr( (int) $s['log_max_rows'] ); ?>" />
						<p class="description"><?php esc_html_e( 'Set either to 0 for no limit.', 'rawi-md' ); ?></p>
					</td>
				</tr>
			</table>
			</div>

			<?php submit_button( __( 'Save changes', 'rawi-md' ) ); ?>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rawi_flush_cache" />
			<?php wp_nonce_field( 'rawi_flush_cache' ); ?>
			<?php submit_button( __( 'Clear Markdown cache', 'rawi-md' ), 'secondary', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * Frontmatter fields the owner can toggle.
	 *
	 * @return string[]
	 */
	private static function frontmatter_fields() {
		return array(
			'title'          => __( 'Title', 'rawi-md' ),
			'description'    => __( 'Description', 'rawi-md' ),
			'url'            => __( 'Canonical URL', 'rawi-md' ),
			'date_published' => __( 'Published date', 'rawi-md' ),
			'date_modified'  => __( 'Modified date', 'rawi-md' ),
			'author'         => __( 'Author', 'rawi-md' ),
			'categories'     => __( 'Categories', 'rawi-md' ),
			'tags'           => __( 'Tags', 'rawi-md' ),
			'language'       => __( 'Language', 'rawi-md' ),
			'image'          => __( 'Featured image', 'rawi-md' ),
			'word_count'     => __( 'Word count', 'rawi-md' ),
		);
	}

	/**
	 * Server rules tab.
	 *
	 * @return void
	 */
	private static function render_server() {
		$detected = RAWI_Cache_Compat::detected_caches();

		echo '<div class="rawi-card">';
		echo '<p>' . esc_html__( 'A page cache can answer a request before WordPress runs. When that happens no plugin can intervene, and an agent asking for Markdown gets a stored HTML copy instead. These rules tell the cache to step aside for those requests.', 'rawi-md' ) . '</p>';

		if ( ! empty( $detected ) ) {
			printf(
				'<div class="notice notice-info inline"><p>%s <strong>%s</strong></p></div>',
				esc_html__( 'Detected on this site:', 'rawi-md' ),
				esc_html( implode( ', ', $detected ) )
			);
		}

		$blocks = array(
			__( 'Apache and LiteSpeed — add to .htaccess above the WordPress block', 'rawi-md' ) => RAWI_Cache_Compat::htaccess_rules(),
			__( 'Nginx with fastcgi_cache', 'rawi-md' )                                          => RAWI_Cache_Compat::nginx_rules(),
			__( 'Cloudflare', 'rawi-md' )                                                        => RAWI_Cache_Compat::cloudflare_rules(),
		);

		foreach ( $blocks as $heading => $body ) {
			echo '<h3>' . esc_html( $heading ) . '</h3>';
			echo '<textarea class="rawi-code" rows="' . esc_attr( substr_count( $body, "\n" ) + 2 ) . '" readonly onclick="this.select();">'
				. esc_textarea( $body ) . '</textarea>';
		}

		echo '<h3>' . esc_html__( 'Check that it works', 'rawi-md' ) . '</h3>';

		$sample = RAWI_Tools::sample_post();
		$url    = $sample ? get_permalink( $sample ) : home_url( '/' );

		$command = 'curl -sI -H "Accept: text/markdown" "' . $url . '" | grep -i "content-type\|x-markdown\|vary"';

		echo '<textarea class="rawi-code" rows="2" readonly onclick="this.select();">' . esc_textarea( $command ) . '</textarea>';
		echo '<p class="description">' . esc_html__( 'A working setup answers with content-type: text/markdown and an x-markdown-tokens header. If you get text/html back, the page cache is still answering first.', 'rawi-md' ) . ' ';
		printf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'admin.php?page=' . self::SLUG . '#rawi-health' ) ),
			esc_html__( 'Or run the live test from the dashboard.', 'rawi-md' )
		);
		echo '</p></div>';
	}

	/**
	 * A compact summary on the main WordPress dashboard.
	 *
	 * @return void
	 */
	public static function dashboard_widget() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_add_dashboard_widget( 'rawi_md_widget', __( 'Rawi MD — AI agents', 'rawi-md' ), array( __CLASS__, 'render_widget' ) );
	}

	/**
	 * Widget body.
	 *
	 * @return void
	 */
	public static function render_widget() {
		$from   = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
		$to     = gmdate( 'Y-m-d H:i:s', time() + MINUTE_IN_SECONDS );
		$kpis   = RAWI_Stats::kpis( $from, $to );
		$agents = array_slice( RAWI_Stats::agents( $from, $to, 5 ), 0, 5 );

		echo '<div class="rawi-widget">';
		echo '<div class="rawi-widget__figures">';
		printf( '<div><strong>%s</strong><span>%s</span></div>', esc_html( number_format_i18n( $kpis['requests'] ) ), esc_html__( 'requests, last 7 days', 'rawi-md' ) );
		printf( '<div><strong>%s</strong><span>%s</span></div>', esc_html( number_format_i18n( $kpis['agents'] ) ), esc_html__( 'Distinct agents', 'rawi-md' ) );
		printf( '<div><strong>%s</strong><span>%s</span></div>', esc_html( number_format_i18n( $kpis['tokens_saved'] ) ), esc_html__( 'Tokens saved', 'rawi-md' ) );
		echo '</div>';

		if ( ! empty( $agents ) ) {
			echo '<ul class="rawi-box__agents">';
			foreach ( $agents as $agent ) {
				printf( '<li><span>%s</span><b>%s</b></li>', esc_html( $agent['label'] ), esc_html( number_format_i18n( $agent['hits'] ) ) );
			}
			echo '</ul>';
		}

		printf(
			'<p><a class="button" href="%s">%s</a></p>',
			esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ),
			esc_html__( 'Open the dashboard', 'rawi-md' )
		);
		echo '</div>';
	}

	/**
	 * Save handler.
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to change these settings.', 'rawi-md' ) );
		}

		check_admin_referer( 'rawi_save' );

		$defaults = RAWI_Settings::defaults();
		$current  = RAWI_Settings::all();
		$values   = array();

		$checkboxes = array(
			'enable_accept_header',
			'enable_md_suffix',
			'enable_query_string',
			'frontmatter_enabled',
			'woo_fields',
			'respect_seo_noindex',
			'noindex_alt_urls',
			'cache_enabled',
			'measure_html',
			'log_enabled',
			'verify_bots',
			'verify_ip_lists',
			'llms_enabled',
			'track_referrals',
			'auto_warm',
		);

		foreach ( $checkboxes as $key ) {
			$values[ $key ] = isset( $_POST[ $key ] ) ? 1 : 0;
		}

		$public_types = array_keys( get_post_types( array( 'public' => true ) ) );

		$values['post_types'] = isset( $_POST['post_types'] ) && is_array( $_POST['post_types'] )
			? array_values( array_intersect( array_map( 'sanitize_key', wp_unslash( $_POST['post_types'] ) ), $public_types ) )
			: array();

		$values['frontmatter_fields'] = isset( $_POST['frontmatter_fields'] ) && is_array( $_POST['frontmatter_fields'] )
			? array_values( array_intersect( array_map( 'sanitize_key', wp_unslash( $_POST['frontmatter_fields'] ) ), array_keys( self::frontmatter_fields() ) ) )
			: array();

		$values['excluded_ids'] = isset( $_POST['excluded_ids'] )
			? implode( ', ', array_filter( array_map( 'absint', preg_split( '/[\s,]+/', sanitize_text_field( wp_unslash( $_POST['excluded_ids'] ) ) ) ) ) )
			: '';

		$mode                  = isset( $_POST['render_mode'] ) ? sanitize_key( wp_unslash( $_POST['render_mode'] ) ) : 'the_content';
		$values['render_mode'] = in_array( $mode, array( 'the_content', 'full_page' ), true ) ? $mode : 'the_content';

		foreach ( array( 'content_selectors', 'strip_selectors', 'content_strip_selectors' ) as $key ) {
			$values[ $key ] = isset( $_POST[ $key ] )
				? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) )
				: $defaults[ $key ];
		}

		$values['content_signal'] = isset( $_POST['content_signal'] )
			? sanitize_text_field( wp_unslash( $_POST['content_signal'] ) )
			: '';

		$values['llms_intro']        = isset( $_POST['llms_intro'] ) ? sanitize_textarea_field( wp_unslash( $_POST['llms_intro'] ) ) : '';
		$values['llms_max_per_type'] = isset( $_POST['llms_max_per_type'] ) ? max( 1, min( 500, absint( wp_unslash( $_POST['llms_max_per_type'] ) ) ) ) : 50;

		$values['cache_ttl']          = isset( $_POST['cache_ttl'] ) ? absint( wp_unslash( $_POST['cache_ttl'] ) ) : 0;
		$values['log_retention_days'] = isset( $_POST['log_retention_days'] ) ? min( 3650, absint( wp_unslash( $_POST['log_retention_days'] ) ) ) : 90;
		$values['log_max_rows']       = isset( $_POST['log_max_rows'] ) ? absint( wp_unslash( $_POST['log_max_rows'] ) ) : 50000;

		$store_ip               = isset( $_POST['log_store_ip'] ) ? sanitize_key( wp_unslash( $_POST['log_store_ip'] ) ) : 'hash';
		$values['log_store_ip'] = in_array( $store_ip, array( 'hash', 'none' ), true ) ? $store_ip : 'hash';

		// Keys this form does not know about (added by a filter or a future
		// version) are carried over untouched.
		RAWI_Settings::update( array_merge( $current, $values ) );

		if ( $values['verify_bots'] && $values['verify_ip_lists'] && empty( $current['verify_ip_lists'] ) ) {
			wp_schedule_single_event( time(), 'rawi_refresh_ip_lists' );
		}

		// A settings change alters every document, so the cache must go.
		RAWI_Cache::flush();
		flush_rewrite_rules();

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'        => self::SLUG,
					'tab'         => 'settings',
					'rawi_notice' => 'saved',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Cache flush handler.
	 *
	 * @return void
	 */
	public static function handle_flush() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'rawi-md' ) );
		}

		check_admin_referer( 'rawi_flush_cache' );

		RAWI_Cache::flush();

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'        => self::SLUG,
					'tab'         => 'settings',
					'rawi_notice' => 'flushed',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Log clear handler.
	 *
	 * @return void
	 */
	public static function handle_clear_log() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'rawi-md' ) );
		}

		check_admin_referer( 'rawi_clear_log' );

		RAWI_Logger::clear();
		RAWI_Referrals::clear();

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'        => self::SLUG,
					'rawi_notice' => 'cleared',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * CSV export handler.
	 *
	 * @return void
	 */
	public static function handle_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'rawi-md' ) );
		}

		check_admin_referer( 'rawi_export' );

		$days = isset( $_GET['days'] ) ? absint( wp_unslash( $_GET['days'] ) ) : 0;

		RAWI_Stats::export_csv( $days );
		exit;
	}
}
