<?php
/**
 * Logs which agents requested Markdown, from where, and how.
 *
 * This is the reporting layer: it answers "who is actually reading my content
 * in Markdown", which neither robots.txt nor a hit counter can tell you.
 *
 * IP addresses are hashed by default and never leave the site's own database.
 *
 * Schema history — every change is additive so no recorded request is lost:
 *   1  1.0.0  id, requested_at, post_id, route, url_path, user_agent,
 *             agent_label, ip_hash, tokens
 *   2  1.3.0  + status, html_tokens, cache_hit, gen_ms, verified
 *   3  1.3.0  + separate rawi_referrals table (see RAWI_Referrals)
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Logger
 */
class RAWI_Logger {

	/**
	 * Table name without prefix.
	 */
	const TABLE = 'rawi_requests';

	/**
	 * Verification states stored in the verified column.
	 */
	const UNCHECKED = 0;
	const VERIFIED  = 1;
	const SPOOFED   = 2;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		// Nothing at runtime; RAWI_Upgrade keeps the table current.
	}

	/**
	 * Fully qualified table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Create or upgrade the log table.
	 *
	 * dbDelta() compares this definition with the live table and only adds
	 * what is missing. It never drops columns or rows.
	 *
	 * @return void
	 */
	public static function create_table() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			requested_at DATETIME NOT NULL,
			post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			route VARCHAR(20) NOT NULL DEFAULT '',
			url_path VARCHAR(255) NOT NULL DEFAULT '',
			user_agent VARCHAR(255) NOT NULL DEFAULT '',
			agent_label VARCHAR(60) NOT NULL DEFAULT '',
			ip_hash CHAR(40) NOT NULL DEFAULT '',
			tokens INT(11) NOT NULL DEFAULT 0,
			status SMALLINT(5) UNSIGNED NOT NULL DEFAULT 200,
			html_tokens INT(11) NOT NULL DEFAULT 0,
			cache_hit TINYINT(1) NOT NULL DEFAULT 0,
			gen_ms INT(11) NOT NULL DEFAULT 0,
			verified TINYINT(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY requested_at (requested_at),
			KEY post_id (post_id),
			KEY agent_label (agent_label),
			KEY route (route)
		) {$collate};";

		dbDelta( $sql );

		// The moment the 1.3.0 columns started being filled. Rows before it
		// keep their data but are left out of cache and timing rates.
		if ( false === get_option( 'rawi_metrics_since', false ) ) {
			add_option( 'rawi_metrics_since', current_time( 'mysql', true ), '', false );
		}

		// If the ALTER failed (no ALTER privilege, a lock timeout) leave the
		// version alone, so the next page load tries again instead of
		// writing rows into a table that lacks the new columns.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$has_columns = $wpdb->get_var( $wpdb->prepare( 'SHOW COLUMNS FROM %i LIKE %s', $table, 'verified' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$has_referrals = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( RAWI_Referrals::table() ) ) );

		if ( $has_columns && $has_referrals ) {
			update_option( 'rawi_db_version', RAWI_DB_VERSION, false );
		}
	}

	/**
	 * Request-scoped details about the current visitor, captured once.
	 *
	 * @return array
	 */
	public static function client() {
		static $client = null;

		if ( null !== $client ) {
			return $client;
		}

		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] )
			? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) )
			: '';

		$ip = isset( $_SERVER['REMOTE_ADDR'] )
			? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
			: '';

		/**
		 * Filter the client IP used for hashing, rate limiting and crawler
		 * verification.
		 *
		 * REMOTE_ADDR is used because it cannot be forged. Behind a reverse
		 * proxy or CDN it is the proxy's address; return the forwarded
		 * address here only when the proxy is trusted.
		 *
		 * @param string $ip REMOTE_ADDR.
		 */
		$ip = (string) apply_filters( 'rawi_client_ip', $ip );

		// Cloudflare: trust CF-Connecting-IP only when the connection really
		// comes from Cloudflare, which verification can prove.
		if ( isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) && RAWI_Cache_Compat::is_cloudflare_ip( $ip ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
		}

		$path = isset( $_SERVER['REQUEST_URI'] )
			? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) )
			: '';

		$client = array(
			'user_agent' => $user_agent,
			'ip'         => filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '',
			'path'       => $path,
			'label'      => RAWI_Agents::label( $user_agent ),
		);

		return $client;
	}

	/**
	 * Record one request.
	 *
	 * @param int    $post_id Post ID served, 0 for llms.txt or a miss.
	 * @param string $route   accept | suffix | query | llms.
	 * @param array  $metrics {
	 *     Optional measurements.
	 *
	 *     @type int  $tokens      Markdown tokens delivered.
	 *     @type int  $html_tokens Tokens the HTML page would have cost.
	 *     @type bool $cache_hit   Served from the Markdown cache.
	 *     @type int  $gen_ms      Milliseconds spent generating on a miss.
	 *     @type int  $status      HTTP status sent.
	 * }
	 * @return void
	 */
	public static function record( $post_id, $route, array $metrics = array() ) {
		if ( ! RAWI_Settings::get( 'log_enabled' ) ) {
			return;
		}

		global $wpdb;

		$metrics = wp_parse_args(
			$metrics,
			array(
				'tokens'      => 0,
				'html_tokens' => 0,
				'cache_hit'   => false,
				'gen_ms'      => 0,
				'status'      => 200,
			)
		);

		$client = self::client();

		// The plugin's own health checks are not traffic.
		if ( 'Rawi MD self-test' === $client['label'] ) {
			return;
		}

		$ip_hash = '';

		if ( 'hash' === RAWI_Settings::get( 'log_store_ip' ) && '' !== $client['ip'] ) {
			$ip_hash = sha1( $client['ip'] . wp_salt( 'nonce' ) );
		}

		$verified = RAWI_Verify::check( $client['label'], $client['ip'] );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert(
			self::table(),
			array(
				'requested_at' => current_time( 'mysql', true ),
				'post_id'      => absint( $post_id ),
				'route'        => substr( (string) $route, 0, 20 ),
				'url_path'     => substr( $client['path'], 0, 255 ),
				'user_agent'   => substr( $client['user_agent'], 0, 255 ),
				'agent_label'  => substr( $client['label'], 0, 60 ),
				'ip_hash'      => $ip_hash,
				'tokens'       => absint( $metrics['tokens'] ),
				'status'       => absint( $metrics['status'] ),
				'html_tokens'  => absint( $metrics['html_tokens'] ),
				'cache_hit'    => $metrics['cache_hit'] ? 1 : 0,
				'gen_ms'       => absint( $metrics['gen_ms'] ),
				'verified'     => (int) $verified,
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%d' )
		);
	}

	/**
	 * Backwards-compatible alias kept for code written against 1.2.x.
	 *
	 * @param string $user_agent Raw user agent.
	 * @return string
	 */
	public static function label_agent( $user_agent ) {
		return RAWI_Agents::label( $user_agent );
	}

	/**
	 * Enforce retention and the row cap.
	 *
	 * @return void
	 */
	public static function prune() {
		global $wpdb;

		$table = self::table();
		$days  = absint( RAWI_Settings::get( 'log_retention_days' ) );

		if ( $days > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				$wpdb->prepare(
					'DELETE FROM %i WHERE requested_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)',
					$table,
					$days
				)
			);
		}

		$max = absint( RAWI_Settings::get( 'log_max_rows' ) );

		if ( $max > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$cutoff = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT id FROM %i ORDER BY id DESC LIMIT %d, 1',
					$table,
					$max
				)
			);

			if ( $cutoff ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE id <= %d', $table, $cutoff ) );
			}
		}
	}

	/**
	 * Empty the log.
	 *
	 * @return void
	 */
	public static function clear() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( $wpdb->prepare( 'TRUNCATE TABLE %i', self::table() ) );
	}

	/**
	 * Drop the table entirely, used by uninstall.
	 *
	 * @return void
	 */
	public static function drop_table() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', self::table() ) );
	}
}
