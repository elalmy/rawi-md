<?php
/**
 * Advertises the Markdown representation on the HTML page.
 *
 * Without this, an agent that does not send Accept: text/markdown has no way
 * to know a Markdown version exists. Most plugins in this space skip it.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Discovery
 */
class RAWI_Discovery {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'alternate_link' ), 5 );
		add_action( 'template_redirect', array( __CLASS__, 'html_headers' ), 5 );
	}

	/**
	 * Post currently being viewed, if it is eligible.
	 *
	 * @return WP_Post|null
	 */
	private static function current_post() {
		if ( ! is_singular() ) {
			return null;
		}

		$post = get_queried_object();

		if ( ! $post instanceof WP_Post ) {
			return null;
		}

		if ( ! RAWI_Eligibility::is_eligible( $post ) ) {
			return null;
		}

		return $post;
	}

	/**
	 * Output <link rel="alternate" type="text/markdown"> in the head.
	 *
	 * @return void
	 */
	public static function alternate_link() {
		$post = self::current_post();

		if ( ! $post ) {
			return;
		}

		$url = RAWI_Router::markdown_url( $post );

		if ( ! $url ) {
			return;
		}

		printf(
			'<link rel="alternate" type="text/markdown" href="%s" />' . "\n",
			esc_url( $url )
		);
	}

	/**
	 * Send Vary and Link headers on the HTML response.
	 *
	 * Vary: Accept is what tells well-behaved caches and CDNs that this URL has
	 * more than one representation. It is only correct to send it when the
	 * Accept route is actually enabled.
	 *
	 * @return void
	 */
	public static function html_headers() {
		$post = self::current_post();

		if ( ! $post || headers_sent() ) {
			return;
		}

		$url = RAWI_Router::markdown_url( $post );

		if ( $url ) {
			header( 'Link: <' . esc_url_raw( $url ) . '>; rel="alternate"; type="text/markdown"', false );
		}

		if ( RAWI_Settings::get( 'enable_accept_header' ) ) {
			header( 'Vary: Accept', false );
		}
	}
}
