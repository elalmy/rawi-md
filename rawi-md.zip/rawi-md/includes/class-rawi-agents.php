<?php
/**
 * Known agents: user-agent fingerprints, display labels, operators and kinds.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Agents
 */
class RAWI_Agents {

	/**
	 * Fingerprint table, most specific first because the first match wins.
	 *
	 * Kinds:
	 *   assistant  fetches a page live because a person asked a chatbot
	 *   search     builds an AI search or answer index
	 *   training   collects data for model training
	 *   search_engine  a classic web search crawler
	 *   tool       a script, library or command-line client
	 *   browser    a browser-like client
	 *
	 * @return array[] needle => array( label, operator, kind ).
	 */
	public static function catalog() {
		$catalog = array(
			'claude-user'          => array( 'Claude-User', 'Anthropic', 'assistant' ),
			'claude-searchbot'     => array( 'Claude-SearchBot', 'Anthropic', 'search' ),
			'claude-web'           => array( 'Claude-Web', 'Anthropic', 'assistant' ),
			'claudebot'            => array( 'ClaudeBot', 'Anthropic', 'training' ),
			'anthropic'            => array( 'Anthropic', 'Anthropic', 'assistant' ),
			'chatgpt-user'         => array( 'ChatGPT-User', 'OpenAI', 'assistant' ),
			'oai-searchbot'        => array( 'OAI-SearchBot', 'OpenAI', 'search' ),
			'gptbot'               => array( 'GPTBot', 'OpenAI', 'training' ),
			'perplexity-user'      => array( 'Perplexity-User', 'Perplexity', 'assistant' ),
			'perplexitybot'        => array( 'PerplexityBot', 'Perplexity', 'search' ),
			'google-cloudvertexbot' => array( 'Google-CloudVertexBot', 'Google', 'assistant' ),
			'gemini-deep-research' => array( 'Gemini-Deep-Research', 'Google', 'assistant' ),
			'googleother'          => array( 'GoogleOther', 'Google', 'training' ),
			'googlebot'            => array( 'Googlebot', 'Google', 'search_engine' ),
			'bingbot'              => array( 'Bingbot', 'Microsoft', 'search_engine' ),
			'copilot'              => array( 'Copilot', 'Microsoft', 'assistant' ),
			'applebot-extended'    => array( 'Applebot-Extended', 'Apple', 'training' ),
			'applebot'             => array( 'Applebot', 'Apple', 'search_engine' ),
			'amzn-user'            => array( 'Amzn-User', 'Amazon', 'assistant' ),
			'amzn-searchbot'       => array( 'Amzn-SearchBot', 'Amazon', 'search' ),
			'amazonbot'            => array( 'Amazonbot', 'Amazon', 'training' ),
			'meta-externalfetcher' => array( 'Meta-ExternalFetcher', 'Meta', 'assistant' ),
			'meta-externalagent'   => array( 'Meta-ExternalAgent', 'Meta', 'training' ),
			'facebookbot'          => array( 'FacebookBot', 'Meta', 'training' ),
			'duckassistbot'        => array( 'DuckAssistBot', 'DuckDuckGo', 'assistant' ),
			'duckduckbot'          => array( 'DuckDuckBot', 'DuckDuckGo', 'search_engine' ),
			'mistralai-user'       => array( 'MistralAI-User', 'Mistral', 'assistant' ),
			'cohere-ai'            => array( 'Cohere', 'Cohere', 'assistant' ),
			'cohere-training'      => array( 'Cohere-Training', 'Cohere', 'training' ),
			'youbot'               => array( 'YouBot', 'You.com', 'search' ),
			'phindbot'             => array( 'PhindBot', 'Phind', 'search' ),
			'kagibot'              => array( 'Kagibot', 'Kagi', 'search' ),
			'ccbot'                => array( 'CCBot', 'Common Crawl', 'training' ),
			'bytespider'           => array( 'Bytespider', 'ByteDance', 'training' ),
			'ai2bot'               => array( 'AI2Bot', 'Allen Institute', 'training' ),
			'diffbot'              => array( 'Diffbot', 'Diffbot', 'training' ),
			'timpibot'             => array( 'Timpibot', 'Timpi', 'training' ),
			'petalbot'             => array( 'PetalBot', 'Huawei', 'search_engine' ),
			'yandex'               => array( 'YandexBot', 'Yandex', 'search_engine' ),
			'baiduspider'          => array( 'Baiduspider', 'Baidu', 'search_engine' ),
			'firecrawl'            => array( 'Firecrawl', 'Firecrawl', 'tool' ),
			'jina'                 => array( 'Jina Reader', 'Jina AI', 'tool' ),
			'headlesschrome'       => array( 'Headless Chrome', '', 'tool' ),
			'python-requests'      => array( 'python-requests', '', 'tool' ),
			'python-httpx'         => array( 'httpx', '', 'tool' ),
			'aiohttp'              => array( 'aiohttp', '', 'tool' ),
			'axios'                => array( 'axios', '', 'tool' ),
			'node-fetch'           => array( 'node-fetch', '', 'tool' ),
			'undici'               => array( 'undici', '', 'tool' ),
			'go-http-client'       => array( 'Go HTTP client', '', 'tool' ),
			'curl'                 => array( 'curl', '', 'tool' ),
			'wget'                 => array( 'wget', '', 'tool' ),
			'rawimd'               => array( 'Rawi MD self-test', '', 'tool' ),
		);

		/**
		 * Filter the agent fingerprint table.
		 *
		 * @param array[] $catalog needle => array( label, operator, kind ).
		 */
		return (array) apply_filters( 'rawi_agent_catalog', $catalog );
	}

	/**
	 * Map a user agent string to a short readable label.
	 *
	 * @param string $user_agent Raw user agent.
	 * @return string
	 */
	public static function label( $user_agent ) {
		$user_agent = strtolower( (string) $user_agent );

		if ( '' === $user_agent ) {
			return 'unknown';
		}

		foreach ( self::catalog() as $needle => $info ) {
			if ( false !== strpos( $user_agent, (string) $needle ) ) {
				return (string) $info[0];
			}
		}

		if ( false !== strpos( $user_agent, 'chrome' ) || false !== strpos( $user_agent, 'firefox' ) || false !== strpos( $user_agent, 'safari' ) ) {
			return 'Chrome-like';
		}

		return 'other';
	}

	/**
	 * Details for a label previously produced by label().
	 *
	 * Labels recorded by 1.2.x ("Claude", "ChatGPT", "Meta", ...) are mapped
	 * too, so older log rows are grouped correctly on the dashboard.
	 *
	 * @param string $label Label.
	 * @return array{operator:string,kind:string}
	 */
	public static function info( $label ) {
		static $index = null;

		if ( null === $index ) {
			$index = array();

			foreach ( self::catalog() as $info ) {
				$index[ (string) $info[0] ] = array(
					'operator' => (string) $info[1],
					'kind'     => (string) $info[2],
				);
			}

			$legacy = array(
				'Claude'          => array( 'Anthropic', 'assistant' ),
				'ChatGPT'         => array( 'OpenAI', 'assistant' ),
				'Perplexity'      => array( 'Perplexity', 'assistant' ),
				'Google-Extended' => array( 'Google', 'training' ),
				'Meta'            => array( 'Meta', 'training' ),
				'Mistral'         => array( 'Mistral', 'assistant' ),
				'Chrome-like'     => array( '', 'browser' ),
				'other'           => array( '', 'other' ),
				'unknown'         => array( '', 'other' ),
			);

			foreach ( $legacy as $name => $pair ) {
				if ( ! isset( $index[ $name ] ) ) {
					$index[ $name ] = array(
						'operator' => $pair[0],
						'kind'     => $pair[1],
					);
				}
			}
		}

		return isset( $index[ $label ] ) ? $index[ $label ] : array(
			'operator' => '',
			'kind'     => 'other',
		);
	}

	/**
	 * Human labels for agent kinds.
	 *
	 * @return string[]
	 */
	public static function kinds() {
		return array(
			'assistant'     => __( 'AI assistants (live)', 'rawi-md' ),
			'search'        => __( 'AI search indexes', 'rawi-md' ),
			'training'      => __( 'AI training crawlers', 'rawi-md' ),
			'search_engine' => __( 'Search engines', 'rawi-md' ),
			'tool'          => __( 'Scripts and tools', 'rawi-md' ),
			'browser'       => __( 'Browsers', 'rawi-md' ),
			'other'         => __( 'Other', 'rawi-md' ),
		);
	}
}
