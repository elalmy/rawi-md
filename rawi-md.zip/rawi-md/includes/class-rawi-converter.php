<?php
/**
 * HTML to Markdown conversion.
 *
 * Written against DOMDocument with no external dependency, so the plugin can
 * ship on WordPress.org without Composer and can never fatal because another
 * plugin loaded a different version of the same library.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Converter
 */
class RAWI_Converter {

	/**
	 * Base URL used to absolutise relative links.
	 *
	 * @var string
	 */
	private $base_url = '';

	/**
	 * Constructor.
	 *
	 * @param string $base_url Base URL for relative link resolution.
	 */
	public function __construct( $base_url = '' ) {
		$this->base_url = $base_url ? $base_url : home_url( '/' );
	}

	/**
	 * Is the DOM extension available?
	 *
	 * Without it there is no conversion at all. Some minimal hosting builds
	 * ship PHP without ext-dom, and silently returning an empty document would
	 * be worse than not answering: the agent would cache an empty page.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return class_exists( 'DOMDocument' ) && class_exists( 'DOMXPath' );
	}

	/**
	 * Convert an HTML fragment or document to Markdown.
	 *
	 * @param string   $html              HTML source.
	 * @param string[] $content_selectors Optional content-root selectors, first match wins.
	 * @param string[] $strip_selectors   Selectors removed before conversion.
	 * @return string
	 */
	public function convert( $html, array $content_selectors = array(), array $strip_selectors = array() ) {
		$html = (string) $html;

		if ( '' === trim( $html ) || ! self::is_available() ) {
			return '';
		}

		// This runs on the front end. If libxml throws on malformed markup we
		// return nothing and the router falls back to the normal HTML page,
		// rather than taking the site down for whoever asked.
		try {
			return $this->do_convert( $html, $content_selectors, $strip_selectors );
		} catch ( Throwable $e ) {
			return '';
		}
	}

	/**
	 * The actual conversion, called only from convert().
	 *
	 * @param string   $html              HTML source.
	 * @param string[] $content_selectors Content-root selectors.
	 * @param string[] $strip_selectors   Selectors removed before conversion.
	 * @return string
	 */
	private function do_convert( $html, array $content_selectors, array $strip_selectors ) {
		$dom = $this->load( $html );

		if ( ! $dom ) {
			return '';
		}

		$xpath = new DOMXPath( $dom );

		// Always drop these, regardless of settings.
		$this->remove_by_xpath( $xpath, '//script|//style|//noscript|//template|//svg|//iframe[not(@src)]' );

		if ( ! empty( $strip_selectors ) ) {
			foreach ( $strip_selectors as $selector ) {
				$expr = self::css_to_xpath( $selector );
				if ( $expr ) {
					$this->remove_by_xpath( $xpath, $expr );
				}
			}
		}

		$root = null;

		foreach ( $content_selectors as $selector ) {
			$expr = self::css_to_xpath( $selector );

			if ( ! $expr ) {
				continue;
			}

			$found = $xpath->query( $expr );

			if ( $found instanceof DOMNodeList && $found->length > 0 ) {
				$root = $found->item( 0 );
				break;
			}
		}

		if ( ! $root ) {
			$body = $dom->getElementsByTagName( 'body' );
			$root = ( $body->length > 0 ) ? $body->item( 0 ) : $dom->documentElement;
		}

		if ( ! $root ) {
			return '';
		}

		$markdown = $this->render_children( $root, 0 );

		return $this->tidy( $markdown );
	}

	/**
	 * Load HTML into a DOMDocument, UTF-8 safe.
	 *
	 * @param string $html HTML source.
	 * @return DOMDocument|null
	 */
	private function load( $html ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return null;
		}

		// Wrap fragments so the parser always has a body.
		if ( false === stripos( $html, '<body' ) ) {
			$html = '<html><body>' . $html . '</body></html>';
		}

		// Force UTF-8 interpretation without relying on mb_convert_encoding,
		// which is deprecated for HTML-ENTITIES on PHP 8.2+.
		$html = '<?xml encoding="UTF-8">' . $html;

		$dom = new DOMDocument( '1.0', 'UTF-8' );

		$previous = libxml_use_internal_errors( true );

		$loaded = $dom->loadHTML( $html, LIBXML_NOERROR | LIBXML_NOWARNING );

		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if ( ! $loaded ) {
			return null;
		}

		// Remove the XML processing instruction we injected.
		foreach ( iterator_to_array( $dom->childNodes ) as $child ) {
			if ( XML_PI_NODE === $child->nodeType ) {
				$dom->removeChild( $child );
			}
		}

		return $dom;
	}

	/**
	 * Remove every node matching an XPath expression.
	 *
	 * @param DOMXPath $xpath XPath engine.
	 * @param string   $expr  Expression.
	 * @return void
	 */
	private function remove_by_xpath( DOMXPath $xpath, $expr ) {
		$nodes = $xpath->query( $expr );

		if ( ! $nodes instanceof DOMNodeList ) {
			return;
		}

		foreach ( iterator_to_array( $nodes ) as $node ) {
			if ( $node->parentNode ) {
				$node->parentNode->removeChild( $node );
			}
		}
	}

	/**
	 * Translate a small subset of CSS selectors into XPath.
	 *
	 * Supports: tag, .class, #id, tag.class, tag#id, comma lists and the
	 * descendant combinator. Anything more exotic is ignored on purpose.
	 *
	 * @param string $selector CSS selector.
	 * @return string Empty string when the selector is unsupported.
	 */
	public static function css_to_xpath( $selector ) {
		$selector = trim( (string) $selector );

		if ( '' === $selector ) {
			return '';
		}

		$groups = array_map( 'trim', explode( ',', $selector ) );
		$paths  = array();

		foreach ( $groups as $group ) {
			if ( '' === $group ) {
				continue;
			}

			$parts = preg_split( '/\s+/', $group );
			$path  = '';

			foreach ( (array) $parts as $part ) {
				$compiled = self::compile_simple_selector( $part );

				if ( '' === $compiled ) {
					$path = '';
					break;
				}

				$path .= '//' . $compiled;
			}

			if ( '' !== $path ) {
				$paths[] = $path;
			}
		}

		return implode( '|', $paths );
	}

	/**
	 * Compile one simple selector such as div.entry-content.
	 *
	 * @param string $part Simple selector.
	 * @return string
	 */
	private static function compile_simple_selector( $part ) {
		if ( ! preg_match( '/^([a-zA-Z][a-zA-Z0-9-]*)?((?:[.#][A-Za-z0-9_-]+)*)$/', $part, $m ) ) {
			return '';
		}

		$tag        = ! empty( $m[1] ) ? strtolower( $m[1] ) : '*';
		$predicates = array();

		if ( ! empty( $m[2] ) && preg_match_all( '/([.#])([A-Za-z0-9_-]+)/', $m[2], $tokens, PREG_SET_ORDER ) ) {
			foreach ( $tokens as $token ) {
				if ( '.' === $token[1] ) {
					$predicates[] = sprintf(
						'contains(concat(" ", normalize-space(@class), " "), " %s ")',
						$token[2]
					);
				} else {
					$predicates[] = sprintf( '@id="%s"', $token[2] );
				}
			}
		}

		if ( '*' === $tag && empty( $predicates ) ) {
			return '';
		}

		return $tag . ( $predicates ? '[' . implode( ' and ', $predicates ) . ']' : '' );
	}

	/**
	 * Render every child of a node.
	 *
	 * @param DOMNode $node   Parent node.
	 * @param int     $indent Current list indent depth.
	 * @return string
	 */
	private function render_children( DOMNode $node, $indent ) {
		$out = '';

		if ( ! $node->hasChildNodes() ) {
			return $out;
		}

		foreach ( $node->childNodes as $child ) {
			$out .= $this->render_node( $child, $indent );
		}

		return $out;
	}

	/**
	 * Render a single node.
	 *
	 * @param DOMNode $node   Node.
	 * @param int     $indent Current list indent depth.
	 * @return string
	 */
	private function render_node( DOMNode $node, $indent ) {
		if ( XML_TEXT_NODE === $node->nodeType ) {
			return $this->escape( $this->collapse( $node->textContent ) );
		}

		if ( XML_CDATA_SECTION_NODE === $node->nodeType ) {
			return $this->escape( $this->collapse( $node->textContent ) );
		}

		if ( XML_ELEMENT_NODE !== $node->nodeType ) {
			return '';
		}

		$tag = strtolower( $node->nodeName );

		switch ( $tag ) {
			case 'h1':
			case 'h2':
			case 'h3':
			case 'h4':
			case 'h5':
			case 'h6':
				$level = (int) substr( $tag, 1 );
				$text  = $this->render_children( $node, $indent );
				// A heading is a single line; a <br> inside it must not end it.
				$text = trim( (string) preg_replace( '/\s*\n\s*/', ' ', $text ) );
				return ( '' === $text ) ? '' : "\n\n" . str_repeat( '#', $level ) . ' ' . $text . "\n\n";

			case 'p':
				$text = trim( $this->render_children( $node, $indent ) );
				return ( '' === $text ) ? '' : "\n\n" . $this->escape_block_start( $text ) . "\n\n";

			case 'br':
				return "  \n";

			case 'hr':
				return "\n\n---\n\n";

			case 'strong':
			case 'b':
				return $this->wrap_inline( $this->render_children( $node, $indent ), '**' );

			case 'em':
			case 'i':
				return $this->wrap_inline( $this->render_children( $node, $indent ), '*' );

			case 'del':
			case 's':
			case 'strike':
				return $this->wrap_inline( $this->render_children( $node, $indent ), '~~' );

			case 'code':
			case 'kbd':
			case 'samp':
			case 'tt':
				if ( $this->has_ancestor( $node, 'pre' ) ) {
					return $node->textContent;
				}
				return $this->render_inline_code( $this->collapse( $node->textContent ) );

			case 'iframe':
			case 'embed':
			case 'object':
				return $this->render_embed( $node );

			case 'video':
			case 'audio':
				return $this->render_media( $node );

			case 'dl':
				return $this->render_definition_list( $node, $indent );

			case 'summary':
				$text = trim( $this->render_children( $node, $indent ) );
				return ( '' === $text ) ? '' : "\n\n**" . $text . "**\n\n";

			case 'picture':
				return $this->render_children( $node, $indent );

			case 'source':
			case 'track':
			case 'input':
			case 'select':
			case 'textarea':
			case 'option':
			case 'canvas':
			case 'map':
				return '';

			case 'pre':
				return $this->render_pre( $node );

			case 'a':
				return $this->render_link( $node, $indent );

			case 'img':
				return $this->render_image( $node );

			case 'figure':
				return "\n\n" . trim( $this->render_children( $node, $indent ) ) . "\n\n";

			case 'figcaption':
				$text = trim( $this->render_children( $node, $indent ) );
				return ( '' === $text ) ? '' : "\n\n*" . $text . "*\n\n";

			case 'ul':
			case 'ol':
				return $this->render_list( $node, $indent );

			case 'li':
				// Handled by render_list(); a stray li is rendered as a paragraph.
				return trim( $this->render_children( $node, $indent ) );

			case 'blockquote':
				return $this->render_blockquote( $node, $indent );

			case 'table':
				return $this->render_table( $node );

			case 'head':
			case 'title':
			case 'meta':
			case 'link':
				return '';

			default:
				// Phrasing elements: rendering them as blocks split sentences
				// into separate paragraphs. bdi and bdo matter for Arabic, where
				// they wrap every embedded Latin word or number.
				$inline = array(
					'span', 'small', 'big', 'sub', 'sup', 'abbr', 'acronym', 'cite', 'q', 'mark',
					'time', 'u', 'font', 'label', 'bdi', 'bdo', 'ins', 'var', 'dfn', 'data',
					'wbr', 'button', 'output', 'meter', 'progress', 'ruby', 'rt', 'rp', 'nobr',
				);

				if ( in_array( $tag, $inline, true ) ) {
					return $this->render_children( $node, $indent );
				}

				// Treat every other element as a block container.
				$text = $this->render_children( $node, $indent );
				return ( '' === trim( $text ) ) ? '' : "\n\n" . trim( $text ) . "\n\n";
		}
	}

	/**
	 * Render a preformatted block as a fenced code block.
	 *
	 * @param DOMNode $node Pre element.
	 * @return string
	 */
	private function render_pre( DOMNode $node ) {
		$code = $node->textContent;
		$code = str_replace( "\r\n", "\n", $code );
		$code = trim( $code, "\n" );

		if ( '' === trim( $code ) ) {
			return '';
		}

		$language = '';

		if ( $node instanceof DOMElement ) {
			$class = $node->getAttribute( 'class' );

			$inner = $node->getElementsByTagName( 'code' );
			if ( $inner->length > 0 && $inner->item( 0 ) instanceof DOMElement ) {
				$class .= ' ' . $inner->item( 0 )->getAttribute( 'class' );
			}

			if ( preg_match( '/(?:language|lang|brush)[-:]([A-Za-z0-9#+_-]+)/i', $class, $m ) ) {
				$language = strtolower( $m[1] );
			}
		}

		// Widen the fence if the code itself contains backtick fences.
		$fence = '```';
		if ( preg_match_all( '/^(`{3,})/m', $code, $matches ) ) {
			$longest = 3;
			foreach ( $matches[1] as $run ) {
				$longest = max( $longest, strlen( $run ) );
			}
			$fence = str_repeat( '`', $longest + 1 );
		}

		return "\n\n" . $fence . $language . "\n" . $code . "\n" . $fence . "\n\n";
	}

	/**
	 * Render an anchor.
	 *
	 * @param DOMNode $node   Anchor element.
	 * @param int     $indent Indent depth.
	 * @return string
	 */
	private function render_link( DOMNode $node, $indent ) {
		$raw = $this->render_children( $node, $indent );

		if ( ! $node instanceof DOMElement ) {
			return $raw;
		}

		$href = trim( $node->getAttribute( 'href' ) );

		if ( '' === $href || 0 === strpos( $href, '#' ) || 0 === stripos( $href, 'javascript:' ) ) {
			return $raw;
		}

		$text = trim( $raw );

		if ( '' === $text ) {
			return ( '' === $raw ) ? '' : ' ';
		}

		// Keep the whitespace that separated the link from its neighbours.
		preg_match( '/^(\s*).*?(\s*)$/su', $raw, $edges );

		$lead  = isset( $edges[1] ) && '' !== $edges[1] ? ' ' : '';
		$trail = isset( $edges[2] ) && '' !== $edges[2] ? ' ' : '';

		$href  = $this->absolutise( $href );
		$title = $this->collapse( $node->getAttribute( 'title' ) );
		$title = ( '' !== trim( $title ) && trim( $title ) !== $text )
			? ' "' . str_replace( '"', '\\"', trim( $title ) ) . '"'
			: '';

		return $lead . '[' . preg_replace( '/\s*\n\s*/', ' ', $text ) . '](' . $this->escape_url( $href ) . $title . ')' . $trail;
	}

	/**
	 * Wrap inline content in an emphasis marker without eating its spaces.
	 *
	 * "foo<strong> bar</strong>" must become "foo **bar**", not "foo**bar**",
	 * which reads as one word and is not even emphasis to most parsers.
	 *
	 * @param string $raw    Rendered children.
	 * @param string $marker Marker placed on both sides.
	 * @return string
	 */
	private function wrap_inline( $raw, $marker ) {
		$raw = (string) $raw;

		if ( '' === trim( $raw ) ) {
			return ( '' === $raw ) ? '' : ' ';
		}

		if ( ! preg_match( '/^(\s*)(.*?)(\s*)$/su', $raw, $m ) ) {
			return $marker . trim( $raw ) . $marker;
		}

		$lead  = '' !== $m[1] ? ' ' : '';
		$trail = '' !== $m[3] ? ' ' : '';

		return $lead . $marker . $m[2] . $marker . $trail;
	}

	/**
	 * Inline code, fenced wide enough for any backticks it contains.
	 *
	 * @param string $text Code text.
	 * @return string
	 */
	private function render_inline_code( $text ) {
		$text = (string) $text;

		if ( '' === trim( $text ) ) {
			return '';
		}

		$longest = 0;

		if ( preg_match_all( '/`+/', $text, $runs ) ) {
			foreach ( $runs[0] as $run ) {
				$longest = max( $longest, strlen( $run ) );
			}
		}

		$fence = str_repeat( '`', $longest + 1 );
		$pad   = ( $longest > 0 || 0 === strpos( $text, '`' ) ) ? ' ' : '';

		return $fence . $pad . trim( $text ) . $pad . $fence;
	}

	/**
	 * An embedded frame (YouTube, Vimeo, maps, forms) as a plain link.
	 *
	 * Agents cannot run the frame, but the address tells them what is there.
	 *
	 * @param DOMNode $node iframe, embed or object element.
	 * @return string
	 */
	private function render_embed( DOMNode $node ) {
		if ( ! $node instanceof DOMElement ) {
			return '';
		}

		$src = '';

		foreach ( array( 'src', 'data-src', 'data-lazy-src', 'data' ) as $attr ) {
			$candidate = trim( $node->getAttribute( $attr ) );

			if ( '' !== $candidate && 0 !== strpos( $candidate, 'about:' ) && 0 !== stripos( $candidate, 'javascript:' ) ) {
				$src = $candidate;
				break;
			}
		}

		if ( '' === $src ) {
			return '';
		}

		$src   = $this->absolutise( $src );
		$label = trim( $this->collapse( $node->getAttribute( 'title' ) ) );

		if ( '' === $label ) {
			$host  = (string) wp_parse_url( $src, PHP_URL_HOST );
			$label = '' !== $host ? 'Embed: ' . preg_replace( '/^www\./', '', $host ) : 'Embed';
		}

		return "\n\n[" . $this->escape( $label ) . '](' . $this->escape_url( $src ) . ")\n\n";
	}

	/**
	 * A video or audio element as a link to its first source.
	 *
	 * @param DOMNode $node video or audio element.
	 * @return string
	 */
	private function render_media( DOMNode $node ) {
		if ( ! $node instanceof DOMElement ) {
			return '';
		}

		$src = trim( $node->getAttribute( 'src' ) );

		if ( '' === $src ) {
			foreach ( $node->getElementsByTagName( 'source' ) as $source ) {
				$candidate = trim( $source->getAttribute( 'src' ) );

				if ( '' !== $candidate ) {
					$src = $candidate;
					break;
				}
			}
		}

		if ( '' === $src || 0 === strpos( $src, 'blob:' ) ) {
			return '';
		}

		$src   = $this->absolutise( $src );
		$label = trim( $this->collapse( $node->getAttribute( 'title' ) ) );

		if ( '' === $label ) {
			$path  = (string) wp_parse_url( $src, PHP_URL_PATH );
			$file  = '' !== $path ? rawurldecode( basename( $path ) ) : '';
			$label = ucfirst( strtolower( $node->nodeName ) ) . ( '' !== $file ? ': ' . $file : '' );
		}

		return "\n\n[" . $this->escape( $label ) . '](' . $this->escape_url( $src ) . ")\n\n";
	}

	/**
	 * A definition list as a bullet list of bold terms.
	 *
	 * Markdown has no definition list, and this is the shape every parser and
	 * every model reads correctly.
	 *
	 * @param DOMNode $node   dl element.
	 * @param int     $indent Indent depth.
	 * @return string
	 */
	private function render_definition_list( DOMNode $node, $indent ) {
		$items = array();
		$term  = '';

		$children = array();

		foreach ( $node->childNodes as $child ) {
			// Some markup wraps each pair in a <div>, which HTML allows.
			if ( XML_ELEMENT_NODE === $child->nodeType && 'div' === strtolower( $child->nodeName ) ) {
				foreach ( $child->childNodes as $grandchild ) {
					$children[] = $grandchild;
				}
				continue;
			}

			$children[] = $child;
		}

		foreach ( $children as $child ) {
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				continue;
			}

			$name = strtolower( $child->nodeName );
			$text = trim( (string) preg_replace( '/\s*\n\s*/', ' ', $this->tidy( $this->render_children( $child, $indent + 1 ) ) ) );

			if ( '' === $text ) {
				continue;
			}

			if ( 'dt' === $name ) {
				if ( '' !== $term ) {
					$items[] = '- **' . $term . '**';
				}
				$term = $text;
			} elseif ( 'dd' === $name ) {
				$items[] = '' !== $term ? '- **' . $term . '**: ' . $text : '- ' . $text;
				$term    = '';
			}
		}

		if ( '' !== $term ) {
			$items[] = '- **' . $term . '**';
		}

		return empty( $items ) ? '' : "\n\n" . implode( "\n", $items ) . "\n\n";
	}

	/**
	 * Escape a marker at the start of a block that would otherwise turn plain
	 * text into a heading, list item or quote.
	 *
	 * "1. Introduction" written as a paragraph stays a paragraph.
	 *
	 * @param string $text Block text.
	 * @return string
	 */
	private function escape_block_start( $text ) {
		$text = (string) $text;

		// Only plain text: anything starting with Markdown we produced
		// ourselves (a list, a table, a quote, a fence) is left alone.
		if ( preg_match( '/^(?:\*\*|\*|~~|`|!\[|\[|\|)/', $text ) ) {
			return $text;
		}

		$escaped = preg_replace( '/^(#{1,6})(\s)/', '\\\\$1$2', $text, 1 );
		$escaped = preg_replace( '/^([+\-])(\s)/', '\\\\$1$2', (string) $escaped, 1 );
		$escaped = preg_replace( '/^>(\s)/', '\\\\>$1', (string) $escaped, 1 );
		$escaped = preg_replace( '/^(\d{1,9})([.)])(\s)/', '$1\\\\$2$3', (string) $escaped, 1 );

		return null === $escaped ? $text : $escaped;
	}

	/**
	 * Render an image.
	 *
	 * @param DOMNode $node Image element.
	 * @return string
	 */
	private function render_image( DOMNode $node ) {
		if ( ! $node instanceof DOMElement ) {
			return '';
		}

		$src = trim( $node->getAttribute( 'src' ) );

		// Lazy-loaded themes often park the real URL in a data attribute.
		if ( '' === $src || 0 === strpos( $src, 'data:' ) ) {
			foreach ( array( 'data-src', 'data-lazy-src', 'data-original' ) as $attr ) {
				$candidate = trim( $node->getAttribute( $attr ) );
				if ( '' !== $candidate ) {
					$src = $candidate;
					break;
				}
			}
		}

		if ( '' === $src || 0 === strpos( $src, 'data:' ) ) {
			return '';
		}

		// Tracking pixels and spacers carry nothing an agent can use.
		if ( '1' === trim( $node->getAttribute( 'width' ) ) && '1' === trim( $node->getAttribute( 'height' ) ) ) {
			return '';
		}

		$alt = $this->collapse( $node->getAttribute( 'alt' ) );

		return '![' . $this->escape( $alt ) . '](' . $this->escape_url( $this->absolutise( $src ) ) . ')';
	}

	/**
	 * Render an ordered or unordered list, including nesting.
	 *
	 * @param DOMNode $node   List element.
	 * @param int     $indent Indent depth.
	 * @return string
	 */
	private function render_list( DOMNode $node, $indent ) {
		$ordered = ( 'ol' === strtolower( $node->nodeName ) );
		$start   = 1;

		if ( $ordered && $node instanceof DOMElement && $node->getAttribute( 'start' ) ) {
			$start = max( 1, (int) $node->getAttribute( 'start' ) );
		}

		$pad   = str_repeat( '  ', $indent );
		$lines = array();
		$index = $start;

		foreach ( $node->childNodes as $child ) {
			if ( XML_ELEMENT_NODE !== $child->nodeType || 'li' !== strtolower( $child->nodeName ) ) {
				continue;
			}

			$body = $this->render_children( $child, $indent + 1 );
			$body = $this->tidy( $body );

			if ( '' === trim( $body ) ) {
				continue;
			}

			$marker = $ordered ? ( $index . '. ' ) : '- ';
			$index++;

			$body_lines = explode( "\n", $body );
			$first      = array_shift( $body_lines );
			$line       = $pad . $marker . $first;

			foreach ( $body_lines as $extra ) {
				$line .= "\n" . ( '' === trim( $extra ) ? '' : $pad . '  ' . $extra );
			}

			$lines[] = rtrim( $line );
		}

		if ( empty( $lines ) ) {
			return '';
		}

		return "\n\n" . implode( "\n", $lines ) . "\n\n";
	}

	/**
	 * Render a blockquote.
	 *
	 * @param DOMNode $node   Blockquote element.
	 * @param int     $indent Indent depth.
	 * @return string
	 */
	private function render_blockquote( DOMNode $node, $indent ) {
		$inner = $this->tidy( $this->render_children( $node, $indent ) );

		if ( '' === trim( $inner ) ) {
			return '';
		}

		$lines = explode( "\n", $inner );
		$out   = array();

		foreach ( $lines as $line ) {
			$out[] = ( '' === trim( $line ) ) ? '>' : '> ' . $line;
		}

		return "\n\n" . implode( "\n", $out ) . "\n\n";
	}

	/**
	 * Render a table as a GitHub-flavoured Markdown table.
	 *
	 * @param DOMNode $node Table element.
	 * @return string
	 */
	private function render_table( DOMNode $node ) {
		if ( ! $node instanceof DOMElement ) {
			return '';
		}

		$rows = array();

		// Only this table's own rows: getElementsByTagName() would also pull
		// in every row of a table nested inside a cell.
		$own_rows = array();

		foreach ( $node->childNodes as $section ) {
			if ( XML_ELEMENT_NODE !== $section->nodeType ) {
				continue;
			}

			$section_name = strtolower( $section->nodeName );

			if ( 'tr' === $section_name ) {
				$own_rows[] = $section;
				continue;
			}

			if ( in_array( $section_name, array( 'thead', 'tbody', 'tfoot' ), true ) ) {
				foreach ( $section->childNodes as $row ) {
					if ( XML_ELEMENT_NODE === $row->nodeType && 'tr' === strtolower( $row->nodeName ) ) {
						$own_rows[] = $row;
					}
				}
			}
		}

		foreach ( $own_rows as $tr ) {
			$cells = array();

			foreach ( $tr->childNodes as $cell ) {
				if ( XML_ELEMENT_NODE !== $cell->nodeType ) {
					continue;
				}

				$name = strtolower( $cell->nodeName );

				if ( 'td' !== $name && 'th' !== $name ) {
					continue;
				}

				$text = trim( $this->render_children( $cell, 0 ) );
				$text = str_replace( array( "\n", '|' ), array( ' ', '\\|' ), $text );

				$cells[] = trim( preg_replace( '/\s+/u', ' ', $text ) );
			}

			if ( ! empty( $cells ) ) {
				$rows[] = $cells;
			}
		}

		if ( empty( $rows ) ) {
			return '';
		}

		$columns = 0;
		foreach ( $rows as $row ) {
			$columns = max( $columns, count( $row ) );
		}

		if ( $columns < 1 ) {
			return '';
		}

		$header = array_shift( $rows );
		$header = array_pad( $header, $columns, '' );

		$out   = array();
		$out[] = '| ' . implode( ' | ', $header ) . ' |';
		$out[] = '|' . str_repeat( ' --- |', $columns );

		foreach ( $rows as $row ) {
			$row   = array_pad( $row, $columns, '' );
			$out[] = '| ' . implode( ' | ', $row ) . ' |';
		}

		return "\n\n" . implode( "\n", $out ) . "\n\n";
	}

	/**
	 * Does the node sit inside an ancestor with the given tag name?
	 *
	 * @param DOMNode $node Node.
	 * @param string  $tag  Tag name.
	 * @return bool
	 */
	private function has_ancestor( DOMNode $node, $tag ) {
		$parent = $node->parentNode;

		while ( $parent instanceof DOMNode ) {
			if ( XML_ELEMENT_NODE === $parent->nodeType && strtolower( $parent->nodeName ) === $tag ) {
				return true;
			}
			$parent = $parent->parentNode;
		}

		return false;
	}

	/**
	 * Collapse runs of whitespace into single spaces.
	 *
	 * @param string $text Raw text.
	 * @return string
	 */
	private function collapse( $text ) {
		$text = str_replace( "\xC2\xA0", ' ', (string) $text );
		$text = preg_replace( '/\s+/u', ' ', $text );

		return null === $text ? '' : $text;
	}

	/**
	 * Escape Markdown control characters.
	 *
	 * Deliberately conservative: underscores are left alone because escaping
	 * them mangles mixed Arabic/English technical text far more often than it
	 * prevents accidental emphasis.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private function escape( $text ) {
		$text = str_replace(
			array( '\\', '`', '*', '[', ']' ),
			array( '\\\\', '\\`', '\\*', '\\[', '\\]' ),
			(string) $text
		);

		return $text;
	}

	/**
	 * Escape parentheses inside a URL so the link target stays intact.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	private function escape_url( $url ) {
		return str_replace( array( '(', ')', ' ' ), array( '%28', '%29', '%20' ), (string) $url );
	}

	/**
	 * Turn a relative URL into an absolute one.
	 *
	 * @param string $url URL, possibly relative.
	 * @return string
	 */
	private function absolutise( $url ) {
		$url = (string) $url;

		if ( preg_match( '#^[a-z][a-z0-9+.-]*:#i', $url ) ) {
			return $url;
		}

		$parts = wp_parse_url( $this->base_url );

		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return $url;
		}

		// Protocol-relative: borrow the page's scheme.
		if ( 0 === strpos( $url, '//' ) ) {
			return $parts['scheme'] . ':' . $url;
		}

		$origin = $parts['scheme'] . '://' . $parts['host'] . ( ! empty( $parts['port'] ) ? ':' . $parts['port'] : '' );

		if ( 0 === strpos( $url, '/' ) ) {
			return $origin . $url;
		}

		$base_path = isset( $parts['path'] ) ? (string) $parts['path'] : '/';

		if ( 0 === strpos( $url, '?' ) ) {
			return $origin . $base_path . $url;
		}

		// Relative to the page's directory, as a browser would resolve it.
		$dir      = ( '/' === substr( $base_path, -1 ) ) ? $base_path : trailingslashit( dirname( $base_path ) );
		$segments = explode( '/', $dir . $url );
		$resolved = array();

		foreach ( $segments as $segment ) {
			if ( '..' === $segment ) {
				array_pop( $resolved );
			} elseif ( '.' !== $segment ) {
				$resolved[] = $segment;
			}
		}

		$path = implode( '/', $resolved );

		return $origin . ( 0 === strpos( $path, '/' ) ? '' : '/' ) . $path;
	}

	/**
	 * Normalise blank lines and trailing whitespace.
	 *
	 * @param string $markdown Raw markdown.
	 * @return string
	 */
	private function tidy( $markdown ) {
		$markdown = str_replace( "\r\n", "\n", (string) $markdown );

		// Strip trailing spaces except deliberate two-space line breaks.
		// A lone trailing space or tab, three or more spaces, or a blank
		// line of spaces go; exactly two spaces after text are a <br>.
		$markdown = preg_replace( '/(?<=\S) $|\t+$|[ \t]{3,}$|^[ \t]+$/m', '', $markdown );

		// Collapse three or more newlines into a paragraph break.
		$markdown = preg_replace( '/\n{3,}/', "\n\n", (string) $markdown );

		return trim( (string) $markdown );
	}

	/**
	 * Rough token estimate.
	 *
	 * Latin text averages about four characters per token, Arabic script is far
	 * denser, so the two are counted separately. This is an estimate, not a
	 * tokenizer.
	 *
	 * @param string $text Text to measure.
	 * @return int
	 */
	public static function estimate_tokens( $text ) {
		$text = (string) $text;

		if ( '' === $text ) {
			return 0;
		}

		$total = function_exists( 'mb_strlen' ) ? mb_strlen( $text, 'UTF-8' ) : strlen( $text );
		$ascii = preg_match_all( '/[\x00-\x7F]/', $text );

		if ( false === $ascii ) {
			$ascii = 0;
		}

		$non_ascii = max( 0, $total - $ascii );

		return (int) max( 1, ceil( ( $ascii / 4 ) + ( $non_ascii / 2 ) ) );
	}
}
