<?php
/**
 * Serves /llms.txt: a Markdown index of the site that points agents straight
 * at the Markdown version of every eligible page.
 *
 * Format follows the llms.txt proposal: an H1 with the site name, a block
 * quote summary, optional prose, then H2 sections of links.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Llms
 */
class RAWI_Llms {

	const TRANSIENT = 'rawi_llms_txt';

	/**
	 * Whether the last build() call was answered from the cache.
	 *
	 * @var bool
	 */
	private static $from_cache = false;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ), -1 );
	}

	/**
	 * Public URL of the index.
	 *
	 * @return string
	 */
	public static function url() {
		return get_option( 'permalink_structure' )
			? home_url( '/llms.txt' )
			: add_query_arg( 'rawi_llms', '1', home_url( '/' ) );
	}

	/**
	 * Answer /llms.txt.
	 *
	 * @return void
	 */
	public static function maybe_serve() {
		if ( ! get_query_var( 'rawi_llms' ) ) {
			return;
		}

		if ( ! RAWI_Settings::get( 'llms_enabled' ) ) {
			RAWI_Router::not_found();
			return;
		}

		RAWI_Cache_Compat::disable_page_cache();

		$body   = self::build();
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';

		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		if ( ! headers_sent() ) {
			header_remove( 'Expires' );
			header_remove( 'Pragma' );
			header_remove( 'Cache-Control' );

			status_header( 200 );
			header( 'Content-Type: text/plain; charset=' . get_option( 'blog_charset', 'UTF-8' ) );
			header( 'Cache-Control: public, max-age=3600' );
			header( 'X-Robots-Tag: noindex, follow' );
			header( 'X-Markdown-Generator: rawi-md/' . RAWI_VERSION );

			if ( ! ini_get( 'zlib.output_compression' ) ) {
				header( 'Content-Length: ' . strlen( $body ) );
			}
		}

		if ( 'HEAD' !== $method ) {
			echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		RAWI_Router::finish_response();

		if ( 'HEAD' !== $method ) {
			RAWI_Logger::record(
				0,
				'llms',
				array(
					'tokens'    => RAWI_Converter::estimate_tokens( $body ),
					'cache_hit' => self::$from_cache,
				)
			);
		}

		exit;
	}

	/**
	 * Build (or read from cache) the index.
	 *
	 * @return string
	 */
	public static function build() {
		$cached = get_transient( self::TRANSIENT );

		self::$from_cache = is_string( $cached ) && '' !== $cached;

		if ( self::$from_cache ) {
			return $cached;
		}

		$name        = wp_strip_all_tags( html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ) );
		$description = wp_strip_all_tags( html_entity_decode( get_bloginfo( 'description' ), ENT_QUOTES, 'UTF-8' ) );
		$intro       = trim( (string) RAWI_Settings::get( 'llms_intro' ) );
		$limit       = max( 1, min( 500, absint( RAWI_Settings::get( 'llms_max_per_type' ) ) ) );

		$lines   = array();
		$lines[] = '# ' . ( '' !== $name ? $name : wp_parse_url( home_url(), PHP_URL_HOST ) );
		$lines[] = '';

		if ( '' !== $description ) {
			$lines[] = '> ' . $description;
			$lines[] = '';
		}

		if ( '' !== $intro ) {
			$lines[] = $intro;
			$lines[] = '';
		}

		$lines[] = sprintf(
			'Every page listed here is available as clean Markdown: append .md to its address, or request it with the header "Accept: text/markdown". Site: %s',
			home_url( '/' )
		);
		$lines[] = '';

		foreach ( RAWI_Settings::enabled_post_types() as $type ) {
			$object = get_post_type_object( $type );

			if ( ! $object || ! $object->public ) {
				continue;
			}

			$posts = get_posts(
				array(
					'post_type'        => $type,
					'post_status'      => 'publish',
					'has_password'     => false,
					'numberposts'      => $limit,
					'orderby'          => is_post_type_hierarchical( $type ) ? 'menu_order title' : 'modified',
					'order'            => is_post_type_hierarchical( $type ) ? 'ASC' : 'DESC',
					'suppress_filters' => false,
					'no_found_rows'    => true,
				)
			);

			$items = array();

			foreach ( $posts as $post ) {
				if ( ! RAWI_Eligibility::is_eligible( $post ) ) {
					continue;
				}

				$title = wp_strip_all_tags( html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ) );
				$title = '' !== $title ? $title : '#' . $post->ID;
				$line  = '- [' . str_replace( array( '[', ']' ), array( '\\[', '\\]' ), $title ) . '](' . RAWI_Router::markdown_url( $post ) . ')';
				$note  = self::summary( $post );

				if ( '' !== $note ) {
					$line .= ': ' . $note;
				}

				$items[] = $line;
			}

			if ( empty( $items ) ) {
				continue;
			}

			$lines[] = '## ' . wp_strip_all_tags( $object->labels->name );
			$lines[] = '';
			$lines   = array_merge( $lines, $items );
			$lines[] = '';
		}

		$body = implode( "\n", $lines ) . "\n";

		/**
		 * Filter the llms.txt document.
		 *
		 * @param string $body The generated index.
		 */
		$body = (string) apply_filters( 'rawi_llms_txt', $body );

		set_transient( self::TRANSIENT, $body, 12 * HOUR_IN_SECONDS );

		return $body;
	}

	/**
	 * One-line summary for an index entry.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	private static function summary( WP_Post $post ) {
		$text = '' !== trim( $post->post_excerpt )
			? $post->post_excerpt
			: wp_strip_all_tags( strip_shortcodes( $post->post_content ) );

		$text = trim( (string) preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $text ) ) );

		return '' === $text ? '' : wp_trim_words( $text, 18, '…' );
	}
}
