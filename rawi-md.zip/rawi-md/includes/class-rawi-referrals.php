<?php
/**
 * Counts people who arrive on the site from an AI assistant.
 *
 * The crawler log shows what AI systems read. This shows what that reading
 * is worth: humans who clicked through from ChatGPT, Perplexity, Gemini,
 * Copilot, Claude and others.
 *
 * Detection runs in the visitor's browser, because most page views are
 * answered by a page cache and never reach PHP. A tiny inline script looks at
 * document.referrer and utm_source; only when either points at an AI
 * assistant does it send one beacon to the site's own REST API. Nothing is
 * sent for any other visit, no cookie is set, and nothing goes to a third
 * party.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Referrals
 */
class RAWI_Referrals {

	const TABLE = 'rawi_referrals';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_route' ) );
		add_action( 'wp_footer', array( __CLASS__, 'print_beacon' ), 99 );
	}

	/**
	 * Fully qualified table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Create or upgrade the table. Additive only, like the request log.
	 *
	 * @return void
	 */
	public static function create_table() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			visited_at DATETIME NOT NULL,
			source VARCHAR(40) NOT NULL DEFAULT '',
			post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			url_path VARCHAR(255) NOT NULL DEFAULT '',
			via VARCHAR(10) NOT NULL DEFAULT '',
			visitor_hash CHAR(40) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY visited_at (visited_at),
			KEY post_id (post_id),
			KEY source (source)
		) {$collate};";

		dbDelta( $sql );
	}

	/**
	 * Assistant hostnames and the name shown for each.
	 *
	 * @return string[] host => label.
	 */
	public static function hosts() {
		return (array) apply_filters(
			'rawi_referral_hosts',
			array(
				'chatgpt.com'             => 'ChatGPT',
				'chat.openai.com'         => 'ChatGPT',
				'perplexity.ai'           => 'Perplexity',
				'gemini.google.com'       => 'Gemini',
				'bard.google.com'         => 'Gemini',
				'copilot.microsoft.com'   => 'Copilot',
				'copilot.cloud.microsoft' => 'Copilot',
				'edgeservices.bing.com'   => 'Copilot',
				'claude.ai'               => 'Claude',
				'chat.mistral.ai'         => 'Le Chat',
				'chat.deepseek.com'       => 'DeepSeek',
				'grok.com'                => 'Grok',
				'meta.ai'                 => 'Meta AI',
				'you.com'                 => 'You.com',
				'phind.com'               => 'Phind',
				'poe.com'                 => 'Poe',
				'chat.qwen.ai'            => 'Qwen',
				'kimi.com'                => 'Kimi',
				'kimi.moonshot.cn'        => 'Kimi',
				'duck.ai'                 => 'Duck.ai',
			)
		);
	}

	/**
	 * utm_source fragments assistants append to the links they cite.
	 *
	 * @return string[] fragment => label.
	 */
	public static function utm_sources() {
		return (array) apply_filters(
			'rawi_referral_utm',
			array(
				'chatgpt'    => 'ChatGPT',
				'openai'     => 'ChatGPT',
				'perplexity' => 'Perplexity',
				'gemini'     => 'Gemini',
				'copilot'    => 'Copilot',
				'claude'     => 'Claude',
				'mistral'    => 'Le Chat',
				'deepseek'   => 'DeepSeek',
				'grok'       => 'Grok',
			)
		);
	}

	/**
	 * Resolve a referrer host or utm_source to a known assistant.
	 *
	 * The browser only reports what it saw; the decision is made here
	 * against the whitelist, so a forged beacon cannot invent a source.
	 *
	 * @param string $host Referrer hostname.
	 * @param string $utm  utm_source value.
	 * @return array{0:string,1:string} label and via ('referrer' | 'utm'), or empty strings.
	 */
	public static function classify( $host, $utm ) {
		$host = strtolower( preg_replace( '/^www\./', '', trim( (string) $host ) ) );
		$utm  = strtolower( trim( (string) $utm ) );

		if ( '' !== $host ) {
			foreach ( self::hosts() as $known => $label ) {
				if ( $host === $known || substr( $host, -strlen( '.' . $known ) ) === '.' . $known ) {
					return array( (string) $label, 'referrer' );
				}
			}
		}

		if ( '' !== $utm ) {
			foreach ( self::utm_sources() as $needle => $label ) {
				if ( false !== strpos( $utm, (string) $needle ) ) {
					return array( (string) $label, 'utm' );
				}
			}
		}

		return array( '', '' );
	}

	/**
	 * Print the detection script on public pages.
	 *
	 * About 600 bytes, inline so it survives page caches and needs no extra
	 * request. It does nothing unless the visitor came from an assistant.
	 *
	 * @return void
	 */
	public static function print_beacon() {
		if ( ! RAWI_Settings::get( 'track_referrals' ) || is_admin() || is_feed() || is_robots() || is_preview() ) {
			return;
		}

		// Editors browsing their own site are not referrals.
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
			return;
		}

		$post_id = is_singular() ? (int) get_queried_object_id() : 0;
		$hosts   = array_keys( self::hosts() );
		$utms    = array_keys( self::utm_sources() );

		$config = array(
			'u' => esc_url_raw( rest_url( 'rawi/v1/referral' ) ),
			'i' => $post_id,
			'h' => array_values( $hosts ),
			't' => array_values( $utms ),
		);

		$script = '(function(c){try{'
			. 'var r=document.referrer,h="",l=location.hostname.replace(/^www\./,""),q=new URLSearchParams(location.search),u=(q.get("utm_source")||"").toLowerCase(),m=false;'
			. 'if(r){h=new URL(r).hostname.replace(/^www\./,"").toLowerCase();}'
			. 'if(h===l){return;}'
			. 'c.h.forEach(function(k){if(h===k||h.slice(-k.length-1)==="."+k){m=true;}});'
			. 'if(!m&&u){c.t.forEach(function(k){if(u.indexOf(k)>-1){m=true;}});}'
			. 'if(!m){return;}'
			. 'var s="rawi_ref:"+location.pathname;try{if(sessionStorage.getItem(s)){return;}sessionStorage.setItem(s,"1");}catch(e){}'
			. 'var b=JSON.stringify({h:h,u:u,p:location.pathname,i:c.i});'
			. 'if(navigator.sendBeacon){navigator.sendBeacon(c.u,new Blob([b],{type:"text/plain"}));}'
			. 'else{fetch(c.u,{method:"POST",body:b,keepalive:true,credentials:"omit"});}'
			. '}catch(e){}})(' . wp_json_encode( $config ) . ');';

		if ( function_exists( 'wp_print_inline_script_tag' ) ) {
			wp_print_inline_script_tag( $script, array( 'id' => 'rawi-referral' ) );
		} else {
			echo '<script id="rawi-referral">' . $script . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Register the beacon endpoint.
	 *
	 * @return void
	 */
	public static function register_route() {
		register_rest_route(
			'rawi/v1',
			'/referral',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_beacon' ),
				// Public on purpose: it is called by anonymous visitors from
				// cached pages, where no nonce can be embedded. Input is
				// whitelisted and the endpoint is rate limited per client.
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Record one referred visit.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function handle_beacon( WP_REST_Request $request ) {
		$done = new WP_REST_Response( null, 204 );

		if ( ! RAWI_Settings::get( 'track_referrals' ) ) {
			return $done;
		}

		$body = json_decode( (string) $request->get_body(), true );

		if ( ! is_array( $body ) ) {
			return $done;
		}

		list( $label, $via ) = self::classify(
			isset( $body['h'] ) ? substr( (string) $body['h'], 0, 120 ) : '',
			isset( $body['u'] ) ? substr( (string) $body['u'], 0, 80 ) : ''
		);

		if ( '' === $label ) {
			return $done;
		}

		$client = RAWI_Logger::client();

		// Crawlers that run JavaScript are not people.
		if ( self::looks_automated( $client['user_agent'] ) ) {
			return $done;
		}

		// At most 20 beacons per client every 10 minutes.
		$bucket = 'rawi_rl_' . substr( sha1( $client['ip'] . wp_salt( 'nonce' ) ), 0, 20 );
		$count  = (int) get_transient( $bucket );

		if ( $count >= 20 ) {
			return $done;
		}

		set_transient( $bucket, $count + 1, 10 * MINUTE_IN_SECONDS );

		$path    = isset( $body['p'] ) ? '/' . ltrim( sanitize_text_field( substr( (string) $body['p'], 0, 250 ) ), '/' ) : '/';
		$post_id = isset( $body['i'] ) ? absint( $body['i'] ) : 0;

		// The id comes from the browser: keep it only if it is a real,
		// published post whose address matches the path that was visited.
		if ( $post_id ) {
			$post = get_post( $post_id );

			if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status ) {
				$post_id = 0;
			} else {
				$expected = (string) wp_parse_url( (string) get_permalink( $post ), PHP_URL_PATH );

				if ( untrailingslashit( rawurldecode( $expected ) ) !== untrailingslashit( rawurldecode( $path ) ) ) {
					$post_id = 0;
				}
			}
		}

		if ( ! $post_id ) {
			$home     = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
			$relative = ( '' !== $home && 0 === strpos( $path, $home . '/' ) ) ? substr( $path, strlen( $home ) ) : $path;
			$post_id  = (int) url_to_postid( home_url( $relative ) );
		}

		// A rotating daily hash: counts unique visitors per day without
		// being able to follow anyone from one day to the next.
		$visitor = '';

		if ( 'hash' === RAWI_Settings::get( 'log_store_ip' ) && '' !== $client['ip'] ) {
			$visitor = sha1( $client['ip'] . '|' . $client['user_agent'] . '|' . gmdate( 'Y-m-d' ) . '|' . wp_salt( 'nonce' ) );
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert(
			self::table(),
			array(
				'visited_at'   => current_time( 'mysql', true ),
				'source'       => substr( $label, 0, 40 ),
				'post_id'      => $post_id,
				'url_path'     => substr( $path, 0, 255 ),
				'via'          => $via,
				'visitor_hash' => $visitor,
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s' )
		);

		return $done;
	}

	/**
	 * Headless browsers and known crawlers.
	 *
	 * @param string $user_agent User agent.
	 * @return bool
	 */
	private static function looks_automated( $user_agent ) {
		$ua = strtolower( (string) $user_agent );

		if ( '' === $ua ) {
			return true;
		}

		foreach ( array( 'bot', 'crawler', 'spider', 'headless', 'lighthouse', 'pagespeed', 'preview', 'python', 'curl', 'wget' ) as $needle ) {
			if ( false !== strpos( $ua, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Dashboard figures for a window.
	 *
	 * @param int    $days      Range in days.
	 * @param string $from      UTC start.
	 * @param string $to        UTC end.
	 * @param string $prev_from UTC start of the previous window.
	 * @return array
	 */
	public static function dashboard( $days, $from, $to, $prev_from ) {
		global $wpdb;

		$table = self::table();

		$totals = static function ( $start, $end ) use ( $wpdb, $table ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT COUNT(*) AS visits,
					        COUNT(DISTINCT CASE WHEN visitor_hash <> '' THEN visitor_hash END) AS visitors,
					        COUNT(DISTINCT source) AS sources,
					        COUNT(DISTINCT CASE WHEN post_id > 0 THEN post_id END) AS pages
					 FROM %i WHERE visited_at >= %s AND visited_at < %s",
					$table,
					$start,
					$end
				),
				ARRAY_A
			);

			return array(
				'visits'   => isset( $row['visits'] ) ? (int) $row['visits'] : 0,
				'visitors' => isset( $row['visitors'] ) ? (int) $row['visitors'] : 0,
				'sources'  => isset( $row['sources'] ) ? (int) $row['sources'] : 0,
				'pages'    => isset( $row['pages'] ) ? (int) $row['pages'] : 0,
			);
		};

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$sources = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT source AS k, COUNT(*) AS hits FROM %i
				 WHERE visited_at >= %s AND visited_at < %s
				 GROUP BY source ORDER BY hits DESC LIMIT 12',
				$table,
				$from,
				$to
			),
			ARRAY_A
		);

		// Landing pages, with how often AI crawlers read each one in the
		// same window: reads that turned into visits.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$pages = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT f.post_id, COUNT(*) AS visits, COUNT(DISTINCT f.source) AS sources,
				        GROUP_CONCAT(DISTINCT f.source ORDER BY f.source SEPARATOR %s) AS source_list,
				        ( SELECT COUNT(*) FROM %i r WHERE r.post_id = f.post_id AND r.requested_at >= %s AND r.requested_at < %s AND r.status = 200 ) AS read_count
				 FROM %i f
				 WHERE f.visited_at >= %s AND f.visited_at < %s AND f.post_id > 0
				 GROUP BY f.post_id ORDER BY visits DESC LIMIT 20',
				'|',
				RAWI_Logger::table(),
				$from,
				$to,
				$table,
				$from,
				$to
			),
			ARRAY_A
		);

		$pages = is_array( $pages ) ? $pages : array();

		if ( ! empty( $pages ) ) {
			_prime_post_caches( array_map( 'intval', wp_list_pluck( $pages, 'post_id' ) ), false, false );
		}

		$page_rows = array();

		foreach ( $pages as $row ) {
			$post = get_post( (int) $row['post_id'] );

			$page_rows[] = array(
				'id'       => (int) $row['post_id'],
				'title'    => $post ? html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ) : '#' . (int) $row['post_id'],
				'url'      => $post ? (string) get_permalink( $post ) : '',
				'edit_url' => $post ? (string) get_edit_post_link( $post, 'raw' ) : '',
				'visits'   => (int) $row['visits'],
				'reads'    => (int) $row['read_count'],
				'sources'  => array_values( array_filter( explode( '|', (string) $row['source_list'] ) ) ),
			);
		}

		$source_rows = array();

		foreach ( is_array( $sources ) ? $sources : array() as $row ) {
			$source_rows[] = array(
				'key'  => (string) $row['k'],
				'hits' => (int) $row['hits'],
			);
		}

		return array(
			'kpis'     => $totals( $from, $to ),
			'previous' => $totals( $prev_from, $from ),
			'sources'  => $source_rows,
			'pages'    => $page_rows,
			'series'   => RAWI_Stats::bucketed( $table, 'visited_at', 'source', $days, $from, $to ),
			'enabled'  => (bool) RAWI_Settings::get( 'track_referrals' ),
		);
	}

	/**
	 * Visits to one post, for the editor box.
	 *
	 * @param int $post_id Post ID.
	 * @param int $days    Window.
	 * @return int
	 */
	public static function for_post( $post_id, $days = 30 ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE post_id = %d AND visited_at >= %s',
				self::table(),
				$post_id,
				gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS )
			)
		);
	}

	/**
	 * Apply the same retention as the request log.
	 *
	 * @return void
	 */
	public static function prune() {
		global $wpdb;

		$days = absint( RAWI_Settings::get( 'log_retention_days' ) );

		if ( $days > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				$wpdb->prepare(
					'DELETE FROM %i WHERE visited_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)',
					self::table(),
					$days
				)
			);
		}
	}

	/**
	 * Empty the table.
	 *
	 * @return void
	 */
	public static function clear() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( $wpdb->prepare( 'TRUNCATE TABLE %i', self::table() ) );
	}
}
