<?php
/**
 * Option storage and defaults.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Settings
 */
class RAWI_Settings {

	const OPTION = 'rawi_settings';

	/**
	 * Request-level memo of the merged settings.
	 *
	 * @var array|null
	 */
	private static $cache = null;

	/**
	 * Default option values.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// Delivery.
			'enable_accept_header'    => 1,
			'enable_md_suffix'        => 1,
			'enable_query_string'     => 1,

			// Content.
			'post_types'              => array( 'post', 'page' ),
			'excluded_ids'            => '',
			'render_mode'             => 'the_content', // the_content | full_page.
			'content_selectors'       => "main\narticle\n.entry-content\n.post-content\n.site-main\n#content",

			// Used with the full page render, where the whole theme is present.
			'strip_selectors'         => "nav\nheader\nfooter\naside\nform\n.sidebar\n.comments\n.comment-respond\n.breadcrumb\n.breadcrumbs\n.woocommerce-breadcrumb\n.share\n.social-share\n.related-posts\n.wp-block-navigation\n.screen-reader-text\n.skip-link\n.price\n.product_meta\n.posted_in\n.tagged_as\n.sku_wrapper\n.wc-tabs\n.related\n.upsells\n.up-sells\n.cross-sells\n.woocommerce-product-rating\n.woocommerce-message\n.woocommerce-info\n.quantity",

			// Used with the content filters. Deliberately short: post content
			// legitimately contains <header>, <aside> and <form> blocks, and
			// stripping those removed real writing in 1.2.x.
			'content_strip_selectors' => ".sharedaddy\n.jp-relatedposts\n.addtoany_share_save_container\n.addtoany_content\n.screen-reader-text\n.skip-link\n.wp-block-search\n.wp-block-navigation\n.wp-block-buttons\n.woocommerce-message\n.woocommerce-info",

			// Frontmatter.
			'frontmatter_enabled'     => 1,
			'frontmatter_fields'      => array( 'title', 'description', 'url', 'date_published', 'date_modified', 'author', 'categories', 'tags', 'language', 'image' ),
			'woo_fields'              => 1,

			// SEO / safety.
			'respect_seo_noindex'     => 1,
			'noindex_alt_urls'        => 1,
			'content_signal'          => 'search=yes, ai-input=yes, ai-train=no',

			// llms.txt.
			'llms_enabled'            => 1,
			'llms_intro'              => '',
			'llms_max_per_type'       => 50,

			// Cache.
			'cache_enabled'           => 1,
			'cache_ttl'               => 0, // 0 = until invalidated by a content change.
			'measure_html'            => 1,
			'auto_warm'               => 1,

			// Logging.
			'log_enabled'             => 1,
			'log_store_ip'            => 'hash', // none | hash.
			'log_retention_days'      => 90,
			'log_max_rows'            => 50000,
			'verify_bots'             => 1,
			'verify_ip_lists'         => 0,
			'track_referrals'         => 1,
		);
	}

	/**
	 * Get all settings merged over defaults.
	 *
	 * @return array
	 */
	public static function all() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		$saved = get_option( self::OPTION, array() );

		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		self::$cache = wp_parse_args( $saved, self::defaults() );

		return self::$cache;
	}

	/**
	 * Get a single setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback when the key is unknown.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();

		if ( array_key_exists( $key, $all ) ) {
			/**
			 * Filter a single setting value.
			 *
			 * @param mixed  $value The stored value.
			 * @param string $key   The setting key.
			 */
			return apply_filters( 'rawi_setting', $all[ $key ], $key );
		}

		return $default;
	}

	/**
	 * Write settings.
	 *
	 * @param array $values Values to store.
	 * @return void
	 */
	public static function update( array $values ) {
		update_option( self::OPTION, $values );
		self::$cache = null;
	}

	/**
	 * Forget the memo, e.g. after another process changed the option.
	 *
	 * @return void
	 */
	public static function reset_cache() {
		self::$cache = null;
	}

	/**
	 * Seed defaults on activation without clobbering an existing config.
	 *
	 * @return void
	 */
	public static function seed_defaults() {
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, self::defaults() );
		}
	}

	/**
	 * Add keys introduced by a newer version to a stored configuration.
	 *
	 * Only missing keys are written; every value the site owner saved stays
	 * exactly as it was. The cache flush hooked on the option update is
	 * avoided, because nothing the owner chose has changed.
	 *
	 * @return void
	 */
	public static function backfill() {
		$saved = get_option( self::OPTION, false );

		if ( ! is_array( $saved ) ) {
			return;
		}

		$missing = array_diff_key( self::defaults(), $saved );

		if ( empty( $missing ) ) {
			return;
		}

		// Requests logged before 1.3.0 relied on a 30 day / 10k row default;
		// keep whatever was stored rather than widening it silently.
		$merged = $saved + $missing;

		remove_action( 'update_option_' . self::OPTION, array( 'RAWI_Cache', 'flush' ) );
		update_option( self::OPTION, $merged );
		self::$cache = null;
	}

	/**
	 * Post types that may be served as Markdown.
	 *
	 * @return string[]
	 */
	public static function enabled_post_types() {
		$types = self::get( 'post_types' );

		if ( ! is_array( $types ) ) {
			$types = array();
		}

		/**
		 * Filter the post types served as Markdown.
		 *
		 * @param string[] $types Post type slugs.
		 */
		return array_values( array_filter( array_map( 'sanitize_key', apply_filters( 'rawi_post_types', $types ) ) ) );
	}

	/**
	 * Post IDs explicitly excluded by the site owner.
	 *
	 * @return int[]
	 */
	public static function excluded_ids() {
		$raw = (string) self::get( 'excluded_ids' );

		if ( '' === trim( $raw ) ) {
			return array();
		}

		$parts = preg_split( '/[\s,]+/', $raw );
		$ids   = array();

		foreach ( (array) $parts as $part ) {
			$id = absint( $part );
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Turn a textarea of one-per-line selectors into an array.
	 *
	 * @param string $key Setting key holding the textarea value.
	 * @return string[]
	 */
	public static function selector_list( $key ) {
		$raw   = (string) self::get( $key );
		$lines = preg_split( '/\r\n|\r|\n/', $raw );
		$out   = array();

		foreach ( (array) $lines as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}

		return $out;
	}
}
