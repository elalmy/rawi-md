<?php
/**
 * Carries an existing install forward to the current version.
 *
 * WordPress does not run the activation hook when a plugin is updated, so a
 * site that updates from 1.2.x through the plugins screen never reactivates.
 * This class notices the version change on the next page load and performs
 * every migration step. All of them are additive:
 *
 * - settings: missing keys are added, nothing the site owner saved is touched;
 * - the request log: dbDelta() adds new columns and indexes, it never drops a
 *   column or a row, so every request recorded before the update survives;
 * - the cache: only files written by an older version are removed, because
 *   they are regenerable output keyed to that version.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Upgrade
 */
class RAWI_Upgrade {

	const VERSION_OPTION = 'rawi_version';
	const FLUSH_OPTION   = 'rawi_flush_rewrite';

	/**
	 * Run the migration when the stored version differs from the code.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		add_action( 'init', array( __CLASS__, 'maybe_flush_rewrites' ), 99 );

		$installed = (string) get_option( self::VERSION_OPTION, '' );
		$db        = (string) get_option( 'rawi_db_version', '' );

		if ( RAWI_VERSION === $installed && RAWI_DB_VERSION === $db ) {
			return;
		}

		// One request migrates; concurrent ones skip instead of racing.
		if ( get_transient( 'rawi_upgrading' ) ) {
			return;
		}

		// 1.2.x never stored its version, only the log table's schema
		// version. A schema version with no plugin version is an upgrade
		// from 1.2.x, not a fresh install.
		if ( '' === $installed && '' !== $db ) {
			$installed = '1.2';
		}

		set_transient( 'rawi_upgrading', 1, MINUTE_IN_SECONDS );
		self::run( $installed );
		delete_transient( 'rawi_upgrading' );
	}

	/**
	 * Every migration step. Idempotent: running it twice changes nothing.
	 *
	 * @param string $from Version the site is coming from, '' when unknown.
	 * @return void
	 */
	public static function run( $from = '' ) {
		RAWI_Settings::seed_defaults();
		RAWI_Settings::backfill();

		RAWI_Referrals::create_table();
		RAWI_Logger::create_table(); // Sets rawi_db_version, so it runs last.

		RAWI_Cache::prepare_directory( true );
		RAWI_Cache::remove_stale();

		if ( ! wp_next_scheduled( 'rawi_daily_maintenance' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'rawi_daily_maintenance' );
		}

		// A new rewrite rule (llms.txt) arrived in 1.3.0. Flushing needs the
		// rules registered first, so it is deferred to the end of init.
		update_option( self::FLUSH_OPTION, 1, false );

		if ( '' !== $from && version_compare( $from, RAWI_VERSION, '<' ) ) {
			update_option( 'rawi_updated_from', $from, false );
		}

		update_option( self::VERSION_OPTION, RAWI_VERSION, false );

		/**
		 * Fires after Rawi MD migrated an install to the current version.
		 *
		 * @param string $from Previous version, or '' on a fresh install.
		 */
		do_action( 'rawi_upgraded', $from );
	}

	/**
	 * Flush rewrite rules once after an update.
	 *
	 * @return void
	 */
	public static function maybe_flush_rewrites() {
		if ( ! get_option( self::FLUSH_OPTION ) ) {
			return;
		}

		delete_option( self::FLUSH_OPTION );
		flush_rewrite_rules( false );
	}
}
