<?php
/**
 * Checks whether a request claiming to be a known crawler really is one.
 *
 * Anyone can send "User-Agent: GPTBot". Two independent methods are used:
 *
 * 1. Forward-confirmed reverse DNS, for operators that document it (Google,
 *    Microsoft, Apple). A DNS lookup only, no HTTP request.
 * 2. The IP range lists operators publish (OpenAI, Perplexity, Google,
 *    Microsoft). Downloading them is an outgoing HTTP request, so it is off
 *    until the site owner enables it.
 *
 * DNS lookups can take a second or two. They only run after the response has
 * already been handed to the client (PHP-FPM or LiteSpeed), and each IP's
 * result is remembered for a day, so no agent ever waits for verification.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Verify
 */
class RAWI_Verify {

	/**
	 * Option holding the downloaded IP range lists.
	 */
	const LISTS_OPTION = 'rawi_ip_lists';

	/**
	 * Set by the router once the client has its full response.
	 *
	 * @var bool
	 */
	public static $response_sent = false;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rawi_refresh_ip_lists', array( __CLASS__, 'refresh_lists' ) );

		if ( RAWI_Settings::get( 'verify_bots' ) && RAWI_Settings::get( 'verify_ip_lists' ) ) {
			if ( ! wp_next_scheduled( 'rawi_refresh_ip_lists' ) ) {
				wp_schedule_event( time() + 60, 'daily', 'rawi_refresh_ip_lists' );
			}
		} elseif ( wp_next_scheduled( 'rawi_refresh_ip_lists' ) ) {
			wp_clear_scheduled_hook( 'rawi_refresh_ip_lists' );
		}
	}

	/**
	 * Reverse DNS hostname suffixes per label.
	 *
	 * @return array<string,string[]>
	 */
	public static function dns_rules() {
		$google = array( '.googlebot.com', '.google.com', '.googleusercontent.com' );

		return (array) apply_filters(
			'rawi_verify_dns_rules',
			array(
				'Googlebot'             => array( '.googlebot.com', '.google.com' ),
				'GoogleOther'           => $google,
				'Google-CloudVertexBot' => $google,
				'Gemini-Deep-Research'  => $google,
				'Bingbot'               => array( '.search.msn.com' ),
				'Applebot'              => array( '.applebot.apple.com' ),
				'Applebot-Extended'     => array( '.applebot.apple.com' ),
				'YandexBot'             => array( '.yandex.ru', '.yandex.net', '.yandex.com' ),
				'Baiduspider'           => array( '.baidu.com', '.baidu.jp' ),
				'PetalBot'              => array( '.petalsearch.com' ),
			)
		);
	}

	/**
	 * Published IP range lists per label.
	 *
	 * @return array<string,string[]> label => list URLs.
	 */
	public static function list_sources() {
		return (array) apply_filters(
			'rawi_verify_list_sources',
			array(
				'GPTBot'          => array( 'https://openai.com/gptbot.json' ),
				'OAI-SearchBot'   => array( 'https://openai.com/searchbot.json' ),
				'ChatGPT-User'    => array( 'https://openai.com/chatgpt-user.json' ),
				'PerplexityBot'   => array( 'https://www.perplexity.ai/perplexitybot.json' ),
				'Perplexity-User' => array( 'https://www.perplexity.ai/perplexity-user.json' ),
				'Googlebot'       => array( 'https://developers.google.com/static/search/apis/ipranges/googlebot.json' ),
				'Bingbot'         => array( 'https://www.bing.com/toolbox/bingbot.json' ),
			)
		);
	}

	/**
	 * Can this label be verified with the current settings at all?
	 *
	 * @param string $label Agent label.
	 * @return bool
	 */
	public static function is_verifiable( $label ) {
		if ( ! RAWI_Settings::get( 'verify_bots' ) ) {
			return false;
		}

		$rules = self::dns_rules();

		if ( isset( $rules[ $label ] ) ) {
			return true;
		}

		$sources = self::list_sources();

		return RAWI_Settings::get( 'verify_ip_lists' ) && isset( $sources[ $label ] );
	}

	/**
	 * Verify a request.
	 *
	 * @param string $label Agent label from RAWI_Agents::label().
	 * @param string $ip    Client IP.
	 * @return int RAWI_Logger::UNCHECKED | VERIFIED | SPOOFED.
	 */
	public static function check( $label, $ip ) {
		if ( '' === $ip || ! self::is_verifiable( $label ) ) {
			return RAWI_Logger::UNCHECKED;
		}

		$cache_key = 'rawi_vf_' . md5( $label . '|' . $ip . '|' . wp_salt( 'nonce' ) );
		$cached    = get_transient( $cache_key );

		if ( false !== $cached ) {
			return (int) $cached;
		}

		$result = self::check_lists( $label, $ip );

		if ( RAWI_Logger::VERIFIED !== $result ) {
			$rules = self::dns_rules();

			if ( isset( $rules[ $label ] ) ) {
				// DNS can block; only do it once the agent has its answer.
				if ( ! self::$response_sent ) {
					return $result;
				}

				$result = self::check_dns( $ip, $rules[ $label ] );
			}
		}

		set_transient( $cache_key, $result, DAY_IN_SECONDS );

		return $result;
	}

	/**
	 * Match an IP against the downloaded lists for a label.
	 *
	 * @param string $label Agent label.
	 * @param string $ip    Client IP.
	 * @return int UNCHECKED when no list is available for the label.
	 */
	private static function check_lists( $label, $ip ) {
		if ( ! RAWI_Settings::get( 'verify_ip_lists' ) ) {
			return RAWI_Logger::UNCHECKED;
		}

		$lists = get_option( self::LISTS_OPTION, array() );

		if ( ! is_array( $lists ) || empty( $lists['ranges'][ $label ] ) ) {
			return RAWI_Logger::UNCHECKED;
		}

		foreach ( (array) $lists['ranges'][ $label ] as $cidr ) {
			if ( self::ip_in_cidr( $ip, (string) $cidr ) ) {
				return RAWI_Logger::VERIFIED;
			}
		}

		return RAWI_Logger::SPOOFED;
	}

	/**
	 * Forward-confirmed reverse DNS.
	 *
	 * @param string   $ip       Client IP.
	 * @param string[] $suffixes Allowed hostname suffixes.
	 * @return int
	 */
	private static function check_dns( $ip, array $suffixes ) {
		$host = @gethostbyaddr( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( ! $host || $host === $ip ) {
			return RAWI_Logger::SPOOFED;
		}

		$host    = strtolower( rtrim( $host, '.' ) );
		$matched = false;

		foreach ( $suffixes as $suffix ) {
			$suffix = strtolower( $suffix );

			if ( substr( $host, -strlen( $suffix ) ) === $suffix ) {
				$matched = true;
				break;
			}
		}

		if ( ! $matched ) {
			return RAWI_Logger::SPOOFED;
		}

		// The forward lookup must point back at the same address, otherwise
		// anyone controlling their own PTR record could claim any hostname.
		$forward = array();

		if ( false !== strpos( $ip, ':' ) && function_exists( 'dns_get_record' ) ) {
			$records = @dns_get_record( $host, DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			foreach ( is_array( $records ) ? $records : array() as $record ) {
				if ( ! empty( $record['ipv6'] ) ) {
					$forward[] = $record['ipv6'];
				}
			}
		} else {
			$ips     = @gethostbynamel( $host ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$forward = is_array( $ips ) ? $ips : array();
		}

		$packed = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		foreach ( $forward as $candidate ) {
			if ( false !== $packed && @inet_pton( $candidate ) === $packed ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				return RAWI_Logger::VERIFIED;
			}
		}

		return RAWI_Logger::SPOOFED;
	}

	/**
	 * Is an IP inside a CIDR range? Works for IPv4 and IPv6.
	 *
	 * @param string $ip   Address.
	 * @param string $cidr Range such as 20.171.206.0/24.
	 * @return bool
	 */
	public static function ip_in_cidr( $ip, $cidr ) {
		if ( false === strpos( $cidr, '/' ) ) {
			$cidr .= ( false !== strpos( $cidr, ':' ) ) ? '/128' : '/32';
		}

		list( $subnet, $bits ) = explode( '/', $cidr, 2 );

		$ip_bin     = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$subnet_bin = @inet_pton( $subnet ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( false === $ip_bin || false === $subnet_bin || strlen( $ip_bin ) !== strlen( $subnet_bin ) ) {
			return false;
		}

		$bits  = (int) $bits;
		$bytes = intdiv( $bits, 8 );
		$rest  = $bits % 8;

		if ( substr( $ip_bin, 0, $bytes ) !== substr( $subnet_bin, 0, $bytes ) ) {
			return false;
		}

		if ( 0 === $rest ) {
			return true;
		}

		$mask = ( 0xFF << ( 8 - $rest ) ) & 0xFF;

		return ( ord( $ip_bin[ $bytes ] ) & $mask ) === ( ord( $subnet_bin[ $bytes ] ) & $mask );
	}

	/**
	 * Cron callback: download the published IP range lists.
	 *
	 * A list that fails to download keeps its previous copy.
	 *
	 * @return array Summary: label => number of ranges.
	 */
	public static function refresh_lists() {
		$stored = get_option( self::LISTS_OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		$ranges = isset( $stored['ranges'] ) && is_array( $stored['ranges'] ) ? $stored['ranges'] : array();

		foreach ( self::list_sources() as $label => $urls ) {
			$found = array();
			$ok    = false;

			foreach ( (array) $urls as $url ) {
				$response = wp_safe_remote_get(
					$url,
					array(
						'timeout'    => 10,
						'user-agent' => 'RawiMD/' . RAWI_VERSION,
					)
				);

				if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
					continue;
				}

				$json = json_decode( (string) wp_remote_retrieve_body( $response ), true );

				if ( ! is_array( $json ) || empty( $json['prefixes'] ) || ! is_array( $json['prefixes'] ) ) {
					continue;
				}

				$ok = true;

				foreach ( $json['prefixes'] as $prefix ) {
					foreach ( array( 'ipv4Prefix', 'ipv6Prefix' ) as $key ) {
						if ( ! empty( $prefix[ $key ] ) && is_string( $prefix[ $key ] ) ) {
							$found[] = sanitize_text_field( $prefix[ $key ] );
						}
					}
				}
			}

			if ( $ok && ! empty( $found ) ) {
				$ranges[ $label ] = array_values( array_unique( $found ) );
			}
		}

		update_option(
			self::LISTS_OPTION,
			array(
				'updated' => time(),
				'ranges'  => $ranges,
			),
			false
		);

		$summary = array();

		foreach ( $ranges as $label => $list ) {
			$summary[ $label ] = count( $list );
		}

		return $summary;
	}
}
