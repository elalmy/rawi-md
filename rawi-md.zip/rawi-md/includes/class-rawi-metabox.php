<?php
/**
 * Editor integration: a sidebar box on every enabled post type, plus a
 * "Markdown" row action in post lists.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Metabox
 */
class RAWI_Metabox {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'register' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 5, 2 );
		add_filter( 'post_row_actions', array( __CLASS__, 'row_action' ), 10, 2 );
		add_filter( 'page_row_actions', array( __CLASS__, 'row_action' ), 10, 2 );
	}

	/**
	 * Add the box.
	 *
	 * @return void
	 */
	public static function register() {
		foreach ( RAWI_Settings::enabled_post_types() as $type ) {
			add_meta_box(
				'rawi-md',
				__( 'Rawi MD — AI agents', 'rawi-md' ),
				array( __CLASS__, 'render' ),
				$type,
				'side',
				'low'
			);
		}
	}

	/**
	 * Box contents.
	 *
	 * @param WP_Post $post Post being edited.
	 * @return void
	 */
	public static function render( $post ) {
		wp_nonce_field( 'rawi_metabox', 'rawi_metabox_nonce' );

		$excluded = (bool) get_post_meta( $post->ID, RAWI_Eligibility::EXCLUDE_META, true );
		$reason   = RAWI_Eligibility::reason( $post );
		$stats    = RAWI_Stats::for_post( $post->ID, 30 );
		$metrics  = get_post_meta( $post->ID, RAWI_Renderer::HTML_META, true );

		echo '<div class="rawi-box">';

		printf(
			'<p class="rawi-box__status rawi-box__status--%s"><span class="rawi-dot"></span>%s</p>',
			esc_attr( '' === $reason ? 'on' : 'off' ),
			esc_html( RAWI_Eligibility::reason_label( $reason ) )
		);

		if ( '' === $reason ) {
			$md_url = RAWI_Router::markdown_url( $post );

			printf(
				'<p><a class="button button-small" href="%s" target="_blank" rel="noopener">%s</a></p>',
				esc_url( $md_url ),
				esc_html__( 'View Markdown', 'rawi-md' )
			);
		}

		printf(
			'<p class="rawi-box__figure"><strong>%s</strong> %s</p>',
			esc_html( number_format_i18n( $stats['total'] ) ),
			esc_html__( 'agent requests in the last 30 days', 'rawi-md' )
		);

		if ( ! empty( $stats['agents'] ) ) {
			echo '<ul class="rawi-box__agents">';
			foreach ( $stats['agents'] as $row ) {
				printf(
					'<li><span>%s</span><b>%s</b></li>',
					esc_html( $row['agent_label'] ),
					esc_html( number_format_i18n( (int) $row['hits'] ) )
				);
			}
			echo '</ul>';
		}

		$visits = RAWI_Referrals::for_post( $post->ID, 30 );

		if ( $visits > 0 ) {
			printf(
				'<p class="rawi-box__figure"><strong>%s</strong> %s</p>',
				esc_html( number_format_i18n( $visits ) ),
				esc_html__( 'visitors sent by AI assistants in the last 30 days', 'rawi-md' )
			);
		}

		$readiness = RAWI_Readiness::get( $post->ID );

		if ( $readiness ) {
			$score  = (int) $readiness['score'];
			$labels = RAWI_Readiness::labels();
			$level  = $score >= 80 ? 'good' : ( $score >= 50 ? 'fair' : 'poor' );

			printf(
				'<div class="rawi-box__score rawi-box__score--%s"><span>%s</span><b>%d</b></div>',
				esc_attr( $level ),
				esc_html__( 'AI readiness', 'rawi-md' ),
				(int) $score
			);

			$issues = RAWI_Readiness::issues( $readiness );

			if ( ! empty( $issues ) ) {
				echo '<ul class="rawi-box__issues">';
				foreach ( array_slice( $issues, 0, 4 ) as $key ) {
					if ( isset( $labels[ $key ] ) ) {
						printf( '<li><strong>%s</strong> %s</li>', esc_html( $labels[ $key ][0] ), esc_html( $labels[ $key ][1] ) );
					}
				}
				echo '</ul>';
			}
		}

		if ( is_array( $metrics ) && ! empty( $metrics['tokens'] ) && RAWI_Cache::has( $post->ID ) ) {
			$doc = RAWI_Cache::get( $post->ID );

			if ( false !== $doc ) {
				$md   = RAWI_Converter::estimate_tokens( $doc );
				$html = (int) $metrics['tokens'];

				if ( $html > 0 ) {
					printf(
						'<p class="rawi-box__figure">%s</p>',
						esc_html(
							sprintf(
								/* translators: 1: Markdown tokens, 2: HTML tokens, 3: percentage saved. */
								__( '%1$s tokens instead of %2$s (%3$s%% lighter)', 'rawi-md' ),
								number_format_i18n( $md ),
								number_format_i18n( $html ),
								number_format_i18n( max( 0, ( 1 - $md / $html ) * 100 ), 0 )
							)
						)
					);
				}
			}
		}

		printf(
			'<p><label><input type="checkbox" name="rawi_exclude" value="1" %s /> %s</label></p>',
			checked( $excluded, true, false ),
			esc_html__( 'Do not serve this post as Markdown', 'rawi-md' )
		);

		echo '</div>';
	}

	/**
	 * Save the opt-out flag.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['rawi_metabox_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rawi_metabox_nonce'] ) ), 'rawi_metabox' ) ) {
			return;
		}

		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! empty( $_POST['rawi_exclude'] ) ) {
			update_post_meta( $post_id, RAWI_Eligibility::EXCLUDE_META, 1 );
		} else {
			delete_post_meta( $post_id, RAWI_Eligibility::EXCLUDE_META );
		}

		RAWI_Eligibility::reset();
	}

	/**
	 * "Markdown" link in the posts list.
	 *
	 * @param string[] $actions Row actions.
	 * @param WP_Post  $post    Post.
	 * @return string[]
	 */
	public static function row_action( $actions, $post ) {
		if ( ! $post instanceof WP_Post || ! RAWI_Eligibility::is_eligible( $post ) ) {
			return $actions;
		}

		$actions['rawi_md'] = sprintf(
			'<a href="%s" target="_blank" rel="noopener">%s</a>',
			esc_url( RAWI_Router::markdown_url( $post ) ),
			esc_html__( 'Markdown', 'rawi-md' )
		);

		return $actions;
	}
}
