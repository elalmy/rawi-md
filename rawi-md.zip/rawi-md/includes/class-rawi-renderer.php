<?php
/**
 * Produces the Markdown document for a post.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Renderer
 */
class RAWI_Renderer {

	/**
	 * Post meta holding the measured size of the real HTML page.
	 */
	const HTML_META = '_rawi_html_metrics';

	/**
	 * Guard against a full-page render request re-entering the router.
	 *
	 * @var bool
	 */
	private static $rendering = false;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rawi_measure_html', array( __CLASS__, 'measure_html' ), 10, 1 );
	}

	/**
	 * Build the Markdown document for a post.
	 *
	 * @param WP_Post $post Post object.
	 * @return string
	 */
	public static function render( WP_Post $post ) {
		$result = self::render_with_metrics( $post );

		return $result['document'];
	}

	/**
	 * Build the document and report what it cost.
	 *
	 * @param WP_Post $post Post object.
	 * @return array{document:string,html_tokens:int,gen_ms:int}
	 */
	public static function render_with_metrics( WP_Post $post ) {
		$started   = microtime( true );
		$full_page = ( 'full_page' === RAWI_Settings::get( 'render_mode' ) );

		$html = $full_page
			? self::full_page_html( $post )
			: self::the_content_html( $post );

		$permalink = get_permalink( $post );
		$converter = new RAWI_Converter( $permalink ? $permalink : home_url( '/' ) );

		$content_selectors = $full_page ? RAWI_Settings::selector_list( 'content_selectors' ) : array();

		// The long list is written for a whole themed page. Applied to the post
		// content alone it deleted <header>, <aside> and <form> blocks the
		// author wrote on purpose, so the content mode has its own list.
		$strip_selectors = $full_page
			? RAWI_Settings::selector_list( 'strip_selectors' )
			: RAWI_Settings::selector_list( 'content_strip_selectors' );

		/**
		 * Filter the selectors removed before conversion.
		 *
		 * @param string[] $strip_selectors CSS selectors.
		 * @param WP_Post  $post            The post being rendered.
		 * @param bool     $full_page       Whether the full page render is used.
		 */
		$strip_selectors = (array) apply_filters( 'rawi_strip_selectors', $strip_selectors, $post, $full_page );

		$body = $converter->convert( $html, $content_selectors, $strip_selectors );

		$title = wp_strip_all_tags( get_the_title( $post ) );

		if ( '' !== $title ) {
			// Themes print the product or post title more than once: in the
			// summary block, in a sticky bar, in the gallery caption. Drop
			// every heading that repeats it, then add exactly one.
			$body = self::strip_title_headings( $body, $title );
			$body = '# ' . $title . "\n\n" . ltrim( $body );
		}

		$document = RAWI_Frontmatter::build( $post ) . $body . "\n";

		/**
		 * Filter the finished Markdown document.
		 *
		 * @param string  $document The Markdown document including frontmatter.
		 * @param WP_Post $post     The post being rendered.
		 */
		$document = (string) apply_filters( 'rawi_markdown_document', $document, $post );

		// With the full page render the real HTML is already in hand.
		if ( $full_page && '' !== $html ) {
			self::store_html_metrics( $post, $html );
		}

		return array(
			'document'    => $document,
			'html_tokens' => self::html_tokens( $post ),
			'gen_ms'      => (int) round( ( microtime( true ) - $started ) * 1000 ),
		);
	}

	/**
	 * Tokens the real HTML page costs, when it has been measured.
	 *
	 * Schedules a background measurement the first time, so an agent request
	 * never waits for it.
	 *
	 * @param WP_Post $post Post object.
	 * @return int 0 when not measured yet.
	 */
	public static function html_tokens( WP_Post $post ) {
		$metrics = get_post_meta( $post->ID, self::HTML_META, true );

		$fresh = is_array( $metrics )
			&& ! empty( $metrics['tokens'] )
			&& isset( $metrics['modified'] )
			&& $metrics['modified'] === $post->post_modified_gmt;

		if ( $fresh ) {
			return (int) $metrics['tokens'];
		}

		if ( RAWI_Settings::get( 'measure_html' ) && ! wp_next_scheduled( 'rawi_measure_html', array( (int) $post->ID ) ) ) {
			wp_schedule_single_event( time() + 5, 'rawi_measure_html', array( (int) $post->ID ) );
		}

		return is_array( $metrics ) && ! empty( $metrics['tokens'] ) ? (int) $metrics['tokens'] : 0;
	}

	/**
	 * Cron callback: fetch the public HTML page once and remember its size.
	 *
	 * This is what turns "tokens delivered" into a real "tokens saved" figure
	 * on the dashboard: the difference between what the agent would have read
	 * and what it actually received.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function measure_html( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status ) {
			return;
		}

		$url = get_permalink( $post );

		if ( ! $url ) {
			return;
		}

		$response = wp_remote_get(
			add_query_arg( 'rawi_render', '1', $url ),
			self::loopback_args()
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return;
		}

		$body = (string) wp_remote_retrieve_body( $response );

		if ( '' !== trim( $body ) ) {
			self::store_html_metrics( $post, $body );
		}
	}

	/**
	 * Remember the size of a post's HTML page.
	 *
	 * @param WP_Post $post Post object.
	 * @param string  $html Full HTML page.
	 * @return void
	 */
	private static function store_html_metrics( WP_Post $post, $html ) {
		update_post_meta(
			$post->ID,
			self::HTML_META,
			array(
				'tokens'   => RAWI_Converter::estimate_tokens( $html ),
				'bytes'    => strlen( $html ),
				'modified' => $post->post_modified_gmt,
				'measured' => time(),
			)
		);
	}

	/**
	 * Arguments for a request back to this same site.
	 *
	 * @return array
	 */
	private static function loopback_args() {
		return array(
			'timeout'     => 15,
			// Same filter core uses for its own loopback requests, so a site
			// with a self-signed certificate keeps working while a site with
			// a valid one gets verification.
			'sslverify'   => (bool) apply_filters( 'https_local_ssl_verify', false ),
			'redirection' => 2,
			'headers'     => array(
				'Accept'     => 'text/html',
				'User-Agent' => 'RawiMD/' . RAWI_VERSION . '; ' . home_url( '/' ),
			),
		);
	}

	/**
	 * Remove every heading whose text is the post title.
	 *
	 * @param string $body  Markdown body.
	 * @param string $title Post title.
	 * @return string
	 */
	private static function strip_title_headings( $body, $title ) {
		$needle = self::normalise( $title );

		if ( '' === $needle ) {
			return $body;
		}

		$lines = explode( "\n", (string) $body );
		$kept  = array();

		foreach ( $lines as $line ) {
			if ( preg_match( '/^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$/u', $line, $m )
				&& self::normalise( $m[1] ) === $needle ) {
				continue;
			}

			$kept[] = $line;
		}

		$out = implode( "\n", $kept );
		$out = preg_replace( '/\n{3,}/', "\n\n", $out );

		return trim( (string) $out );
	}

	/**
	 * Normalise heading text for comparison: undo Markdown escaping, collapse
	 * whitespace, lowercase.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function normalise( $text ) {
		$text = preg_replace( '/\\\\(.)/u', '$1', (string) $text );
		$text = preg_replace( '/[*_`]/u', '', (string) $text );
		$text = preg_replace( '/\s+/u', ' ', (string) $text );
		$text = trim( (string) $text );

		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
	}

	/**
	 * Render through the_content filters.
	 *
	 * Fast, no HTTP request, and it already covers Classic, Gutenberg,
	 * Elementor and WPBakery, all of which hook the_content.
	 *
	 * @param WP_Post $post Post object.
	 * @return string
	 */
	private static function the_content_html( WP_Post $post ) {
		$original_post = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;

		$GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		setup_postdata( $post );

		$content = apply_filters( 'the_content', $post->post_content );

		wp_reset_postdata();

		$GLOBALS['post'] = $original_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

		if ( 'product' === $post->post_type ) {
			$content = self::prepend_product_summary( $post, $content );
		}

		return (string) $content;
	}

	/**
	 * Fetch the full rendered page over a loopback request.
	 *
	 * Needed for Bricks and Oxygen, which replace the whole template instead of
	 * filtering the_content. It costs one HTTP request per cache miss, so it is
	 * off by default: on shared hosting with a single PHP worker a loopback can
	 * stall until the request times out.
	 *
	 * @param WP_Post $post Post object.
	 * @return string
	 */
	private static function full_page_html( WP_Post $post ) {
		if ( self::$rendering ) {
			return self::the_content_html( $post );
		}

		self::$rendering = true;

		$url = add_query_arg( 'rawi_render', '1', get_permalink( $post ) );

		$response = wp_remote_get( $url, self::loopback_args() );

		self::$rendering = false;

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			// Fall back rather than serve nothing.
			return self::the_content_html( $post );
		}

		$body = wp_remote_retrieve_body( $response );

		if ( '' === trim( (string) $body ) ) {
			return self::the_content_html( $post );
		}

		if ( 'product' === $post->post_type ) {
			$body = self::prepend_product_summary( $post, $body );
		}

		return (string) $body;
	}

	/**
	 * Is this request the plugin's own loopback render?
	 *
	 * @return bool
	 */
	public static function is_loopback_render() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return isset( $_GET['rawi_render'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['rawi_render'] ) );
	}

	/**
	 * Add a short product summary above the description for WooCommerce items.
	 *
	 * @param WP_Post $post    Post object.
	 * @param string  $content Rendered content.
	 * @return string
	 */
	private static function prepend_product_summary( WP_Post $post, $content ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return $content;
		}

		$product = wc_get_product( $post->ID );

		if ( ! $product ) {
			return $content;
		}

		$short = trim( (string) $product->get_short_description() );

		if ( '' === $short ) {
			return $content;
		}

		return '<div>' . $short . '</div>' . $content;
	}
}
