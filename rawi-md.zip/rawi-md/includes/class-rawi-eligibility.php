<?php
/**
 * Decides whether a given post may be served as Markdown.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Eligibility
 */
class RAWI_Eligibility {

	/**
	 * Per-post opt-out stored by the editor meta box.
	 */
	const EXCLUDE_META = '_rawi_exclude';

	/**
	 * Request-level memo: the same post is checked by discovery and router.
	 *
	 * @var bool[]
	 */
	private static $memo = array();

	/**
	 * Check a post.
	 *
	 * @param int|WP_Post $post Post ID or object.
	 * @return bool
	 */
	public static function is_eligible( $post ) {
		$post = get_post( $post );

		if ( ! $post instanceof WP_Post ) {
			return false;
		}

		if ( isset( self::$memo[ $post->ID ] ) ) {
			return self::$memo[ $post->ID ];
		}

		$eligible = ( '' === self::reason( $post ) );

		/**
		 * Filter the eligibility decision for a post.
		 *
		 * @param bool    $eligible Whether the post may be served as Markdown.
		 * @param WP_Post $post     The post being checked.
		 */
		self::$memo[ $post->ID ] = (bool) apply_filters( 'rawi_is_eligible', $eligible, $post );

		return self::$memo[ $post->ID ];
	}

	/**
	 * Forget memoised decisions, e.g. after a post was saved.
	 *
	 * @return void
	 */
	public static function reset() {
		self::$memo = array();
	}

	/**
	 * Why a post is not served, as a machine key; '' when it is served.
	 *
	 * Used by the editor meta box and the dashboard to explain the decision.
	 *
	 * @param WP_Post $post Post object.
	 * @return string
	 */
	public static function reason( WP_Post $post ) {
		if ( 'publish' !== $post->post_status ) {
			return 'not_published';
		}

		if ( '' !== $post->post_password ) {
			return 'password';
		}

		if ( ! in_array( $post->post_type, RAWI_Settings::enabled_post_types(), true ) ) {
			return 'post_type';
		}

		if ( in_array( (int) $post->ID, RAWI_Settings::excluded_ids(), true ) ) {
			return 'excluded';
		}

		if ( get_post_meta( $post->ID, self::EXCLUDE_META, true ) ) {
			return 'excluded';
		}

		if ( RAWI_Settings::get( 'respect_seo_noindex' ) ) {
			if ( '0' === (string) get_option( 'blog_public' ) ) {
				return 'site_noindex';
			}

			if ( self::is_seo_noindex( $post ) ) {
				return 'noindex';
			}
		}

		return '';
	}

	/**
	 * Readable explanation for a reason key.
	 *
	 * @param string $reason Key from reason().
	 * @return string
	 */
	public static function reason_label( $reason ) {
		$labels = array(
			''              => __( 'Served as Markdown', 'rawi-md' ),
			'not_published' => __( 'Not published', 'rawi-md' ),
			'password'      => __( 'Password protected', 'rawi-md' ),
			'post_type'     => __( 'This post type is not enabled', 'rawi-md' ),
			'excluded'      => __( 'Excluded by you', 'rawi-md' ),
			'site_noindex'  => __( 'The whole site discourages search engines', 'rawi-md' ),
			'noindex'       => __( 'Marked noindex by your SEO plugin', 'rawi-md' ),
		);

		return isset( $labels[ $reason ] ) ? $labels[ $reason ] : $reason;
	}

	/**
	 * Detect noindex set by Yoast SEO, Rank Math, SEOPress or AIOSEO, both on
	 * the post itself and as the default for its post type.
	 *
	 * @param WP_Post $post Post object.
	 * @return bool
	 */
	private static function is_seo_noindex( WP_Post $post ) {
		$post_id = (int) $post->ID;
		$type    = $post->post_type;

		// Yoast SEO: "1" = noindex, "2" = forced index, empty = post type default.
		$yoast = (string) get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );

		if ( '1' === $yoast ) {
			return true;
		}

		if ( '' === $yoast && class_exists( 'WPSEO_Options' ) && method_exists( 'WPSEO_Options', 'get' ) ) {
			if ( WPSEO_Options::get( 'noindex-' . $type, false ) ) {
				return true;
			}
		}

		// Rank Math: per-post robots array, else the post type or global default.
		$rank_math = get_post_meta( $post_id, 'rank_math_robots', true );

		if ( is_array( $rank_math ) && ! empty( $rank_math ) ) {
			if ( in_array( 'noindex', $rank_math, true ) ) {
				return true;
			}
		} elseif ( defined( 'RANK_MATH_VERSION' ) ) {
			$titles = get_option( 'rank-math-options-titles', array() );

			if ( is_array( $titles ) ) {
				$custom = isset( $titles[ 'pt_' . $type . '_custom_robots' ] ) && 'on' === $titles[ 'pt_' . $type . '_custom_robots' ];
				$robots = $custom
					? ( isset( $titles[ 'pt_' . $type . '_robots' ] ) ? $titles[ 'pt_' . $type . '_robots' ] : array() )
					: ( isset( $titles['robots_global'] ) ? $titles['robots_global'] : array() );

				if ( is_array( $robots ) && in_array( 'noindex', $robots, true ) ) {
					return true;
				}
			}
		}

		// SEOPress: "yes" means noindex.
		if ( 'yes' === (string) get_post_meta( $post_id, '_seopress_robots_index', true ) ) {
			return true;
		}

		// All in One SEO 4 keeps robots settings in its own table; older
		// installs mirror a legacy meta key.
		$aioseo = (string) get_post_meta( $post_id, '_aioseo_robots_noindex', true );

		if ( '1' === $aioseo || 'true' === $aioseo ) {
			return true;
		}

		if ( function_exists( 'aioseo' ) && self::aioseo_noindex( $post_id ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Read the AIOSEO 4 robots flag for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private static function aioseo_noindex( $post_id ) {
		global $wpdb;

		$cached = wp_cache_get( 'aioseo_' . $post_id, 'rawi' );

		if ( false !== $cached ) {
			return 'yes' === $cached;
		}

		$suppress = $wpdb->suppress_errors( true );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT robots_default, robots_noindex FROM %i WHERE post_id = %d LIMIT 1',
				$wpdb->prefix . 'aioseo_posts',
				$post_id
			),
			ARRAY_A
		);

		$wpdb->suppress_errors( $suppress );

		$noindex = is_array( $row ) && empty( $row['robots_default'] ) && ! empty( $row['robots_noindex'] );

		wp_cache_set( 'aioseo_' . $post_id, $noindex ? 'yes' : 'no', 'rawi', HOUR_IN_SECONDS );

		return $noindex;
	}
}
