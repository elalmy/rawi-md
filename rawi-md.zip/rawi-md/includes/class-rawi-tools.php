<?php
/**
 * Shared operations used by the dashboard, the editor and WP-CLI:
 * cache warming, the live self-test and the environment health checks.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Tools
 */
class RAWI_Tools {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'save_post', array( __CLASS__, 'schedule_warm' ), 20, 2 );
		add_action( 'rawi_warm_post', array( __CLASS__, 'warm_scheduled' ), 10, 1 );
	}

	/**
	 * After a post is published or updated, queue its Markdown so the first
	 * agent to arrive gets a cached document instead of waiting for one.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 * @return void
	 */
	public static function schedule_warm( $post_id, $post ) {
		if ( ! RAWI_Settings::get( 'auto_warm' ) || ! RAWI_Settings::get( 'cache_enabled' ) ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ! $post instanceof WP_Post ) {
			return;
		}

		RAWI_Eligibility::reset();

		if ( ! RAWI_Eligibility::is_eligible( $post ) ) {
			return;
		}

		$args = array( (int) $post_id );

		if ( ! wp_next_scheduled( 'rawi_warm_post', $args ) ) {
			// A few seconds' delay lets the editor finish saving meta and
			// terms, which change the document.
			wp_schedule_single_event( time() + 15, 'rawi_warm_post', $args );
		}
	}

	/**
	 * Cron callback: generate one post's document.
	 *
	 * It asks the site for the page exactly as an agent would, so builders
	 * render in a real front-end request. If a page cache answers instead,
	 * the document is generated directly.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function warm_scheduled( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post instanceof WP_Post || ! RAWI_Eligibility::is_eligible( $post ) ) {
			return;
		}

		if ( RAWI_Cache::has( $post->ID ) ) {
			return;
		}

		$response = wp_remote_get(
			(string) get_permalink( $post ),
			array(
				'timeout'     => 20,
				'redirection' => 2,
				'sslverify'   => (bool) apply_filters( 'https_local_ssl_verify', false ),
				'headers'     => array(
					'Accept'     => 'text/markdown',
					'User-Agent' => 'RawiMD-Warm/' . RAWI_VERSION,
				),
			)
		);

		$ok = ! is_wp_error( $response )
			&& 200 === (int) wp_remote_retrieve_response_code( $response )
			&& false !== stripos( (string) wp_remote_retrieve_header( $response, 'content-type' ), 'text/markdown' );

		if ( ! $ok || ! RAWI_Cache::has( $post->ID ) ) {
			self::warm_one( $post->ID, true );
		}
	}

	/**
	 * Generate and cache the document for one post.
	 *
	 * @param int  $post_id Post ID.
	 * @param bool $force   Regenerate even when cached.
	 * @return string generated | cached | skipped | empty
	 */
	public static function warm_one( $post_id, $force = false ) {
		$post = get_post( $post_id );

		if ( ! $post instanceof WP_Post || ! RAWI_Eligibility::is_eligible( $post ) || ! RAWI_Converter::is_available() ) {
			return 'skipped';
		}

		if ( ! $force && RAWI_Cache::has( $post->ID ) ) {
			$document = RAWI_Cache::get( $post->ID );

			if ( false !== $document ) {
				RAWI_Readiness::maybe_update( $post, $document );
				return 'cached';
			}
		}

		$result = RAWI_Renderer::render_with_metrics( $post );

		if ( '' === trim( $result['document'] ) ) {
			return 'empty';
		}

		RAWI_Cache::set( $post->ID, $result['document'] );
		RAWI_Readiness::update( $post, $result['document'] );

		return 'generated';
	}

	/**
	 * IDs of every eligible-looking published post, for batch warming.
	 *
	 * @return int[]
	 */
	public static function warmable_ids() {
		$types = RAWI_Settings::enabled_post_types();

		if ( empty( $types ) ) {
			return array();
		}

		return array_map(
			'intval',
			get_posts(
				array(
					'post_type'        => $types,
					'post_status'      => 'publish',
					'has_password'     => false,
					'numberposts'      => 5000,
					'fields'           => 'ids',
					'orderby'          => 'ID',
					'order'            => 'ASC',
					'suppress_filters' => false,
					'no_found_rows'    => true,
				)
			)
		);
	}

	/**
	 * A post to test with: the newest eligible one.
	 *
	 * @return WP_Post|null
	 */
	public static function sample_post() {
		$types = RAWI_Settings::enabled_post_types();

		if ( empty( $types ) ) {
			return null;
		}

		$posts = get_posts(
			array(
				'post_type'        => $types,
				'post_status'      => 'publish',
				'has_password'     => false,
				'numberposts'      => 10,
				'suppress_filters' => false,
			)
		);

		foreach ( $posts as $post ) {
			if ( RAWI_Eligibility::is_eligible( $post ) ) {
				return $post;
			}
		}

		return null;
	}

	/**
	 * Request the site the way an agent and a browser would, through every
	 * cache layer in front of it, and report what came back.
	 *
	 * @param string $url Page URL; empty to pick a sample post.
	 * @return array{url:string,checks:array[]}
	 */
	public static function self_test( $url = '' ) {
		$checks = array();
		$md_url = '';

		if ( '' === $url ) {
			$post = self::sample_post();

			if ( ! $post ) {
				return array(
					'url'    => '',
					'checks' => array(
						array(
							'state'  => 'fail',
							'label'  => __( 'Sample page', 'rawi-md' ),
							'detail' => __( 'No published post is eligible. Check the post types under Settings.', 'rawi-md' ),
						),
					),
				);
			}

			$url    = (string) get_permalink( $post );
			$md_url = RAWI_Router::markdown_url( $post );
		}

		$args = static function ( $accept ) {
			return array(
				'timeout'     => 15,
				'redirection' => 3,
				'sslverify'   => (bool) apply_filters( 'https_local_ssl_verify', false ),
				'headers'     => array(
					'Accept'     => $accept,
					'User-Agent' => 'RawiMD-SelfTest/' . RAWI_VERSION,
				),
			);
		};

		// 1. Agent on the canonical URL.
		$started  = microtime( true );
		$response = wp_remote_get( $url, $args( 'text/markdown, text/html;q=0.5' ) );
		$ms       = (int) round( ( microtime( true ) - $started ) * 1000 );

		if ( is_wp_error( $response ) ) {
			$checks[] = array(
				'state'  => 'fail',
				'label'  => __( 'Accept: text/markdown', 'rawi-md' ),
				'detail' => $response->get_error_message(),
			);
		} else {
			$type   = (string) wp_remote_retrieve_header( $response, 'content-type' );
			$tokens = (string) wp_remote_retrieve_header( $response, 'x-markdown-tokens' );

			if ( false !== stripos( $type, 'text/markdown' ) ) {
				$checks[] = array(
					'state'  => 'pass',
					'label'  => __( 'Accept: text/markdown', 'rawi-md' ),
					/* translators: 1: token count, 2: milliseconds. */
					'detail' => sprintf( __( 'Markdown returned, %1$s tokens, in %2$s ms.', 'rawi-md' ), $tokens, $ms ),
				);
			} else {
				$checks[] = array(
					'state'  => 'fail',
					'label'  => __( 'Accept: text/markdown', 'rawi-md' ),
					/* translators: %s: content type received. */
					'detail' => sprintf( __( 'Got %s instead. A page cache is answering before WordPress runs: apply the server rules.', 'rawi-md' ), '' !== $type ? $type : '?' ),
				);
			}
		}

		// 2. A browser on the same URL must still get HTML.
		$response = wp_remote_get( $url, $args( 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' ) );

		if ( ! is_wp_error( $response ) ) {
			$type = (string) wp_remote_retrieve_header( $response, 'content-type' );

			$checks[] = false === stripos( $type, 'text/markdown' )
				? array(
					'state'  => 'pass',
					'label'  => __( 'Browsers still get HTML', 'rawi-md' ),
					'detail' => __( 'Visitors are unaffected.', 'rawi-md' ),
				)
				: array(
					'state'  => 'fail',
					'label'  => __( 'Browsers still get HTML', 'rawi-md' ),
					'detail' => __( 'A cache served Markdown to a browser. Your CDN ignores Vary: Accept — apply the Cloudflare or server rule now.', 'rawi-md' ),
				);
		}

		// 3. The .md address.
		if ( '' !== $md_url && false === strpos( $md_url, 'format=md' ) ) {
			$response = wp_remote_get( $md_url, $args( '*/*' ) );

			if ( is_wp_error( $response ) ) {
				$checks[] = array(
					'state'  => 'fail',
					'label'  => __( '.md address', 'rawi-md' ),
					'detail' => $response->get_error_message(),
				);
			} else {
				$code = (int) wp_remote_retrieve_response_code( $response );
				$type = (string) wp_remote_retrieve_header( $response, 'content-type' );

				$checks[] = ( 200 === $code && false !== stripos( $type, 'text/markdown' ) )
					? array(
						'state'  => 'pass',
						'label'  => __( '.md address', 'rawi-md' ),
						'detail' => $md_url,
					)
					: array(
						'state'  => 'warn',
						/* translators: 1: HTTP status, 2: content type. */
						'label'  => __( '.md address', 'rawi-md' ),
						'detail' => sprintf( __( 'Answered %1$d %2$s. Re-save Settings > Permalinks to refresh the rewrite rules.', 'rawi-md' ), $code, $type ),
					);
			}
		}

		// 4. llms.txt.
		if ( RAWI_Settings::get( 'llms_enabled' ) ) {
			$response = wp_remote_get( RAWI_Llms::url(), $args( 'text/plain' ) );
			$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
			$body     = is_wp_error( $response ) ? '' : (string) wp_remote_retrieve_body( $response );
			$ours     = ! is_wp_error( $response ) && '' !== (string) wp_remote_retrieve_header( $response, 'x-markdown-generator' );

			if ( 200 === $code && $ours ) {
				$checks[] = array(
					'state'  => 'pass',
					'label'  => 'llms.txt',
					/* translators: %d: number of listed pages. */
					'detail' => sprintf( __( '%d pages listed.', 'rawi-md' ), substr_count( $body, "\n- [" ) ),
				);
			} elseif ( 200 === $code ) {
				$checks[] = array(
					'state'  => 'warn',
					'label'  => 'llms.txt',
					'detail' => __( 'A static llms.txt file on the server is answering instead of the generated one.', 'rawi-md' ),
				);
			} else {
				$checks[] = array(
					'state'  => 'warn',
					'label'  => 'llms.txt',
					/* translators: %d: HTTP status. */
					'detail' => sprintf( __( 'Answered %d. Re-save Settings > Permalinks.', 'rawi-md' ), $code ),
				);
			}
		}

		return array(
			'url'    => $url,
			'checks' => $checks,
		);
	}

	/**
	 * Static environment checks for the dashboard.
	 *
	 * @return array[] state, label, detail.
	 */
	public static function health() {
		$checks = array();

		$checks[] = RAWI_Converter::is_available()
			? array( 'pass', __( 'PHP DOM extension', 'rawi-md' ), __( 'Available', 'rawi-md' ) )
			: array( 'fail', __( 'PHP DOM extension', 'rawi-md' ), __( 'Missing: nothing is converted until your host enables php-xml.', 'rawi-md' ) );

		$checks[] = get_option( 'permalink_structure' )
			? array( 'pass', __( 'Pretty permalinks', 'rawi-md' ), __( '.md addresses and /llms.txt work.', 'rawi-md' ) )
			: array( 'warn', __( 'Pretty permalinks', 'rawi-md' ), __( 'Plain permalinks: agents fall back to ?format=md.', 'rawi-md' ) );

		$checks[] = RAWI_Cache::is_writable()
			? array( 'pass', __( 'Cache folder', 'rawi-md' ), __( 'Writable', 'rawi-md' ) )
			: array( 'warn', __( 'Cache folder', 'rawi-md' ), __( 'Not writable: every request is converted from scratch.', 'rawi-md' ) );

		$types = RAWI_Settings::enabled_post_types();

		$checks[] = ! empty( $types )
			? array( 'pass', __( 'Post types', 'rawi-md' ), implode( ', ', $types ) )
			: array( 'fail', __( 'Post types', 'rawi-md' ), __( 'None enabled.', 'rawi-md' ) );

		if ( '0' === (string) get_option( 'blog_public' ) ) {
			$checks[] = array( 'warn', __( 'Search engine visibility', 'rawi-md' ), __( 'The site discourages search engines, so nothing is served while "Skip noindex pages" is on.', 'rawi-md' ) );
		}

		$caches = RAWI_Cache_Compat::detected_caches();

		if ( ! empty( $caches ) ) {
			/* translators: %s: list of cache layers. */
			$checks[] = array( 'warn', __( 'Page cache', 'rawi-md' ), sprintf( __( '%s detected: apply the rules from the Server rules tab, then run the live test.', 'rawi-md' ), implode( ', ', $caches ) ) );
		} else {
			$checks[] = array( 'pass', __( 'Page cache', 'rawi-md' ), __( 'No page cache detected in WordPress.', 'rawi-md' ) );
		}

		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
			$checks[] = array( 'warn', __( 'WP-Cron', 'rawi-md' ), __( 'Disabled: make sure a server cron calls wp-cron.php, or log pruning and HTML measurement stall.', 'rawi-md' ) );
		}

		if ( RAWI_Settings::get( 'verify_bots' ) ) {
			$async = function_exists( 'fastcgi_finish_request' ) || function_exists( 'litespeed_finish_request' );

			$checks[] = $async
				? array( 'pass', __( 'Crawler verification', 'rawi-md' ), __( 'Runs after the response is sent; agents never wait.', 'rawi-md' ) )
				: array( 'warn', __( 'Crawler verification', 'rawi-md' ), __( 'This server cannot finish a response early, so DNS checks are skipped. IP list checks still work.', 'rawi-md' ) );
		}

		if ( RAWI_Settings::get( 'llms_enabled' ) && file_exists( ABSPATH . 'llms.txt' ) ) {
			$checks[] = array( 'warn', 'llms.txt', __( 'A static llms.txt file exists in the site root and hides the generated one.', 'rawi-md' ) );
		}

		if ( ! RAWI_Settings::get( 'log_enabled' ) ) {
			$checks[] = array( 'warn', __( 'Request log', 'rawi-md' ), __( 'Off: the dashboard will not receive new data.', 'rawi-md' ) );
		}

		$out = array();

		foreach ( $checks as $check ) {
			$out[] = array(
				'state'  => $check[0],
				'label'  => $check[1],
				'detail' => $check[2],
			);
		}

		return $out;
	}
}
