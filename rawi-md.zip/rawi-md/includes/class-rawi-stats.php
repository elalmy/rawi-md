<?php
/**
 * Reporting queries behind the dashboard, the CLI and the editor meta box.
 *
 * Every query is bounded by requested_at, which is indexed, and grouped in
 * the database, so the dashboard stays fast with hundreds of thousands of
 * logged requests.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Stats
 */
class RAWI_Stats {

	/**
	 * Ranges the dashboard offers, in days.
	 *
	 * @return int[]
	 */
	public static function ranges() {
		return array( 1, 7, 30, 90, 365 );
	}

	/**
	 * Clamp a requested range to one of the offered values.
	 *
	 * @param mixed $days Requested days.
	 * @return int
	 */
	public static function normalise_range( $days ) {
		$days = absint( $days );

		return in_array( $days, self::ranges(), true ) ? $days : 30;
	}

	/**
	 * Seconds to add to UTC to get the site's local time.
	 *
	 * @return int
	 */
	private static function offset() {
		return (int) wp_timezone()->getOffset( new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) ) );
	}

	/**
	 * Format a UTC MySQL datetime as ISO 8601 for the browser.
	 *
	 * @param string $mysql UTC datetime.
	 * @return string
	 */
	private static function iso( $mysql ) {
		if ( empty( $mysql ) ) {
			return '';
		}

		$ts = strtotime( $mysql . ' UTC' );

		return $ts ? gmdate( 'Y-m-d\TH:i:s\Z', $ts ) : '';
	}

	/**
	 * Everything the dashboard draws, for one range.
	 *
	 * @param int $days Range in days.
	 * @return array
	 */
	public static function dashboard( $days ) {
		$days = self::normalise_range( $days );
		$now  = time();

		$from      = gmdate( 'Y-m-d H:i:s', $now - $days * DAY_IN_SECONDS );
		$prev_from = gmdate( 'Y-m-d H:i:s', $now - 2 * $days * DAY_IN_SECONDS );
		$to        = gmdate( 'Y-m-d H:i:s', $now + MINUTE_IN_SECONDS );

		$agents = self::agents( $from, $to );

		return array(
			'range'     => $days,
			'generated' => gmdate( 'Y-m-d\TH:i:s\Z', $now ),
			'kpis'      => self::kpis( $from, $to ),
			'previous'  => self::kpis( $prev_from, $from ),
			'series'    => self::series( $days, $from, $to ),
			'heatmap'   => self::heatmap( $from, $to ),
			'agents'    => $agents,
			'kinds'     => self::group_agents( $agents, 'kind' ),
			'operators' => self::group_agents( $agents, 'operator' ),
			'routes'    => self::routes( $from, $to ),
			'statuses'  => self::statuses( $from, $to ),
			'pages'     => self::pages( $from, $to, 25 ),
			'missing'   => self::missing( $from, $to ),
			'coverage'  => self::coverage( $from, $to ),
			'recent'    => self::recent( 40 ),
			'lifetime'  => self::lifetime(),
			'referrals' => RAWI_Referrals::dashboard( $days, $from, $to, $prev_from ),
			'readiness' => RAWI_Readiness::summary(),
		);
	}

	/**
	 * Headline figures for a window.
	 *
	 * @param string $from UTC start, inclusive.
	 * @param string $to   UTC end, exclusive.
	 * @return array
	 */
	public static function kpis( $from, $to ) {
		global $wpdb;

		// Columns added in 1.3.0 hold 0 on rows logged before the update;
		// cache and timing rates only count rows that could have recorded them.
		$since = (string) get_option( 'rawi_metrics_since', '' );
		$since = '' !== $since ? $since : '1970-01-01 00:00:00';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
					COUNT(*) AS requests,
					COALESCE(SUM(status = 200), 0) AS served,
					COALESCE(SUM(status = 304), 0) AS not_modified,
					COALESCE(SUM(status = 404), 0) AS missing,
					COUNT(DISTINCT agent_label) AS agents,
					COUNT(DISTINCT CASE WHEN post_id > 0 THEN post_id END) AS pages,
					COUNT(DISTINCT CASE WHEN ip_hash <> '' THEN ip_hash END) AS clients,
					COALESCE(SUM(tokens), 0) AS md_tokens,
					COALESCE(SUM(CASE WHEN html_tokens > 0 THEN html_tokens END), 0) AS html_measured,
					COALESCE(SUM(CASE WHEN html_tokens > 0 THEN tokens END), 0) AS md_measured,
					COALESCE(SUM(status = 200 AND requested_at >= %s), 0) AS served_tracked,
					COALESCE(SUM(status = 200 AND cache_hit = 1 AND requested_at >= %s), 0) AS cache_hits,
					AVG(CASE WHEN cache_hit = 0 AND gen_ms > 0 THEN gen_ms END) AS avg_ms,
					COALESCE(SUM(verified = 1), 0) AS verified,
					COALESCE(SUM(verified = 2), 0) AS spoofed,
					COALESCE(SUM(route = 'llms'), 0) AS llms
				FROM %i
				WHERE requested_at >= %s AND requested_at < %s",
				$since,
				$since,
				RAWI_Logger::table(),
				$from,
				$to
			),
			ARRAY_A
		);

		$row = is_array( $row ) ? $row : array();
		$int = static function ( $key ) use ( $row ) {
			return isset( $row[ $key ] ) ? (int) $row[ $key ] : 0;
		};

		$html_measured = $int( 'html_measured' );
		$md_measured   = $int( 'md_measured' );
		$served        = $int( 'served_tracked' );

		return array(
			'requests'      => $int( 'requests' ),
			'served'        => $int( 'served' ),
			'not_modified'  => $int( 'not_modified' ),
			'missing'       => $int( 'missing' ),
			'agents'        => $int( 'agents' ),
			'pages'         => $int( 'pages' ),
			'clients'       => $int( 'clients' ),
			'md_tokens'     => $int( 'md_tokens' ),
			'html_measured' => $html_measured,
			'md_measured'   => $md_measured,
			'tokens_saved'  => max( 0, $html_measured - $md_measured ),
			'saving_pct'    => $html_measured > 0 ? round( ( 1 - $md_measured / $html_measured ) * 100, 1 ) : null,
			'cache_hits'    => $int( 'cache_hits' ),
			'cache_rate'    => $served > 0 ? round( $int( 'cache_hits' ) / $served * 100, 1 ) : null,
			'avg_ms'        => isset( $row['avg_ms'] ) && null !== $row['avg_ms'] ? (int) round( (float) $row['avg_ms'] ) : null,
			'verified'      => $int( 'verified' ),
			'spoofed'       => $int( 'spoofed' ),
			'llms'          => $int( 'llms' ),
		);
	}

	/**
	 * Requests per bucket, split by the busiest agents.
	 *
	 * Hourly buckets for a one-day range, daily otherwise, both in the site's
	 * own timezone so "today" means the owner's today.
	 *
	 * @param int    $days Range in days.
	 * @param string $from UTC start.
	 * @param string $to   UTC end.
	 * @return array{buckets:string[],unit:string,series:array[]}
	 */
	public static function series( $days, $from, $to ) {
		return self::bucketed( RAWI_Logger::table(), 'requested_at', 'agent_label', $days, $from, $to );
	}

	/**
	 * Counts per time bucket for any log table, split by its busiest values
	 * of one column. Shared by the crawler timeline and the referral timeline.
	 *
	 * @param string $table    Table name.
	 * @param string $time_col Datetime column, UTC.
	 * @param string $group    Column to split by.
	 * @param int    $days     Range in days.
	 * @param string $from     UTC start.
	 * @param string $to       UTC end.
	 * @return array{buckets:string[],unit:string,series:array[]}
	 */
	public static function bucketed( $table, $time_col, $group, $days, $from, $to ) {
		global $wpdb;

		$offset = self::offset();
		$hourly = ( 1 === (int) $days );
		$format = $hourly ? '%Y-%m-%d %H:00' : '%Y-%m-%d';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT DATE_FORMAT(DATE_ADD(%i, INTERVAL %d SECOND), %s) AS bucket, %i AS grp, COUNT(*) AS hits
				 FROM %i
				 WHERE %i >= %s AND %i < %s
				 GROUP BY bucket, grp',
				$time_col,
				$offset,
				$format,
				$group,
				$table,
				$time_col,
				$from,
				$time_col,
				$to
			),
			ARRAY_A
		);

		$rows = is_array( $rows ) ? $rows : array();

		// Bucket labels, oldest first, with no gaps.
		$buckets = array();
		$step    = $hourly ? HOUR_IN_SECONDS : DAY_IN_SECONDS;
		$count   = $hourly ? 24 : (int) $days;
		$now     = time() + $offset;

		for ( $i = $count - 1; $i >= 0; $i-- ) {
			$buckets[] = gmdate( $hourly ? 'Y-m-d H:00' : 'Y-m-d', $now - $i * $step );
		}

		// The five busiest agents get their own series; the rest are pooled.
		$totals = array();

		foreach ( $rows as $row ) {
			$label            = (string) $row['grp'];
			$totals[ $label ] = ( isset( $totals[ $label ] ) ? $totals[ $label ] : 0 ) + (int) $row['hits'];
		}

		arsort( $totals );

		$top    = array_slice( array_keys( $totals ), 0, 5 );
		$index  = array_flip( $buckets );
		$series = array();

		foreach ( $top as $label ) {
			$series[ $label ] = array_fill( 0, count( $buckets ), 0 );
		}

		$other = array_fill( 0, count( $buckets ), 0 );

		foreach ( $rows as $row ) {
			if ( ! isset( $index[ $row['bucket'] ] ) ) {
				continue;
			}

			$i = $index[ $row['bucket'] ];

			if ( isset( $series[ $row['grp'] ] ) ) {
				$series[ $row['grp'] ][ $i ] += (int) $row['hits'];
			} else {
				$other[ $i ] += (int) $row['hits'];
			}
		}

		$out = array();

		foreach ( $series as $label => $values ) {
			$out[] = array(
				'label'  => (string) $label,
				'values' => $values,
			);
		}

		if ( array_sum( $other ) > 0 ) {
			$out[] = array(
				'label'  => '__other',
				'values' => $other,
			);
		}

		return array(
			'buckets' => $buckets,
			'unit'    => $hourly ? 'hour' : 'day',
			'series'  => $out,
		);
	}

	/**
	 * Requests by weekday and hour, in the site's timezone.
	 *
	 * @param string $from UTC start.
	 * @param string $to   UTC end.
	 * @return int[][] 7 rows (Sunday first) of 24 hours.
	 */
	public static function heatmap( $from, $to ) {
		global $wpdb;

		$offset = self::offset();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT DAYOFWEEK(DATE_ADD(requested_at, INTERVAL %d SECOND)) AS dow,
				        HOUR(DATE_ADD(requested_at, INTERVAL %d SECOND)) AS hr,
				        COUNT(*) AS hits
				 FROM %i
				 WHERE requested_at >= %s AND requested_at < %s
				 GROUP BY dow, hr',
				$offset,
				$offset,
				RAWI_Logger::table(),
				$from,
				$to
			),
			ARRAY_A
		);

		$grid = array_fill( 0, 7, array_fill( 0, 24, 0 ) );

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$d = (int) $row['dow'] - 1; // MySQL: 1 = Sunday.
			$h = (int) $row['hr'];

			if ( $d >= 0 && $d < 7 && $h >= 0 && $h < 24 ) {
				$grid[ $d ][ $h ] = (int) $row['hits'];
			}
		}

		return $grid;
	}

	/**
	 * Per-agent breakdown.
	 *
	 * @param string $from  UTC start.
	 * @param string $to    UTC end.
	 * @param int    $limit Maximum rows.
	 * @return array[]
	 */
	public static function agents( $from, $to, $limit = 60 ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT agent_label,
				        COUNT(*) AS hits,
				        COUNT(DISTINCT CASE WHEN post_id > 0 THEN post_id END) AS pages,
				        MAX(requested_at) AS last_seen,
				        COALESCE(SUM(verified = 1), 0) AS verified,
				        COALESCE(SUM(verified = 2), 0) AS spoofed,
				        COALESCE(SUM(tokens), 0) AS tokens,
				        COALESCE(SUM(route = %s), 0) AS via_accept
				 FROM %i
				 WHERE requested_at >= %s AND requested_at < %s
				 GROUP BY agent_label
				 ORDER BY hits DESC
				 LIMIT %d',
				'accept',
				RAWI_Logger::table(),
				$from,
				$to,
				$limit
			),
			ARRAY_A
		);

		$out = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$label = (string) $row['agent_label'];
			$info  = RAWI_Agents::info( $label );

			$out[] = array(
				'label'      => $label,
				'operator'   => $info['operator'],
				'kind'       => $info['kind'],
				'hits'       => (int) $row['hits'],
				'pages'      => (int) $row['pages'],
				'last_seen'  => self::iso( $row['last_seen'] ),
				'verified'   => (int) $row['verified'],
				'spoofed'    => (int) $row['spoofed'],
				'tokens'     => (int) $row['tokens'],
				'via_accept' => (int) $row['via_accept'],
				'verifiable' => RAWI_Verify::is_verifiable( $label ),
			);
		}

		return $out;
	}

	/**
	 * Sum agent rows by kind or operator.
	 *
	 * @param array[] $agents Rows from agents().
	 * @param string  $field  kind | operator.
	 * @return array[] label, hits.
	 */
	private static function group_agents( array $agents, $field ) {
		$groups = array();

		foreach ( $agents as $agent ) {
			$key = '' !== $agent[ $field ] ? $agent[ $field ] : ( 'operator' === $field ? '__unknown' : 'other' );

			$groups[ $key ] = ( isset( $groups[ $key ] ) ? $groups[ $key ] : 0 ) + $agent['hits'];
		}

		arsort( $groups );

		$out = array();

		foreach ( $groups as $key => $hits ) {
			$out[] = array(
				'key'  => (string) $key,
				'hits' => (int) $hits,
			);
		}

		return $out;
	}

	/**
	 * Requests per route.
	 *
	 * @param string $from UTC start.
	 * @param string $to   UTC end.
	 * @return array[]
	 */
	public static function routes( $from, $to ) {
		return self::grouped( 'route', $from, $to );
	}

	/**
	 * Requests per HTTP status.
	 *
	 * @param string $from UTC start.
	 * @param string $to   UTC end.
	 * @return array[]
	 */
	public static function statuses( $from, $to ) {
		return self::grouped( 'status', $from, $to );
	}

	/**
	 * Count rows grouped by one whitelisted column.
	 *
	 * @param string $column route | status.
	 * @param string $from   UTC start.
	 * @param string $to     UTC end.
	 * @return array[]
	 */
	private static function grouped( $column, $from, $to ) {
		global $wpdb;

		if ( ! in_array( $column, array( 'route', 'status' ), true ) ) {
			return array();
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT %i AS k, COUNT(*) AS hits FROM %i
				 WHERE requested_at >= %s AND requested_at < %s
				 GROUP BY k ORDER BY hits DESC',
				$column,
				RAWI_Logger::table(),
				$from,
				$to
			),
			ARRAY_A
		);

		$out = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$out[] = array(
				'key'  => (string) $row['k'],
				'hits' => (int) $row['hits'],
			);
		}

		return $out;
	}

	/**
	 * Most requested posts with their token economics.
	 *
	 * @param string $from  UTC start.
	 * @param string $to    UTC end.
	 * @param int    $limit Maximum rows.
	 * @return array[]
	 */
	public static function pages( $from, $to, $limit = 25 ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT post_id,
				        COUNT(*) AS hits,
				        COUNT(DISTINCT agent_label) AS agents,
				        MAX(requested_at) AS last_seen,
				        AVG(NULLIF(tokens, 0)) AS md_tokens,
				        AVG(NULLIF(html_tokens, 0)) AS html_tokens
				 FROM %i
				 WHERE requested_at >= %s AND requested_at < %s AND post_id > 0
				 GROUP BY post_id
				 ORDER BY hits DESC
				 LIMIT %d',
				RAWI_Logger::table(),
				$from,
				$to,
				$limit
			),
			ARRAY_A
		);

		$rows = is_array( $rows ) ? $rows : array();

		if ( ! empty( $rows ) ) {
			_prime_post_caches( array_map( 'intval', wp_list_pluck( $rows, 'post_id' ) ), false, false );
		}

		$out = array();

		foreach ( $rows as $row ) {
			$post_id = (int) $row['post_id'];
			$post    = get_post( $post_id );
			$md      = null !== $row['md_tokens'] ? (int) round( (float) $row['md_tokens'] ) : 0;
			$html    = null !== $row['html_tokens'] ? (int) round( (float) $row['html_tokens'] ) : 0;

			$out[] = array(
				'id'          => $post_id,
				'title'       => $post ? html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ) : '#' . $post_id,
				'type'        => $post ? $post->post_type : '',
				'exists'      => (bool) $post,
				'url'         => $post ? (string) get_permalink( $post ) : '',
				'md_url'      => $post ? RAWI_Router::markdown_url( $post ) : '',
				'edit_url'    => $post ? (string) get_edit_post_link( $post, 'raw' ) : '',
				'hits'        => (int) $row['hits'],
				'agents'      => (int) $row['agents'],
				'last_seen'   => self::iso( $row['last_seen'] ),
				'md_tokens'   => $md,
				'html_tokens' => $html,
				'saving_pct'  => ( $html > 0 && $md > 0 ) ? round( ( 1 - $md / $html ) * 100, 1 ) : null,
			);
		}

		return $out;
	}

	/**
	 * Markdown addresses agents asked for that do not exist.
	 *
	 * @param string $from UTC start.
	 * @param string $to   UTC end.
	 * @return array[]
	 */
	public static function missing( $from, $to ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT url_path, COUNT(*) AS hits, MAX(requested_at) AS last_seen
				 FROM %i
				 WHERE requested_at >= %s AND requested_at < %s AND status = 404
				 GROUP BY url_path ORDER BY hits DESC LIMIT 15',
				RAWI_Logger::table(),
				$from,
				$to
			),
			ARRAY_A
		);

		$out = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$out[] = array(
				'path'      => (string) $row['url_path'],
				'hits'      => (int) $row['hits'],
				'last_seen' => self::iso( $row['last_seen'] ),
			);
		}

		return $out;
	}

	/**
	 * How much of the site agents have actually read, per post type.
	 *
	 * @param string $from UTC start.
	 * @param string $to   UTC end.
	 * @return array
	 */
	public static function coverage( $from, $to ) {
		global $wpdb;

		$types = RAWI_Settings::enabled_post_types();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT p.post_type AS type, COUNT(DISTINCT r.post_id) AS read_count
				 FROM %i r
				 INNER JOIN %i p ON p.ID = r.post_id
				 WHERE r.requested_at >= %s AND r.requested_at < %s AND r.post_id > 0
				 GROUP BY p.post_type',
				RAWI_Logger::table(),
				$wpdb->posts,
				$from,
				$to
			),
			ARRAY_A
		);

		$read = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$read[ $row['type'] ] = (int) $row['read_count'];
		}

		$out = array();

		foreach ( $types as $type ) {
			$object = get_post_type_object( $type );

			if ( ! $object ) {
				continue;
			}

			$counts    = wp_count_posts( $type );
			$published = isset( $counts->publish ) ? (int) $counts->publish : 0;

			$out[] = array(
				'type'      => $type,
				'label'     => $object->labels->name,
				'published' => $published,
				'read'      => isset( $read[ $type ] ) ? min( $published, $read[ $type ] ) : 0,
			);
		}

		$usage = RAWI_Cache::usage();

		return array(
			'types'        => $out,
			'cached_files' => $usage['files'],
			'cached_bytes' => $usage['bytes'],
		);
	}

	/**
	 * Latest requests, newest first.
	 *
	 * @param int $limit   Maximum rows.
	 * @param int $after   Only rows with a larger id, for live polling.
	 * @return array[]
	 */
	public static function recent( $limit = 40, $after = 0 ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, requested_at, post_id, route, url_path, agent_label, status, tokens, cache_hit, gen_ms, verified
				 FROM %i WHERE id > %d ORDER BY id DESC LIMIT %d',
				RAWI_Logger::table(),
				absint( $after ),
				max( 1, min( 200, absint( $limit ) ) )
			),
			ARRAY_A
		);

		$rows = is_array( $rows ) ? $rows : array();

		$ids = array_filter( array_map( 'intval', wp_list_pluck( $rows, 'post_id' ) ) );

		if ( ! empty( $ids ) ) {
			_prime_post_caches( $ids, false, false );
		}

		$out = array();

		foreach ( $rows as $row ) {
			$post_id = (int) $row['post_id'];
			$title   = '';

			if ( $post_id ) {
				$title = html_entity_decode( wp_strip_all_tags( get_the_title( $post_id ) ), ENT_QUOTES, 'UTF-8' );
			} elseif ( 'llms' === $row['route'] ) {
				$title = 'llms.txt';
			}

			$info = RAWI_Agents::info( (string) $row['agent_label'] );

			$out[] = array(
				'id'        => (int) $row['id'],
				'time'      => self::iso( $row['requested_at'] ),
				'post_id'   => $post_id,
				'title'     => '' !== $title ? $title : (string) $row['url_path'],
				'path'      => (string) $row['url_path'],
				'route'     => (string) $row['route'],
				'agent'     => (string) $row['agent_label'],
				'kind'      => $info['kind'],
				'status'    => (int) $row['status'],
				'tokens'    => (int) $row['tokens'],
				'cache_hit' => (bool) $row['cache_hit'],
				'gen_ms'    => (int) $row['gen_ms'],
				'verified'  => (int) $row['verified'],
			);
		}

		return $out;
	}

	/**
	 * All-time totals.
	 *
	 * @return array
	 */
	public static function lifetime() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT COUNT(*) AS requests, MIN(requested_at) AS first_seen, MAX(requested_at) AS last_seen,
				        COALESCE(SUM(tokens), 0) AS tokens, COUNT(DISTINCT agent_label) AS agents
				 FROM %i',
				RAWI_Logger::table()
			),
			ARRAY_A
		);

		$row = is_array( $row ) ? $row : array();

		return array(
			'requests'   => isset( $row['requests'] ) ? (int) $row['requests'] : 0,
			'tokens'     => isset( $row['tokens'] ) ? (int) $row['tokens'] : 0,
			'agents'     => isset( $row['agents'] ) ? (int) $row['agents'] : 0,
			'first_seen' => isset( $row['first_seen'] ) ? self::iso( $row['first_seen'] ) : '',
			'last_seen'  => isset( $row['last_seen'] ) ? self::iso( $row['last_seen'] ) : '',
		);
	}

	/**
	 * Requests and agents for one post, for the editor meta box.
	 *
	 * @param int $post_id Post ID.
	 * @param int $days    Window in days.
	 * @return array
	 */
	public static function for_post( $post_id, $days = 30 ) {
		global $wpdb;

		$from = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT agent_label, COUNT(*) AS hits, MAX(requested_at) AS last_seen
				 FROM %i WHERE post_id = %d AND requested_at >= %s
				 GROUP BY agent_label ORDER BY hits DESC LIMIT 6',
				RAWI_Logger::table(),
				$post_id,
				$from
			),
			ARRAY_A
		);

		$rows  = is_array( $rows ) ? $rows : array();
		$total = 0;
		$last  = '';

		foreach ( $rows as $row ) {
			$total += (int) $row['hits'];
			$last   = max( $last, (string) $row['last_seen'] );
		}

		return array(
			'total'  => $total,
			'last'   => $last,
			'agents' => $rows,
		);
	}

	/**
	 * Stream the log for a window as CSV.
	 *
	 * @param int $days Range in days, 0 for everything.
	 * @return void
	 */
	public static function export_csv( $days ) {
		global $wpdb;

		$days = absint( $days );
		$from = $days > 0 ? gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) : '1970-01-01 00:00:00';

		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="rawi-md-requests-' . gmdate( 'Y-m-d' ) . '.csv"' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		// UTF-8 byte order mark, so spreadsheet apps read Arabic titles right.
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite

		fputcsv( $out, array( 'time_utc', 'post_id', 'title', 'route', 'status', 'agent', 'verified', 'tokens', 'html_tokens', 'cache_hit', 'gen_ms', 'path', 'user_agent' ) );

		$last_id = PHP_INT_MAX;

		// Paged by id so a large log never sits in memory at once.
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					'SELECT * FROM %i WHERE requested_at >= %s AND id < %d ORDER BY id DESC LIMIT 2000',
					RAWI_Logger::table(),
					$from,
					$last_id
				),
				ARRAY_A
			);

			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				$last_id = (int) $row['id'];
				$title   = $row['post_id'] ? html_entity_decode( wp_strip_all_tags( get_the_title( (int) $row['post_id'] ) ), ENT_QUOTES, 'UTF-8' ) : '';

				$cells = array(
					$row['requested_at'],
					$row['post_id'],
					$title,
					$row['route'],
					$row['status'],
					$row['agent_label'],
					array( 'unchecked', 'verified', 'spoofed' )[ (int) $row['verified'] ] ?? 'unchecked',
					$row['tokens'],
					$row['html_tokens'],
					$row['cache_hit'],
					$row['gen_ms'],
					$row['url_path'],
					$row['user_agent'],
				);

				// Neutralise spreadsheet formulas in values an outsider controls.
				foreach ( $cells as $i => $cell ) {
					$cell = (string) $cell;
					if ( '' !== $cell && in_array( $cell[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
						$cells[ $i ] = "'" . $cell;
					}
				}

				fputcsv( $out, $cells );
			}

			if ( function_exists( 'wp_cache_flush_runtime' ) ) {
				wp_cache_flush_runtime();
			}
		} while ( is_array( $rows ) && count( $rows ) === 2000 );

		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
	}
}
