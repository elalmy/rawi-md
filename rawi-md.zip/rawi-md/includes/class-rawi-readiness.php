<?php
/**
 * AI readiness: a 0–100 score per page, from the Markdown an agent receives.
 *
 * Each check is something an answer engine demonstrably uses or trips over:
 * a stated summary, enough substance, headings to chunk by, alt text,
 * structure, links, freshness, size. Checks that cannot apply to a page are
 * left out of its score instead of counting against it.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Readiness
 */
class RAWI_Readiness {

	const META_SCORE = '_rawi_readiness_score';
	const META_DATA  = '_rawi_readiness';

	/**
	 * Check keys and their weights.
	 *
	 * @return int[]
	 */
	public static function weights() {
		return array(
			'description' => 15,
			'length'      => 15,
			'headings'    => 15,
			'alt_text'    => 10,
			'structure'   => 10,
			'links'       => 10,
			'fresh'       => 10,
			'weight'      => 10,
			'size'        => 5,
		);
	}

	/**
	 * Readable names and fixes for each check.
	 *
	 * @return array[] key => array( label, hint ).
	 */
	public static function labels() {
		return array(
			'description' => array( __( 'Has a summary', 'rawi-md' ), __( 'Write an excerpt or an SEO meta description. Agents quote it as the page summary.', 'rawi-md' ) ),
			'length'      => array( __( 'Enough substance', 'rawi-md' ), __( 'Thin pages are rarely cited. Aim for at least 300 words (80 for products).', 'rawi-md' ) ),
			'headings'    => array( __( 'Clear headings', 'rawi-md' ), __( 'Split long content with H2/H3 headings and do not skip levels. Agents chunk by heading.', 'rawi-md' ) ),
			'alt_text'    => array( __( 'Images described', 'rawi-md' ), __( 'Add alt text to images. Without it an agent sees an image it cannot describe.', 'rawi-md' ) ),
			'structure'   => array( __( 'Structured content', 'rawi-md' ), __( 'Long pages read better with a list or a table for steps, specs or comparisons.', 'rawi-md' ) ),
			'links'       => array( __( 'Internal links', 'rawi-md' ), __( 'Link to related pages on your site so agents can follow the topic.', 'rawi-md' ) ),
			'fresh'       => array( __( 'Recently updated', 'rawi-md' ), __( 'Not updated for over a year. Answer engines prefer current information.', 'rawi-md' ) ),
			'weight'      => array( __( 'Light Markdown', 'rawi-md' ), __( 'The Markdown is not much lighter than the HTML: check the removal lists for leftover theme parts.', 'rawi-md' ) ),
			'size'        => array( __( 'Reasonable size', 'rawi-md' ), __( 'Over 25,000 tokens: many agents truncate a page this long. Consider splitting it.', 'rawi-md' ) ),
		);
	}

	/**
	 * Analyse a post's Markdown.
	 *
	 * @param WP_Post $post     Post.
	 * @param string  $markdown Document as served, frontmatter included.
	 * @return array{score:int,checks:array}
	 */
	public static function analyze( WP_Post $post, $markdown ) {
		$markdown = str_replace( "\r\n", "\n", (string) $markdown );
		$body     = (string) preg_replace( '/\A---\n.*?\n---\n/s', '', $markdown );

		// Prose only: code blocks would inflate the word count.
		$prose = (string) preg_replace( '/^(`{3,}|~{3,}).*?^\1\s*$/ms', '', $body );
		$text  = (string) preg_replace( '/!\[[^\]]*\]\([^)]*\)|\[([^\]]*)\]\([^)]*\)/u', '$1', $prose );
		$text  = (string) preg_replace( '/[#>*_`|~\-]+/u', ' ', $text );
		$words = count( preg_split( '/\s+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY ) );

		$is_product = ( 'product' === $post->post_type );
		$min_words  = $is_product ? 80 : 300;
		$checks     = array();

		// Summary.
		$checks['description'] = array(
			'ok'    => '' !== RAWI_Frontmatter::explicit_description( $post ),
			'value' => null,
		);

		// Substance.
		$checks['length'] = array(
			'ok'    => $words >= $min_words,
			'value' => $words,
		);

		// Headings: the renderer adds one H1; count what is below it.
		preg_match_all( '/^(#{2,6})\s+\S/m', $prose, $heads );
		$levels  = array_map( 'strlen', $heads[1] );
		$skipped = false;
		$prev    = 1;

		foreach ( $levels as $level ) {
			if ( $level > $prev + 1 ) {
				$skipped = true;
				break;
			}
			$prev = $level;
		}

		$checks['headings'] = array(
			'ok'    => ! $skipped && ( $words < 600 || count( $levels ) >= 2 ),
			'value' => count( $levels ),
		);

		// Images.
		preg_match_all( '/!\[([^\]]*)\]\(/u', $body, $images );
		$total_images = count( $images[1] );
		$missing_alt  = 0;

		foreach ( $images[1] as $alt ) {
			if ( '' === trim( $alt ) ) {
				$missing_alt++;
			}
		}

		if ( $total_images > 0 ) {
			$checks['alt_text'] = array(
				'ok'    => 0 === $missing_alt,
				'value' => $missing_alt,
			);
		}

		// Structure on long pages.
		if ( $words >= 500 ) {
			$has_list  = (bool) preg_match( '/^\s{0,3}(?:[-*+]|\d+[.)])\s+\S/m', $prose );
			$has_table = (bool) preg_match( '/^\|.+\|\s*$/m', $prose );

			$checks['structure'] = array(
				'ok'    => $has_list || $has_table,
				'value' => null,
			);
		}

		// Internal links.
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );

		if ( ! $is_product ) {
			$internal = 0;

			if ( '' !== $host && preg_match_all( '/(?<!!)\[[^\]]+\]\((https?:\/\/[^)\s]+)/u', $prose, $links ) ) {
				foreach ( $links[1] as $url ) {
					$link_host = (string) wp_parse_url( $url, PHP_URL_HOST );

					if ( preg_replace( '/^www\./', '', $link_host ) === preg_replace( '/^www\./', '', $host ) ) {
						$internal++;
					}
				}
			}

			$checks['links'] = array(
				'ok'    => $internal > 0,
				'value' => $internal,
			);
		}

		// Freshness, for dated content only: an "About" page is evergreen.
		if ( ! is_post_type_hierarchical( $post->post_type ) ) {
			$modified = strtotime( $post->post_modified_gmt . ' UTC' );
			$age_days = $modified ? (int) floor( ( time() - $modified ) / DAY_IN_SECONDS ) : 0;

			$checks['fresh'] = array(
				'ok'    => $age_days <= 365,
				'value' => $age_days,
			);
		}

		// Weight against the HTML page, once it has been measured.
		$md_tokens   = RAWI_Converter::estimate_tokens( $markdown );
		$html_tokens = RAWI_Renderer::html_tokens( $post );

		if ( $html_tokens > 0 ) {
			$checks['weight'] = array(
				'ok'    => $md_tokens <= $html_tokens * 0.5,
				'value' => (int) round( ( 1 - $md_tokens / $html_tokens ) * 100 ),
			);
		}

		$checks['size'] = array(
			'ok'    => $md_tokens <= 25000,
			'value' => $md_tokens,
		);

		/**
		 * Filter the readiness checks for a post.
		 *
		 * @param array   $checks   key => array( ok, value ).
		 * @param WP_Post $post     The post.
		 * @param string  $markdown The served document.
		 */
		$checks = (array) apply_filters( 'rawi_readiness_checks', $checks, $post, $markdown );

		$weights  = self::weights();
		$possible = 0;
		$earned   = 0;

		foreach ( $checks as $key => $check ) {
			$weight    = isset( $weights[ $key ] ) ? $weights[ $key ] : 10;
			$possible += $weight;
			$earned   += ! empty( $check['ok'] ) ? $weight : 0;
		}

		return array(
			'score'  => $possible > 0 ? (int) round( $earned / $possible * 100 ) : 0,
			'checks' => $checks,
		);
	}

	/**
	 * Analyse and store the result for a post.
	 *
	 * @param WP_Post $post     Post.
	 * @param string  $markdown Served document.
	 * @return array
	 */
	public static function update( WP_Post $post, $markdown ) {
		$result = self::analyze( $post, $markdown );

		update_post_meta( $post->ID, self::META_SCORE, $result['score'] );
		update_post_meta(
			$post->ID,
			self::META_DATA,
			array(
				'score'    => $result['score'],
				'checks'   => $result['checks'],
				'modified' => $post->post_modified_gmt,
				'at'       => time(),
			)
		);

		return $result;
	}

	/**
	 * Refresh the stored score when it is missing, older than the post, or
	 * more than a week old (freshness changes with time alone).
	 *
	 * @param WP_Post $post     Post.
	 * @param string  $markdown Served document.
	 * @return void
	 */
	public static function maybe_update( WP_Post $post, $markdown ) {
		$data = self::get( $post->ID );

		$stale = ! $data
			|| ! isset( $data['modified'], $data['at'] )
			|| $data['modified'] !== $post->post_modified_gmt
			|| ( time() - (int) $data['at'] ) > WEEK_IN_SECONDS;

		if ( $stale && '' !== trim( (string) $markdown ) ) {
			self::update( $post, $markdown );
		}
	}

	/**
	 * Stored result for a post, or null.
	 *
	 * @param int $post_id Post ID.
	 * @return array|null
	 */
	public static function get( $post_id ) {
		$data = get_post_meta( $post_id, self::META_DATA, true );

		return is_array( $data ) && isset( $data['score'] ) ? $data : null;
	}

	/**
	 * Failed check keys for a stored result, heaviest first.
	 *
	 * @param array $data Stored result.
	 * @return string[]
	 */
	public static function issues( array $data ) {
		$weights = self::weights();
		$issues  = array();

		foreach ( (array) $data['checks'] as $key => $check ) {
			if ( empty( $check['ok'] ) ) {
				$issues[ $key ] = isset( $weights[ $key ] ) ? $weights[ $key ] : 10;
			}
		}

		arsort( $issues );

		return array_keys( $issues );
	}

	/**
	 * Site-wide summary for the dashboard.
	 *
	 * @return array
	 */
	public static function summary() {
		global $wpdb;

		$types = RAWI_Settings::enabled_post_types();
		$empty = array(
			'scored'  => 0,
			'average' => null,
			'buckets' => array(
				'good' => 0,
				'fair' => 0,
				'poor' => 0,
			),
			'worst'   => array(),
			'common'  => array(),
		);

		if ( empty( $types ) ) {
			return $empty;
		}

		$in = implode( ', ', array_fill( 0, count( $types ), '%s' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, CAST(pm.meta_value AS UNSIGNED) AS score
				 FROM %i pm INNER JOIN %i p ON p.ID = pm.post_id
				 WHERE pm.meta_key = %s AND p.post_status = 'publish' AND p.post_type IN ($in)
				 ORDER BY score ASC, p.post_modified DESC
				 LIMIT 5000",
				array_merge( array( $wpdb->postmeta, $wpdb->posts, self::META_SCORE ), $types )
			),
			ARRAY_A
		);
		// phpcs:enable

		$rows = is_array( $rows ) ? $rows : array();

		if ( empty( $rows ) ) {
			return $empty;
		}

		$buckets = $empty['buckets'];
		$total   = 0;
		$common  = array();

		foreach ( $rows as $row ) {
			$score  = (int) $row['score'];
			$total += $score;

			if ( $score >= 80 ) {
				$buckets['good']++;
			} elseif ( $score >= 50 ) {
				$buckets['fair']++;
			} else {
				$buckets['poor']++;
			}
		}

		// Issue counts across the site, from the stored detail of each page.
		$ids = array_map( 'intval', wp_list_pluck( array_slice( $rows, 0, 2000 ), 'post_id' ) );

		update_meta_cache( 'post', $ids );

		foreach ( $ids as $id ) {
			$data = self::get( $id );

			if ( ! $data ) {
				continue;
			}

			foreach ( self::issues( $data ) as $key ) {
				$common[ $key ] = ( isset( $common[ $key ] ) ? $common[ $key ] : 0 ) + 1;
			}
		}

		arsort( $common );

		$worst = array();

		foreach ( array_slice( $rows, 0, 10 ) as $row ) {
			$post = get_post( (int) $row['post_id'] );
			$data = self::get( (int) $row['post_id'] );

			if ( ! $post || ! $data ) {
				continue;
			}

			$worst[] = array(
				'id'       => (int) $post->ID,
				'title'    => html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ),
				'score'    => (int) $data['score'],
				'issues'   => array_slice( self::issues( $data ), 0, 3 ),
				'url'      => (string) get_permalink( $post ),
				'edit_url' => (string) get_edit_post_link( $post, 'raw' ),
			);
		}

		$common_rows = array();

		foreach ( $common as $key => $count ) {
			$common_rows[] = array(
				'key'   => (string) $key,
				'count' => (int) $count,
			);
		}

		return array(
			'scored'  => count( $rows ),
			'average' => (int) round( $total / count( $rows ) ),
			'buckets' => $buckets,
			'worst'   => $worst,
			'common'  => $common_rows,
		);
	}
}
