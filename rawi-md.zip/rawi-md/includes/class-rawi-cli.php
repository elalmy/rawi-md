<?php
/**
 * WP-CLI commands.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Manage Rawi MD from the command line.
 */
class RAWI_CLI {

	/**
	 * Register the command.
	 *
	 * @return void
	 */
	public static function register() {
		WP_CLI::add_command( 'rawi', __CLASS__ );
	}

	/**
	 * Pre-generate the Markdown cache for every eligible post.
	 *
	 * ## OPTIONS
	 *
	 * [--post_type=<type>]
	 * : Only this post type.
	 *
	 * [--force]
	 * : Regenerate documents that are already cached.
	 *
	 * ## EXAMPLES
	 *
	 *     wp rawi warm
	 *     wp rawi warm --post_type=product --force
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function warm( $args, $assoc_args ) {
		$types = isset( $assoc_args['post_type'] ) ? array( sanitize_key( $assoc_args['post_type'] ) ) : RAWI_Settings::enabled_post_types();
		$force = ! empty( $assoc_args['force'] );

		$ids = get_posts(
			array(
				'post_type'   => $types,
				'post_status' => 'publish',
				'numberposts' => -1,
				'fields'      => 'ids',
			)
		);

		$progress = \WP_CLI\Utils\make_progress_bar( 'Generating Markdown', count( $ids ) );
		$made     = 0;

		foreach ( $ids as $id ) {
			$result = RAWI_Tools::warm_one( (int) $id, $force );

			if ( 'generated' === $result ) {
				$made++;
			}

			$progress->tick();
		}

		$progress->finish();

		WP_CLI::success( sprintf( '%d documents generated, %d posts checked.', $made, count( $ids ) ) );
	}

	/**
	 * Delete every cached Markdown document.
	 *
	 * @return void
	 */
	public function flush() {
		WP_CLI::success( sprintf( '%d cached documents removed.', RAWI_Cache::flush() ) );
	}

	/**
	 * Print the Markdown document for a post.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Post ID.
	 *
	 * @param array $args Positional arguments.
	 * @return void
	 */
	public function render( $args ) {
		$post = get_post( (int) $args[0] );

		if ( ! $post instanceof WP_Post ) {
			WP_CLI::error( 'No such post.' );
		}

		$reason = RAWI_Eligibility::reason( $post );

		if ( '' !== $reason ) {
			WP_CLI::warning( 'Not served to agents: ' . RAWI_Eligibility::reason_label( $reason ) );
		}

		WP_CLI::line( RAWI_Renderer::render( $post ) );
	}

	/**
	 * Show request statistics.
	 *
	 * ## OPTIONS
	 *
	 * [--days=<days>]
	 * : Window: 1, 7, 30, 90 or 365.
	 * ---
	 * default: 30
	 * ---
	 *
	 * [--format=<format>]
	 * : table, json, csv or yaml.
	 * ---
	 * default: table
	 * ---
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function stats( $args, $assoc_args ) {
		$days = RAWI_Stats::normalise_range( isset( $assoc_args['days'] ) ? $assoc_args['days'] : 30 );
		$from = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$to   = gmdate( 'Y-m-d H:i:s', time() + MINUTE_IN_SECONDS );
		$kpis = RAWI_Stats::kpis( $from, $to );

		WP_CLI::log( sprintf( 'Last %d days: %d requests, %d agents, %d pages, %d tokens served, %d saved.', $days, $kpis['requests'], $kpis['agents'], $kpis['pages'], $kpis['md_tokens'], $kpis['tokens_saved'] ) );

		$rows = array();

		foreach ( RAWI_Stats::agents( $from, $to, 30 ) as $agent ) {
			$rows[] = array(
				'agent'    => $agent['label'],
				'operator' => $agent['operator'],
				'kind'     => $agent['kind'],
				'requests' => $agent['hits'],
				'pages'    => $agent['pages'],
				'verified' => $agent['verified'],
				'spoofed'  => $agent['spoofed'],
			);
		}

		\WP_CLI\Utils\format_items(
			isset( $assoc_args['format'] ) ? $assoc_args['format'] : 'table',
			$rows,
			array( 'agent', 'operator', 'kind', 'requests', 'pages', 'verified', 'spoofed' )
		);
	}

	/**
	 * Request a URL the way an agent would and report what came back.
	 *
	 * ## OPTIONS
	 *
	 * [<url>]
	 * : Address to test. Defaults to the most recent eligible post.
	 *
	 * @param array $args Positional arguments.
	 * @return void
	 */
	public function test( $args ) {
		$result = RAWI_Tools::self_test( isset( $args[0] ) ? esc_url_raw( $args[0] ) : '' );

		foreach ( $result['checks'] as $check ) {
			$line = sprintf( '%s — %s', $check['label'], $check['detail'] );

			if ( 'pass' === $check['state'] ) {
				WP_CLI::log( WP_CLI::colorize( '%G✔%n ' ) . $line );
			} elseif ( 'warn' === $check['state'] ) {
				WP_CLI::log( WP_CLI::colorize( '%Y!%n ' ) . $line );
			} else {
				WP_CLI::log( WP_CLI::colorize( '%R✘%n ' ) . $line );
			}
		}
	}

	/**
	 * Download the published crawler IP lists now.
	 *
	 * @subcommand refresh-ip-lists
	 * @return void
	 */
	public function refresh_ip_lists() {
		foreach ( RAWI_Verify::refresh_lists() as $label => $count ) {
			WP_CLI::log( sprintf( '%s: %d ranges', $label, $count ) );
		}

		WP_CLI::success( 'IP lists updated.' );
	}
}
