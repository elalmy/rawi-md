<?php
/**
 * Detects Markdown requests and serves the response.
 *
 * Three routes, deliberately given different caching policies:
 *
 *   accept  the canonical URL negotiated with Accept: text/markdown.
 *           Sent as private. If any intermediary ignored Vary: Accept it
 *           could otherwise serve Markdown to a human on the real page URL.
 *
 *   suffix  /some-post.md — a distinct URL, so it is safe to cache hard and
 *           safe to mark noindex.
 *
 *   query   ?format=md and ?output_format=md, same treatment as the suffix.
 *
 * Every route answers conditional requests (ETag / Last-Modified) with a 304,
 * so a crawler that checks back often costs almost nothing.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Router
 */
class RAWI_Router {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ), 0 );
	}

	/**
	 * Register the rewrite query vars.
	 *
	 * @param string[] $vars Existing query vars.
	 * @return string[]
	 */
	public static function query_vars( $vars ) {
		$vars[] = 'rawi_md';
		$vars[] = 'rawi_path';
		$vars[] = 'rawi_llms';

		return $vars;
	}

	/**
	 * Request method, uppercased.
	 *
	 * @return string
	 */
	private static function method() {
		return isset( $_SERVER['REQUEST_METHOD'] )
			? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) )
			: 'GET';
	}

	/**
	 * Decide whether to serve Markdown, and do it.
	 *
	 * @return void
	 */
	public static function maybe_serve() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		if ( is_feed() || is_robots() || is_trackback() ) {
			return;
		}

		if ( RAWI_Renderer::is_loopback_render() ) {
			return;
		}

		$method = self::method();

		if ( 'GET' !== $method && 'HEAD' !== $method ) {
			return;
		}

		$route = null;
		$post  = null;

		// The rewrite rule stays registered so switching the route on needs
		// no flush; while it is off the address simply does not exist.
		if ( get_query_var( 'rawi_md' ) && ! RAWI_Settings::get( 'enable_md_suffix' ) ) {
			self::not_found();
			return;
		}

		// Route 1: the .md suffix.
		if ( RAWI_Settings::get( 'enable_md_suffix' ) && get_query_var( 'rawi_md' ) ) {
			$route = 'suffix';
			$path  = trim( (string) get_query_var( 'rawi_path' ), '/' );
			$post  = self::resolve_path( $path );

			if ( ! $post ) {
				self::send_404( $route );
				return;
			}

			// One document, one address: a slug-only match reached through a
			// wrong path is redirected to the post's real .md URL.
			$expected = self::markdown_path( $post );

			if ( '' !== $expected && $expected !== $path && RAWI_Eligibility::is_eligible( $post ) ) {
				wp_safe_redirect( self::markdown_url( $post ), 301, 'Rawi MD' );
				exit;
			}
		}

		// Route 2: the query string.
		if ( ! $route && RAWI_Settings::get( 'enable_query_string' ) && is_singular() && self::query_asks_for_markdown() ) {
			$route = 'query';
			$post  = get_queried_object();
		}

		// Route 3: content negotiation on the canonical URL.
		if ( ! $route && RAWI_Settings::get( 'enable_accept_header' ) && is_singular() && RAWI_Accept::prefers_markdown() ) {
			$route = 'accept';
			$post  = get_queried_object();
		}

		if ( ! $route || ! $post instanceof WP_Post ) {
			return;
		}

		if ( ! RAWI_Eligibility::is_eligible( $post ) ) {
			// On the negotiated canonical URL, fall through to the normal HTML
			// page rather than 404 — the resource exists, we just will not
			// serve this representation of it.
			if ( 'accept' === $route ) {
				return;
			}

			self::send_404( $route );
			return;
		}

		self::serve( $post, $route );
	}

	/**
	 * Does the query string ask for Markdown?
	 *
	 * @return bool
	 */
	public static function query_asks_for_markdown() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		foreach ( array( 'format', 'output_format' ) as $param ) {
			if ( isset( $_GET[ $param ] ) && 'md' === strtolower( sanitize_text_field( wp_unslash( $_GET[ $param ] ) ) ) ) {
				return true;
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		return false;
	}

	/**
	 * Turn the captured .md path into a post.
	 *
	 * @param string $path Relative path without the .md suffix.
	 * @return WP_Post|null
	 */
	private static function resolve_path( $path ) {
		$path = trim( (string) $path, '/' );

		if ( '' === $path ) {
			return null;
		}

		$candidates = array(
			home_url( '/' . $path . '/' ),
			home_url( '/' . $path ),
		);

		foreach ( $candidates as $url ) {
			$post_id = url_to_postid( $url );

			if ( $post_id ) {
				$post = get_post( $post_id );

				if ( $post instanceof WP_Post ) {
					return $post;
				}
			}
		}

		$types = RAWI_Settings::enabled_post_types();

		if ( empty( $types ) ) {
			return null;
		}

		// Hierarchical types (pages, docs): the full path decides, so
		// /about/team.md and /careers/team.md never resolve to each other.
		$hierarchical = array_values( array_filter( $types, 'is_post_type_hierarchical' ) );

		if ( ! empty( $hierarchical ) ) {
			$page = get_page_by_path( $path, OBJECT, $hierarchical );

			if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
				return $page;
			}
		}

		// Last resort: a slug match on a flat type whose permalinks
		// url_to_postid() does not understand. The caller redirects to the
		// real address when the path differs.
		$slug = basename( $path );
		$flat = array_values( array_diff( $types, $hierarchical ) );

		if ( empty( $flat ) || '' === $slug ) {
			return null;
		}

		$found = get_posts(
			array(
				'name'                   => sanitize_title( $slug ),
				'post_type'              => $flat,
				'post_status'            => 'publish',
				'numberposts'            => 2,
				'suppress_filters'       => false,
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		// Two posts share the slug across types: refuse to guess.
		if ( 1 === count( $found ) && $found[0] instanceof WP_Post ) {
			return $found[0];
		}

		return null;
	}

	/**
	 * Render, cache and send the Markdown response.
	 *
	 * @param WP_Post $post  Post to serve.
	 * @param string  $route accept | suffix | query.
	 * @return void
	 */
	private static function serve( WP_Post $post, $route ) {
		if ( ! RAWI_Converter::is_available() ) {
			return;
		}

		RAWI_Cache_Compat::disable_page_cache();

		$document  = RAWI_Cache::get( $post->ID );
		$cache_hit = ( false !== $document );
		$gen_ms    = 0;

		if ( ! $cache_hit ) {
			$result   = RAWI_Renderer::render_with_metrics( $post );
			$document = $result['document'];
			$gen_ms   = $result['gen_ms'];

			if ( ! self::has_body( $document ) ) {
				// Conversion produced nothing usable. Serving an empty page is
				// worse than serving none, and caching it would make it stick.
				if ( 'accept' === $route ) {
					return;
				}

				self::send_404( $route );
				return;
			}

			RAWI_Cache::set( $post->ID, $document );
		}

		$tokens        = RAWI_Converter::estimate_tokens( $document );
		$canonical     = get_permalink( $post );
		$etag = '"rawi-' . substr( md5( $document ), 0, 20 ) . '"';

		// The document can change without the post changing (a settings
		// change, a plugin update), so the newer of the two times is used.
		$modified_ts   = max( (int) strtotime( $post->post_modified_gmt . ' UTC' ), $cache_hit ? RAWI_Cache::mtime( $post->ID ) : time() );
		$last_modified = gmdate( 'D, d M Y H:i:s', $modified_ts ) . ' GMT';
		$not_modified  = self::is_not_modified( $etag, $modified_ts );
		$method        = self::method();

		// Discard anything a theme or plugin already buffered.
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		if ( ! headers_sent() ) {
			// nocache_headers() ran when the page cache was disabled; its
			// Expires and Pragma would contradict the policy set below.
			header_remove( 'Expires' );
			header_remove( 'Pragma' );
			header_remove( 'Cache-Control' );
			header_remove( 'Last-Modified' );

			status_header( $not_modified ? 304 : 200 );

			header( 'Content-Type: text/markdown; charset=' . get_option( 'blog_charset', 'UTF-8' ) );
			header( 'Vary: Accept' );
			header( 'ETag: ' . $etag );
			header( 'Last-Modified: ' . $last_modified );
			header( 'X-Markdown-Tokens: ' . $tokens );
			header( 'X-Markdown-Generator: rawi-md/' . RAWI_VERSION );
			header( 'X-Rawi-Cache: ' . ( $cache_hit ? 'HIT' : 'MISS' ) );

			if ( $canonical ) {
				header( 'Link: <' . esc_url_raw( $canonical ) . '>; rel="canonical"' );
			}

			$signal = trim( (string) RAWI_Settings::get( 'content_signal' ) );

			if ( '' !== $signal ) {
				header( 'Content-Signal: ' . $signal );
			}

			if ( 'accept' === $route ) {
				// Shared caches must not store this against the HTML URL, but
				// the client itself may keep it and revalidate with the ETag.
				header( 'Cache-Control: private, no-cache' );
			} else {
				// A distinct URL: safe to cache, and it must not be indexed.
				header( 'Cache-Control: public, max-age=3600' );

				if ( RAWI_Settings::get( 'noindex_alt_urls' ) ) {
					header( 'X-Robots-Tag: noindex, follow' );
				}
			}

			// Only safe when PHP is not compressing the body after us, since
			// zlib rewrites the body but not a header we already set.
			if ( ! $not_modified && ! ini_get( 'zlib.output_compression' ) ) {
				header( 'Content-Length: ' . strlen( $document ) );
			}
		}

		if ( 'HEAD' !== $method && ! $not_modified ) {
			// Raw Markdown by design; escaping would corrupt the payload.
			echo $document; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		// Logging and bot verification happen after the agent has its answer.
		self::finish_response();

		// Keep the readiness score in step with what agents actually get.
		RAWI_Readiness::maybe_update( $post, $document );

		if ( 'HEAD' !== $method ) {
			RAWI_Logger::record(
				$post->ID,
				$route,
				array(
					'tokens'      => $not_modified ? 0 : $tokens,
					'html_tokens' => $not_modified ? 0 : RAWI_Renderer::html_tokens( $post ),
					'cache_hit'   => $cache_hit,
					'gen_ms'      => $gen_ms,
					'status'      => $not_modified ? 304 : 200,
				)
			);
		}

		exit;
	}

	/**
	 * Does the client already hold this exact document?
	 *
	 * @param string $etag     Current ETag.
	 * @param int    $modified Unix time the document last changed.
	 * @return bool
	 */
	private static function is_not_modified( $etag, $modified ) {
		$if_none_match = isset( $_SERVER['HTTP_IF_NONE_MATCH'] )
			? trim( sanitize_text_field( wp_unslash( $_SERVER['HTTP_IF_NONE_MATCH'] ) ) )
			: '';

		// If-None-Match wins over If-Modified-Since when both are present.
		if ( '' !== $if_none_match ) {
			if ( '*' === $if_none_match ) {
				return true;
			}

			foreach ( explode( ',', $if_none_match ) as $candidate ) {
				$candidate = trim( preg_replace( '/^W\//', '', trim( $candidate ) ) );

				if ( $candidate === $etag ) {
					return true;
				}
			}

			return false;
		}

		$since = isset( $_SERVER['HTTP_IF_MODIFIED_SINCE'] )
			? strtotime( sanitize_text_field( wp_unslash( $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) ) )
			: false;

		if ( ! $since ) {
			return false;
		}

		return $modified > 0 && $modified <= $since;
	}

	/**
	 * Hand the response to the client before doing bookkeeping.
	 *
	 * @return void
	 */
	public static function finish_response() {
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
			RAWI_Verify::$response_sent = true;
			return;
		}

		if ( function_exists( 'litespeed_finish_request' ) ) {
			litespeed_finish_request();
			RAWI_Verify::$response_sent = true;
			return;
		}

		flush();
	}

	/**
	 * Does the document contain anything beyond frontmatter and a title?
	 *
	 * @param string $document Rendered Markdown.
	 * @return bool
	 */
	private static function has_body( $document ) {
		$document = str_replace( "\r\n", "\n", (string) $document );

		// Drop a leading frontmatter block.
		$body = preg_replace( '/\A---\n.*?\n---\n/s', '', $document );
		$body = null === $body ? $document : $body;

		// Drop the H1 the renderer adds.
		$body = preg_replace( '/\A\s*#\s[^\n]*\n/', '', $body );

		return '' !== trim( (string) $body );
	}

	/**
	 * Send a plain 404 for an unresolvable Markdown URL, and log it so the
	 * dashboard can show which links agents are failing on.
	 *
	 * @param string $route Route that was asked for.
	 * @return void
	 */
	private static function send_404( $route = 'suffix' ) {
		if ( ! headers_sent() ) {
			status_header( 404 );
			header( 'Content-Type: text/plain; charset=UTF-8' );
			header( 'X-Robots-Tag: noindex, nofollow' );
			nocache_headers();
		}

		if ( 'HEAD' !== self::method() ) {
			echo "404 Not Found\n";
		}

		self::finish_response();

		if ( 'HEAD' !== self::method() ) {
			RAWI_Logger::record( 0, $route, array( 'status' => 404 ) );
		}

		exit;
	}

	/**
	 * Hand an address the plugin owns but does not serve to WordPress's 404.
	 *
	 * @return void
	 */
	public static function not_found() {
		global $wp_query;

		if ( $wp_query instanceof WP_Query ) {
			$wp_query->set_404();
		}

		status_header( 404 );
		nocache_headers();
	}

	/**
	 * Path part of a post's .md address, without slashes or suffix.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	private static function markdown_path( WP_Post $post ) {
		$permalink = get_permalink( $post );

		if ( ! $permalink ) {
			return '';
		}

		$path = (string) wp_parse_url( $permalink, PHP_URL_PATH );
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );

		// Sites installed in a subdirectory: the rewrite captures the part
		// after the home path.
		if ( '' !== $home && '/' !== $home && 0 === strpos( $path, $home ) ) {
			$path = substr( $path, strlen( $home ) );
		}

		return trim( rawurldecode( $path ), '/' );
	}

	/**
	 * Markdown URL for a post using the .md suffix.
	 *
	 * @param WP_Post|int $post Post.
	 * @return string
	 */
	public static function markdown_url( $post ) {
		$post = get_post( $post );

		if ( ! $post instanceof WP_Post ) {
			return '';
		}

		$permalink = get_permalink( $post );

		if ( ! $permalink ) {
			return '';
		}

		// The front page has no path to put a suffix on.
		$is_front = ( 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_on_front' ) === (int) $post->ID );

		if ( ! $is_front && RAWI_Settings::get( 'enable_md_suffix' ) && get_option( 'permalink_structure' ) && false === strpos( $permalink, '?' ) ) {
			return untrailingslashit( $permalink ) . '.md';
		}

		return add_query_arg( 'format', 'md', $permalink );
	}
}
