<?php
/**
 * Keeps page caches out of the way of Markdown requests.
 *
 * Two layers are needed and they solve different halves of the problem:
 *
 * 1. Runtime hooks tell LiteSpeed, WP Rocket and friends not to store the
 *    response WordPress is about to send.
 * 2. Server-level rules stop the cache serving a stored HTML copy *before*
 *    WordPress runs at all. Nothing in PHP can fix that case, which is why the
 *    admin screen generates the rules for the site owner to paste.
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class RAWI_Cache_Compat
 */
class RAWI_Cache_Compat {

	/**
	 * Hook early enough that cache plugins have not committed yet.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'maybe_bypass' ), 0 );
	}

	/**
	 * If this request looks like an agent asking for Markdown, disable caching.
	 *
	 * Deliberately broad: it is far cheaper to skip the cache on a handful of
	 * extra requests than to let a cache store Markdown against an HTML URL.
	 *
	 * @return void
	 */
	public static function maybe_bypass() {
		if ( is_admin() || wp_doing_cron() ) {
			return;
		}

		if ( ! self::request_looks_like_markdown() ) {
			return;
		}

		self::disable_page_cache();
	}

	/**
	 * Does the current request ask for Markdown by any of the three routes?
	 *
	 * @return bool
	 */
	public static function request_looks_like_markdown() {
		if ( RAWI_Settings::get( 'enable_accept_header' ) && RAWI_Accept::prefers_markdown() ) {
			return true;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( RAWI_Settings::get( 'enable_query_string' ) && RAWI_Router::query_asks_for_markdown() ) {
			return true;
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( RAWI_Settings::get( 'enable_md_suffix' ) ) {
			$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			$uri = (string) wp_parse_url( $uri, PHP_URL_PATH );

			if ( '' !== $uri && preg_match( '#(\.md/?|/llms\.txt)$#i', $uri ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Tell every known page cache to leave this response alone.
	 *
	 * @return void
	 */
	public static function disable_page_cache() {
		// Understood by W3 Total Cache, WP Super Cache, WP Rocket, LiteSpeed,
		// Comet Cache, Cache Enabler and most managed-host drop-ins.
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}

		if ( ! defined( 'DONOTMINIFY' ) ) {
			define( 'DONOTMINIFY', true );
		}

		// LiteSpeed Cache public API.
		do_action( 'litespeed_control_set_nocache', 'Rawi MD: content negotiation' );

		// WP Rocket.
		add_filter( 'do_rocket_generate_caching_files', '__return_false', 99 );
		add_filter( 'rocket_buffer', array( __CLASS__, 'passthrough_buffer' ), 1 );

		// Autoptimize and similar output buffers.
		add_filter( 'autoptimize_filter_noptimize', '__return_true', 99 );

		nocache_headers();
	}

	/**
	 * Return WP Rocket's buffer untouched.
	 *
	 * @param string $buffer Output buffer.
	 * @return string
	 */
	public static function passthrough_buffer( $buffer ) {
		return $buffer;
	}

	/**
	 * Apache / LiteSpeed .htaccess rules.
	 *
	 * @return string
	 */
	public static function htaccess_rules() {
		return "# BEGIN Rawi MD\n"
			. "<IfModule LiteSpeed>\n"
			. "RewriteEngine On\n"
			. "RewriteCond %{HTTP:Accept} text/markdown [NC]\n"
			. "RewriteRule .* - [E=Cache-Control:no-cache]\n"
			. "RewriteCond %{QUERY_STRING} (^|&)(output_)?format=md(&|$) [NC]\n"
			. "RewriteRule .* - [E=Cache-Control:no-cache]\n"
			. "</IfModule>\n"
			. "# END Rawi MD\n";
	}

	/**
	 * Nginx fastcgi_cache rules.
	 *
	 * @return string
	 */
	public static function nginx_rules() {
		return "# Inside your server { } block, before the PHP location block:\n"
			. "if (\$http_accept ~* \"text/markdown\") {\n"
			. "    set \$skip_cache 1;\n"
			. "}\n"
			. "if (\$arg_format = \"md\") {\n"
			. "    set \$skip_cache 1;\n"
			. "}\n"
			. "if (\$arg_output_format = \"md\") {\n"
			. "    set \$skip_cache 1;\n"
			. "}\n"
			. "# Then make sure your cache block uses it:\n"
			. "# fastcgi_cache_bypass \$skip_cache;\n"
			. "# fastcgi_no_cache \$skip_cache;\n";
	}

	/**
	 * Cloudflare cache rule description.
	 *
	 * @return string
	 */
	public static function cloudflare_rules() {
		return "Cloudflare dashboard: Caching > Cache Rules > Create rule\n"
			. "  If:   http.request.headers[\"accept\"][0] contains \"text/markdown\"\n"
			. "  Then: Bypass cache\n"
			. "\n"
			. "If your zone is on a Pro plan or above, also check\n"
			. "AI Crawl Control > Markdown for Agents. Running both this plugin and\n"
			. "Cloudflare's edge conversion on the same zone means two conversions of\n"
			. "the same page; pick one.\n";
	}

	/**
	 * Is this address one of Cloudflare's edge servers?
	 *
	 * Only then can CF-Connecting-IP be believed; from anywhere else the
	 * header is just text a client chose to send.
	 *
	 * @param string $ip Address.
	 * @return bool
	 */
	public static function is_cloudflare_ip( $ip ) {
		if ( '' === (string) $ip ) {
			return false;
		}

		// Published at https://www.cloudflare.com/ips/ — stable for years.
		$ranges = (array) apply_filters(
			'rawi_cloudflare_ranges',
			array(
				'173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
				'141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
				'197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
				'104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
				'2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32',
				'2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
			)
		);

		foreach ( $ranges as $range ) {
			if ( RAWI_Verify::ip_in_cidr( $ip, (string) $range ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Detect active caching layers so the admin screen can point at the right rules.
	 *
	 * @return string[] Human-readable names.
	 */
	public static function detected_caches() {
		$found = array();

		if ( defined( 'LSCWP_V' ) || rawi_is_plugin_active( 'litespeed-cache/litespeed-cache.php' ) ) {
			$found[] = 'LiteSpeed Cache';
		}

		if ( defined( 'WP_ROCKET_VERSION' ) ) {
			$found[] = 'WP Rocket';
		}

		if ( defined( 'W3TC' ) ) {
			$found[] = 'W3 Total Cache';
		}

		if ( function_exists( 'wp_cache_is_enabled' ) ) {
			$found[] = 'WP Super Cache';
		}

		if ( isset( $_SERVER['HTTP_CF_RAY'] ) ) {
			$found[] = 'Cloudflare';
		}

		return $found;
	}
}

if ( ! function_exists( 'rawi_is_plugin_active' ) ) {
	/**
	 * Front-end safe replacement for is_plugin_active().
	 *
	 * @param string $basename Plugin basename.
	 * @return bool
	 */
	function rawi_is_plugin_active( $basename ) {
		$active = get_option( 'active_plugins', array() );

		return is_array( $active ) && in_array( $basename, $active, true );
	}
}
