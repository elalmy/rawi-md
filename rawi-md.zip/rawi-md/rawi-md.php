<?php
/**
 * Plugin Name:       Rawi MD — Markdown for AI Crawlers
 * Plugin URI:        https://ahmed-abdelhamed.com/rawi-md
 * Description:       Serves a clean Markdown representation of your posts, pages and products to the AI crawlers that ask for it — through Accept: text/markdown, a .md URL suffix, or a query string — plus an llms.txt index and a full analytics dashboard. Built to keep working behind LiteSpeed Cache and WP Rocket.
 * Version:           1.3.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Ahmed Abdelhamed
 * Author URI:        https://ahmed-abdelhamed.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       rawi-md
 * Domain Path:       /languages
 *
 * @package RawiMD
 */

defined( 'ABSPATH' ) || exit;

define( 'RAWI_VERSION', '1.3.0' );
define( 'RAWI_FILE', __FILE__ );
define( 'RAWI_DIR', plugin_dir_path( __FILE__ ) );
define( 'RAWI_URL', plugin_dir_url( __FILE__ ) );
define( 'RAWI_DB_VERSION', '3' );

require_once RAWI_DIR . 'includes/class-rawi-settings.php';
require_once RAWI_DIR . 'includes/class-rawi-upgrade.php';
require_once RAWI_DIR . 'includes/class-rawi-accept.php';
require_once RAWI_DIR . 'includes/class-rawi-eligibility.php';
require_once RAWI_DIR . 'includes/class-rawi-converter.php';
require_once RAWI_DIR . 'includes/class-rawi-frontmatter.php';
require_once RAWI_DIR . 'includes/class-rawi-renderer.php';
require_once RAWI_DIR . 'includes/class-rawi-cache.php';
require_once RAWI_DIR . 'includes/class-rawi-cache-compat.php';
require_once RAWI_DIR . 'includes/class-rawi-agents.php';
require_once RAWI_DIR . 'includes/class-rawi-verify.php';
require_once RAWI_DIR . 'includes/class-rawi-logger.php';
require_once RAWI_DIR . 'includes/class-rawi-stats.php';
require_once RAWI_DIR . 'includes/class-rawi-referrals.php';
require_once RAWI_DIR . 'includes/class-rawi-readiness.php';
require_once RAWI_DIR . 'includes/class-rawi-discovery.php';
require_once RAWI_DIR . 'includes/class-rawi-llms.php';
require_once RAWI_DIR . 'includes/class-rawi-router.php';
require_once RAWI_DIR . 'includes/class-rawi-tools.php';

if ( is_admin() ) {
	require_once RAWI_DIR . 'includes/class-rawi-admin.php';
	require_once RAWI_DIR . 'includes/class-rawi-metabox.php';
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once RAWI_DIR . 'includes/class-rawi-cli.php';
}

/**
 * Boot the plugin.
 *
 * @return void
 */
function rawi_boot() {
	// Runs on every load but costs two cached option reads. Activation hooks
	// do not fire on updates, so this is what carries an existing install
	// forward without losing its settings or its request log.
	RAWI_Upgrade::maybe_upgrade();

	RAWI_Router::init();
	RAWI_Discovery::init();
	RAWI_Llms::init();
	RAWI_Cache::init();
	RAWI_Cache_Compat::init();
	RAWI_Renderer::init();
	RAWI_Verify::init();
	RAWI_Logger::init();
	RAWI_Referrals::init();
	RAWI_Tools::init();

	if ( is_admin() ) {
		RAWI_Admin::init();
		RAWI_Metabox::init();
	}

	if ( defined( 'WP_CLI' ) && WP_CLI ) {
		RAWI_CLI::register();
	}
}
add_action( 'plugins_loaded', 'rawi_boot' );

/**
 * Register the .md and llms.txt rewrite rules.
 *
 * Kept outside the router so that activation can call it directly.
 *
 * @return void
 */
function rawi_register_rewrite() {
	add_rewrite_rule( '^llms\.txt$', 'index.php?rawi_llms=1', 'top' );
	add_rewrite_rule( '^(.+?)\.md/?$', 'index.php?rawi_md=1&rawi_path=$matches[1]', 'top' );
}
add_action( 'init', 'rawi_register_rewrite' );

/**
 * Activation: create the log table, seed defaults, flush rewrites.
 *
 * Safe to run on an existing install: nothing here deletes or resets data.
 *
 * @return void
 */
function rawi_activate() {
	RAWI_Upgrade::run();
	rawi_register_rewrite();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'rawi_activate' );

/**
 * Deactivation: clear scheduled events and rewrite rules.
 *
 * Settings, the request log and the cache are kept, so reactivating picks up
 * exactly where the site left off. Only uninstalling removes them.
 *
 * @return void
 */
function rawi_deactivate() {
	wp_clear_scheduled_hook( 'rawi_daily_maintenance' );
	wp_clear_scheduled_hook( 'rawi_refresh_ip_lists' );
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'rawi_deactivate' );

/**
 * Daily maintenance: prune the request log and tidy the cache folder.
 *
 * @return void
 */
function rawi_daily_maintenance() {
	RAWI_Logger::prune();
	RAWI_Referrals::prune();
	RAWI_Cache::remove_stale();
}
add_action( 'rawi_daily_maintenance', 'rawi_daily_maintenance' );
